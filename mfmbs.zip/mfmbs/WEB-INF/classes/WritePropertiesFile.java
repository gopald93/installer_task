import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class WritePropertiesFile {
	public static void main(String[] args) {
		try {
			Properties properties = new Properties();
			properties.setProperty("Database_Tool_Name", "mysql");
			properties.setProperty("Database_Name", "mfs_temp_database");
			properties.setProperty("Database_User_Name", "admin");
			properties.setProperty("Database_Pass_Word", "1234@Root");
			properties.setProperty("Application_Server_Name", "Antarctica");
			properties.setProperty("Application_Server_User_Name", "Antarctica");
			properties.setProperty("Application_Server_Pass_Word", "Antarctica");
			properties.setProperty("java_folder_path", "D:/java");
			properties.setProperty("python_folder_path", "D:/python");
			properties.setProperty("mysql_folder_path", "D:/mysql");
			properties.setProperty("oracle_folder_path", "D:/oracle");
			properties.setProperty("mssql_folder_path", "D:/mssql");
			properties.setProperty("postgress_folder_path", "D:/postgress");
			properties.setProperty("favoriteContinent", "Antarctica");
			File file = new File("mfs.properties");
			FileOutputStream fileOut = new FileOutputStream(file);
			properties.store(fileOut, "Favorite Things");
			fileOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}