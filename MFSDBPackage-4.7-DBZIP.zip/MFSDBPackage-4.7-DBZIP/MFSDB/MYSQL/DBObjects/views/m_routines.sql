-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `customer_reqeust1_view`
--

DROP TABLE IF EXISTS `customer_reqeust1_view`;
/*!50001 DROP VIEW IF EXISTS `customer_reqeust1_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_reqeust1_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_DESC`,
 1 AS `REQUEST_STATUS`,
 1 AS `REQUEST_CHG_DESC`,
 1 AS `cmobile`,
 1 AS `extn1`,
 1 AS `extn2`,
 1 AS `extn3`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_funds_transfer_transaction_audit`
--

DROP TABLE IF EXISTS `report_funds_transfer_transaction_audit`;
/*!50001 DROP VIEW IF EXISTS `report_funds_transfer_transaction_audit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_funds_transfer_transaction_audit` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_ACCOUNT`,
 1 AS `TO_ACCOUNT`,
 1 AS `REF_NO`,
 1 AS `FROM_BENE`,
 1 AS `TO_BENE`,
 1 AS `BENE_TYPE`,
 1 AS `BENE_CODE`,
 1 AS `BENE_BANK`,
 1 AS `BENE_BRANCH`,
 1 AS `BENE_MOBILE`,
 1 AS `CURRENCY`,
 1 AS `CUST_MOBILE`,
 1 AS `CUST_REF2`,
 1 AS `BEN_CURR`,
 1 AS `BEN_COUNTRY`,
 1 AS `AMOUNT`,
 1 AS `TRAN_TIME`,
 1 AS `TRAN_RESULT_FLAG`,
 1 AS `TRAN_RESULT`,
 1 AS `FT_TYPE`,
 1 AS `CUSTOMER_ID`,
 1 AS `CUSTOMER_CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `MFREVACC`,
 1 AS `MFREVAMT`,
 1 AS `EXCACC`,
 1 AS `EXCAMT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `loan_detail_view`
--

DROP TABLE IF EXISTS `loan_detail_view`;
/*!50001 DROP VIEW IF EXISTS `loan_detail_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `loan_detail_view` AS SELECT 
 1 AS `Id`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `AMOUNT`,
 1 AS `ACC_NUM`,
 1 AS `EMAIL`,
 1 AS `LOAN_TERM`,
 1 AS `PRODUCT`,
 1 AS `PERCENTAGE`,
 1 AS `ADDRESS`,
 1 AS `NATIONAL_ID`,
 1 AS `EMI_AMT`,
 1 AS `AGE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `corp_self_reg_add_accnt_request_view`
--

DROP TABLE IF EXISTS `corp_self_reg_add_accnt_request_view`;
/*!50001 DROP VIEW IF EXISTS `corp_self_reg_add_accnt_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `corp_self_reg_add_accnt_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `REGACCOUNTNO`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mail_stat_view`
--

DROP TABLE IF EXISTS `mail_stat_view`;
/*!50001 DROP VIEW IF EXISTS `mail_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mail_stat_view` AS SELECT 
 1 AS `DATEVAL`,
 1 AS `category`,
 1 AS `status`,
 1 AS `cnt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `full_stmt_temp_view`
--

DROP TABLE IF EXISTS `full_stmt_temp_view`;
/*!50001 DROP VIEW IF EXISTS `full_stmt_temp_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `full_stmt_temp_view` AS SELECT 
 1 AS `ID`,
 1 AS `ACCOUNT_ID`,
 1 AS `NAME`,
 1 AS `PARTICULARS`,
 1 AS `AMOUNT`,
 1 AS `PRODUCT`,
 1 AS `ADDRESS`,
 1 AS `OPERATOR`,
 1 AS `CLIENTID`,
 1 AS `BRANCH1`,
 1 AS `BRANCH2`,
 1 AS `CURRENCY`,
 1 AS `CLEARBALANCE`,
 1 AS `EFFECTS`,
 1 AS `TDATE`,
 1 AS `TVALUE`,
 1 AS `TTYPE`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REPORT_ID`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_funds_tran_trans_view`
--

DROP TABLE IF EXISTS `rep_funds_tran_trans_view`;
/*!50001 DROP VIEW IF EXISTS `rep_funds_tran_trans_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_funds_tran_trans_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `AMOUNT`,
 1 AS `CHARGES`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mobile_access_log_view`
--

DROP TABLE IF EXISTS `mobile_access_log_view`;
/*!50001 DROP VIEW IF EXISTS `mobile_access_log_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mobile_access_log_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIFNO`,
 1 AS `SESSIONID`,
 1 AS `STATUS`,
 1 AS `LASTACC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `LAST_FT_FROM`,
 1 AS `LAST_FT_TO`,
 1 AS `LAST_FT_AMT`,
 1 AS `LAST_FT_REMARKS`,
 1 AS `LAST_PHONE_TYPE`,
 1 AS `LAST_PHONE_ID`,
 1 AS `ACTION_MESG`,
 1 AS `CNAME`,
 1 AS `INSTITUTION_ID`,
 1 AS `INAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_user_activity`
--

DROP TABLE IF EXISTS `report_user_activity`;
/*!50001 DROP VIEW IF EXISTS `report_user_activity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_user_activity` AS SELECT 
 1 AS `USER_ID`,
 1 AS `SOURCE`,
 1 AS `SERVICE`,
 1 AS `SESSIONID`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_system_user_statistics_view`
--

DROP TABLE IF EXISTS `report_system_user_statistics_view`;
/*!50001 DROP VIEW IF EXISTS `report_system_user_statistics_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_system_user_statistics_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `ROLE`,
 1 AS `STATUS`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `card_view`
--

DROP TABLE IF EXISTS `card_view`;
/*!50001 DROP VIEW IF EXISTS `card_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `card_view` AS SELECT 
 1 AS `Id`,
 1 AS `CARD_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `BRANCH_CODE`,
 1 AS `PRIMARY_CARD`,
 1 AS `CARDTYPE`,
 1 AS `ALLOW_SMS`,
 1 AS `ALLOW_EMAIL`,
 1 AS `SMS_THRES`,
 1 AS `EMAIL_THRES`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `ADDTNL_SMS1`,
 1 AS `ADDTNL_SMS2`,
 1 AS `ADDTNL_SMS3`,
 1 AS `ADDTNL_SMS4`,
 1 AS `ADDTNL_SMS5`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXPIRY_AT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `acc_num`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mfs_exc_err_view`
--

DROP TABLE IF EXISTS `mfs_exc_err_view`;
/*!50001 DROP VIEW IF EXISTS `mfs_exc_err_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mfs_exc_err_view` AS SELECT 
 1 AS `Id`,
 1 AS `EXC_NAME`,
 1 AS `EXC_LOCATION`,
 1 AS `FEATURE`,
 1 AS `STACKTRACE`,
 1 AS `EXC_DETAILS`,
 1 AS `EXC_FILE_NAME`,
 1 AS `SERVICE_TITLE`,
 1 AS `REQ_CIF`,
 1 AS `REQ_MOB`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `intel_async`
--

DROP TABLE IF EXISTS `intel_async`;
/*!50001 DROP VIEW IF EXISTS `intel_async`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `intel_async` AS SELECT 
 1 AS `Id`,
 1 AS `SALUTN`,
 1 AS `FIRST_NAME`,
 1 AS `MIDDLE_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `IMG1`,
 1 AS `IMG2`,
 1 AS `IMG3`,
 1 AS `IMG4`,
 1 AS `IMG5`,
 1 AS `RES_TYPE`,
 1 AS `CURRENCY`,
 1 AS `ZIPCODE`,
 1 AS `ADDR1`,
 1 AS `ADDR2`,
 1 AS `ADDR3`,
 1 AS `ADDR4`,
 1 AS `OTPGEN`,
 1 AS `OTPEXP`,
 1 AS `OTPCONFIRMED`,
 1 AS `CHILDCNT`,
 1 AS `GENDER`,
 1 AS `NATIONALITY`,
 1 AS `MAR_STATUS`,
 1 AS `EMPLOYER`,
 1 AS `TIN`,
 1 AS `SHORT_NAME`,
 1 AS `CUST_TYPE`,
 1 AS `ADDR_TYPE`,
 1 AS `COMM_TYPE`,
 1 AS `DEV_NO`,
 1 AS `DOC_ID`,
 1 AS `REF_NO`,
 1 AS `SEC_ANA_TYPE`,
 1 AS `ORG_CLASSF`,
 1 AS `ES_CLASSF`,
 1 AS `AN_TYPE`,
 1 AS `AN_CODE`,
 1 AS `NATIONAL_ID`,
 1 AS `MOBILE`,
 1 AS `DOB`,
 1 AS `ADDRESS`,
 1 AS `SUBMIT_AG_NAME`,
 1 AS `AG_MOBILE`,
 1 AS `CA_STATUS`,
 1 AS `REG_STATUS`,
 1 AS `REQ_CATEG`,
 1 AS `CURR_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `ID1Checked`,
 1 AS `ID2Checked`,
 1 AS `PhotoChecked`,
 1 AS `SignatureChecked`,
 1 AS `IPRSChecked`,
 1 AS `CBCUST_ID`,
 1 AS `CBACCNUM1`,
 1 AS `CBACCNUM2`,
 1 AS `CBACCNUM3`,
 1 AS `CBACCNUM4`,
 1 AS `RESULTCODE`,
 1 AS `RESULTDESC`,
 1 AS `BRANCH_ID`,
 1 AS `ADDR`,
 1 AS `NATURE_OF_BUS`,
 1 AS `AGENT_CODE`,
 1 AS `AGENT_CAT`,
 1 AS `ACCOUNT_OFFICER_ID`,
 1 AS `ACCOUNT_OFFICER_NAME`,
 1 AS `NATIONAL_ID_CHECKED`,
 1 AS `DATE_CODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lnm_tran_master_view`
--

DROP TABLE IF EXISTS `lnm_tran_master_view`;
/*!50001 DROP VIEW IF EXISTS `lnm_tran_master_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `lnm_tran_master_view` AS SELECT 
 1 AS `Id`,
 1 AS `BANK_CODE`,
 1 AS `LNM_SHORT_CODE`,
 1 AS `LNM_REF_NUM`,
 1 AS `LNM_TRAN_DATE`,
 1 AS `LNM_STATUS`,
 1 AS `MERCH_INFO`,
 1 AS `TRAN_ACC_ID`,
 1 AS `TRAN_TYPE`,
 1 AS `NARRATION`,
 1 AS `TRAN_AMT`,
 1 AS `WDL_AMT`,
 1 AS `FILE_NAME`,
 1 AS `POSTING_TYPE`,
 1 AS `SENDER_NAME`,
 1 AS `SENDER_NUMBER`,
 1 AS `PROCESSED_AT`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_mobile_access_log_view`
--

DROP TABLE IF EXISTS `report_mobile_access_log_view`;
/*!50001 DROP VIEW IF EXISTS `report_mobile_access_log_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_mobile_access_log_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIFNO`,
 1 AS `SESSIONID`,
 1 AS `STATUS`,
 1 AS `LASTACC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `LAST_FT_FROM`,
 1 AS `LAST_FT_TO`,
 1 AS `LAST_FT_AMT`,
 1 AS `LAST_FT_REMARKS`,
 1 AS `DATEVAL`,
 1 AS `LAST_PHONE_TYPE`,
 1 AS `LAST_PHONE_ID`,
 1 AS `ACTION_MESG`,
 1 AS `CNAME`,
 1 AS `INSTITUTION_ID`,
 1 AS `INAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mfs_alt_accnum_view`
--

DROP TABLE IF EXISTS `mfs_alt_accnum_view`;
/*!50001 DROP VIEW IF EXISTS `mfs_alt_accnum_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mfs_alt_accnum_view` AS SELECT 
 1 AS `Id`,
 1 AS `MASTER_ACCOUNT`,
 1 AS `MASTER_ACCOUNTH_NAME`,
 1 AS `ALTERNATE_ACCOUNT`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_async_account_opening`
--

DROP TABLE IF EXISTS `report_async_account_opening`;
/*!50001 DROP VIEW IF EXISTS `report_async_account_opening`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_async_account_opening` AS SELECT 
 1 AS `SERVICE_NAME`,
 1 AS `DETAILS`,
 1 AS `RESULT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sms_mesg_view`
--

DROP TABLE IF EXISTS `sms_mesg_view`;
/*!50001 DROP VIEW IF EXISTS `sms_mesg_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sms_mesg_view` AS SELECT 
 1 AS `Id`,
 1 AS `MFROMADDR`,
 1 AS `MTOADDR`,
 1 AS `MMESSAGE`,
 1 AS `MRETRYCNT`,
 1 AS `MESGQIN`,
 1 AS `MESGQOUT`,
 1 AS `MESGQERR`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `NEXT_ATTEMPT`,
 1 AS `LAST_ATTEMPT`,
 1 AS `SCHEDULE_TS`,
 1 AS `REQ_SOURCE`,
 1 AS `LANG_CODE`,
 1 AS `DESTCID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXEC_AG_CODE`,
 1 AS `CCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_view`
--

DROP TABLE IF EXISTS `report_view`;
/*!50001 DROP VIEW IF EXISTS `report_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_view` AS SELECT 
 1 AS `Id`,
 1 AS `RCODE`,
 1 AS `RPARAMETERS`,
 1 AS `RUSERID`,
 1 AS `RRETRYCNT`,
 1 AS `RFORMAT`,
 1 AS `ROUT`,
 1 AS `RERR`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `RURL`,
 1 AS `AGCODE`,
 1 AS `RESULTCODE`,
 1 AS `UName`,
 1 AS `INAME`,
 1 AS `INSTITUTION_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_cheque_deposit`
--

DROP TABLE IF EXISTS `report_cheque_deposit`;
/*!50001 DROP VIEW IF EXISTS `report_cheque_deposit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_cheque_deposit` AS SELECT 
 1 AS `FROM_ACCOUNT_NUMBER`,
 1 AS `TO_ACCOUNT_NUMBER`,
 1 AS `CHEQUE_NUMBER`,
 1 AS `MOBILE_NUMBER`,
 1 AS `IMAGEURL1`,
 1 AS `IMAGEURL2`,
 1 AS `CHQAMT`,
 1 AS `CUST_ID`,
 1 AS `CREATED_AT`,
 1 AS `RSTATUS`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bond_view`
--

DROP TABLE IF EXISTS `bond_view`;
/*!50001 DROP VIEW IF EXISTS `bond_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bond_view` AS SELECT 
 1 AS `Id`,
 1 AS `SUB_REC_ID`,
 1 AS `CIF`,
 1 AS `BOND_NAME`,
 1 AS `BOND_VALUE`,
 1 AS `PURCH_DATE`,
 1 AS `BOND_STATUS`,
 1 AS `BOND_MATURITY`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REF_NO`,
 1 AS `BONDCODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_mobile_recharge_tran_view`
--

DROP TABLE IF EXISTS `ef_mobile_recharge_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_mobile_recharge_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_mobile_recharge_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `RCOPERATOR`,
 1 AS `RCAMOUNT`,
 1 AS `RCMOBILE`,
 1 AS `RCTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `monitor_ft_transactions_view`
--

DROP TABLE IF EXISTS `monitor_ft_transactions_view`;
/*!50001 DROP VIEW IF EXISTS `monitor_ft_transactions_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `monitor_ft_transactions_view` AS SELECT 
 1 AS `FROM_ACCOUNT`,
 1 AS `TO_ACCOUNT`,
 1 AS `REF_NO`,
 1 AS `CUSTOMER_ID`,
 1 AS `CUST_MOBILE`,
 1 AS `FT_TYPE`,
 1 AS `DATEVAL`,
 1 AS `VENDOR_RESPONSE`,
 1 AS `RSTATUS`,
 1 AS `AMOUNT`,
 1 AS `CUST_REF2`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `merchant_credit_request_view`
--

DROP TABLE IF EXISTS `merchant_credit_request_view`;
/*!50001 DROP VIEW IF EXISTS `merchant_credit_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `merchant_credit_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REQUEST_ID`,
 1 AS `CREDIT_REQUEST_TS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `PFROM`,
 1 AS `PFROMCIF`,
 1 AS `PFROMNAME`,
 1 AS `PTO`,
 1 AS `PTOCIF`,
 1 AS `PTONAME`,
 1 AS `ITEM`,
 1 AS `PAMOUNT`,
 1 AS `PCATEGORY`,
 1 AS `PCHARGES`,
 1 AS `PDISC`,
 1 AS `PFINALAMT`,
 1 AS `PRESULT`,
 1 AS `PCURRCODE`,
 1 AS `PCHARGE`,
 1 AS `PREQTIME`,
 1 AS `PPAYTIME`,
 1 AS `PPAYSTATUS`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `ITEM_TYPE`,
 1 AS `CHARGE_TYPE`,
 1 AS `DISCOUNT_TYPE`,
 1 AS `PAYMENT_TYPE`,
 1 AS `MERCHANT_REC_ID`,
 1 AS `CUSTOMER_REC_ID`,
 1 AS `CUSTOMER_ACC_REC_ID`,
 1 AS `CREDIT_APPL_DATE`,
 1 AS `CREDIT_PLAN`,
 1 AS `CREDIT_APP_DATE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `card_code_view`
--

DROP TABLE IF EXISTS `card_code_view`;
/*!50001 DROP VIEW IF EXISTS `card_code_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `card_code_view` AS SELECT 
 1 AS `Id`,
 1 AS `CARDCODE`,
 1 AS `CUST_ID`,
 1 AS `ACC_ID`,
 1 AS `CARD_CATEGORY`,
 1 AS `FROM_DATE`,
 1 AS `TO_DATE`,
 1 AS `CARD_STATUS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_customer_stat_view`
--

DROP TABLE IF EXISTS `rep_customer_stat_view`;
/*!50001 DROP VIEW IF EXISTS `rep_customer_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_customer_stat_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `CATEGORY`,
 1 AS `STATUS`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_category_view`
--

DROP TABLE IF EXISTS `customer_category_view`;
/*!50001 DROP VIEW IF EXISTS `customer_category_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_category_view` AS SELECT 
 1 AS `Id`,
 1 AS `CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHARGE_TYPE`,
 1 AS `CHARGE_VALUE`,
 1 AS `PER_DAY_LIMIT`,
 1 AS `PER_TRAN_LIMIT`,
 1 AS `MIN_TRAN_LIMIT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `SERVICE_ID`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customer_creation_history`
--

DROP TABLE IF EXISTS `report_customer_creation_history`;
/*!50001 DROP VIEW IF EXISTS `report_customer_creation_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customer_creation_history` AS SELECT 
 1 AS `CUST_NAME`,
 1 AS `CUST_MOB`,
 1 AS `CUST_AC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kits_bulk_uplds_view`
--

DROP TABLE IF EXISTS `kits_bulk_uplds_view`;
/*!50001 DROP VIEW IF EXISTS `kits_bulk_uplds_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `kits_bulk_uplds_view` AS SELECT 
 1 AS `Id`,
 1 AS `FILE_NAME`,
 1 AS `NO_OF_REC`,
 1 AS `STATUS`,
 1 AS `BATCH_CODE`,
 1 AS `SERVICE_TITLE`,
 1 AS `DESCRIPTION`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `account_request_view`
--

DROP TABLE IF EXISTS `account_request_view`;
/*!50001 DROP VIEW IF EXISTS `account_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `account_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACCRECID`,
 1 AS `ACCNUM`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cbib_bank_view`
--

DROP TABLE IF EXISTS `cbib_bank_view`;
/*!50001 DROP VIEW IF EXISTS `cbib_bank_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cbib_bank_view` AS SELECT 
 1 AS `Id`,
 1 AS `BANK_CODE`,
 1 AS `BANK_NAME`,
 1 AS `FTACC`,
 1 AS `CHARGESACC`,
 1 AS `CHARGE_CATEGORY`,
 1 AS `STATUS_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BANK_CHARGES_ACCOUNT`,
 1 AS `MF_CHARGES_ACCOUNT`,
 1 AS `BANK_CHARGES_CATEGORY`,
 1 AS `MF_CHARGES_CATEGORY`,
 1 AS `BANK_URL`,
 1 AS `BANK_ENC_KEY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kits_other_bank_view`
--

DROP TABLE IF EXISTS `kits_other_bank_view`;
/*!50001 DROP VIEW IF EXISTS `kits_other_bank_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `kits_other_bank_view` AS SELECT 
 1 AS `Id`,
 1 AS `BANK_ID`,
 1 AS `BANK_NAME`,
 1 AS `SWIFT_CODE`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `REF_BIN_CODE`,
 1 AS `REF_BRANCH_CODE`,
 1 AS `REF_ACCOUNT_NUMBER`,
 1 AS `REF_OTHER_BANK`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kits_accounts_view`
--

DROP TABLE IF EXISTS `kits_accounts_view`;
/*!50001 DROP VIEW IF EXISTS `kits_accounts_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `kits_accounts_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `NATIONAL_ID`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `ACCEXTN1`,
 1 AS `ACCEXTN2`,
 1 AS `ACCEXTN3`,
 1 AS `ACCEXTN4`,
 1 AS `ACCEXTN5`,
 1 AS `ACCEXTN6`,
 1 AS `ACCEXTN7`,
 1 AS `ACCEXTN8`,
 1 AS `ACCEXTN9`,
 1 AS `ACCEXTN10`,
 1 AS `BRANCH_CODE`,
 1 AS `ALT_ACC_ID`,
 1 AS `JOINT_ACCOUNT`,
 1 AS `JOINT_ACCOUNT_MANDATES`,
 1 AS `PRIMARY_ACCOUNT`,
 1 AS `group_code`,
 1 AS `ACCCTYPE`,
 1 AS `card_num`,
 1 AS `card_expiry`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_dtc_bp_tran_view`
--

DROP TABLE IF EXISTS `ef_dtc_bp_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_dtc_bp_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_dtc_bp_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `BPOPERATOR`,
 1 AS `BPAMOUNT`,
 1 AS `BPMOBILE`,
 1 AS `BPTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_dtc_recharge_tran_view`
--

DROP TABLE IF EXISTS `ef_dtc_recharge_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_dtc_recharge_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_dtc_recharge_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `RCOPERATOR`,
 1 AS `RCAMOUNT`,
 1 AS `RCMOBILE`,
 1 AS `RCTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `goods_category_view`
--

DROP TABLE IF EXISTS `goods_category_view`;
/*!50001 DROP VIEW IF EXISTS `goods_category_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `goods_category_view` AS SELECT 
 1 AS `Id`,
 1 AS `CAT_NAME`,
 1 AS `CAT_TYPE`,
 1 AS `CAT_DESCRIPTION`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_permissions_view`
--

DROP TABLE IF EXISTS `customer_permissions_view`;
/*!50001 DROP VIEW IF EXISTS `customer_permissions_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_permissions_view` AS SELECT 
 1 AS `Id`,
 1 AS `CGID`,
 1 AS `SLID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `INAME`,
 1 AS `SCODE`,
 1 AS `SNAME`,
 1 AS `SPARENT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mobile_menu_map_view`
--

DROP TABLE IF EXISTS `mobile_menu_map_view`;
/*!50001 DROP VIEW IF EXISTS `mobile_menu_map_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mobile_menu_map_view` AS SELECT 
 1 AS `Id`,
 1 AS `MENU_TYPE`,
 1 AS `SCREEN_ID`,
 1 AS `FTEXT`,
 1 AS `FHEIGHT`,
 1 AS `FWIDTH`,
 1 AS `FSEQ`,
 1 AS `FSESSCONT`,
 1 AS `FCONTTYPE`,
 1 AS `FFLDLEN`,
 1 AS `FFLDCODE`,
 1 AS `FFLDTYPE`,
 1 AS `NEWSESS`,
 1 AS `ACTIVE_FLAG`,
 1 AS `PARENT_ID`,
 1 AS `SERVICE_ID`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `LANGCODE`,
 1 AS `CONTENT_LENGTH`,
 1 AS `ACTION_ID`,
 1 AS `OVERRIDE_CODE`,
 1 AS `LANG2_MSG`,
 1 AS `LANG3_MSG`,
 1 AS `LANG4_MSG`,
 1 AS `ACCESS_CODE`,
 1 AS `USSD`,
 1 AS `WAP`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `IMAGE_ICON`,
 1 AS `ALLOW_VIRTUAL_AGENT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `INSTITUTION_ID`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mvisa_ext_merchant_view`
--

DROP TABLE IF EXISTS `mvisa_ext_merchant_view`;
/*!50001 DROP VIEW IF EXISTS `mvisa_ext_merchant_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mvisa_ext_merchant_view` AS SELECT 
 1 AS `Id`,
 1 AS `EXT_MV_MERC_ID`,
 1 AS `MERC_NAME`,
 1 AS `PRIMARY_ID`,
 1 AS `SEC_ID`,
 1 AS `MCC`,
 1 AS `CITY`,
 1 AS `CONVFEEPERC`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `eod_tran_master_view`
--

DROP TABLE IF EXISTS `eod_tran_master_view`;
/*!50001 DROP VIEW IF EXISTS `eod_tran_master_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `eod_tran_master_view` AS SELECT 
 1 AS `Id`,
 1 AS `TO_ACCOUNT`,
 1 AS `FROM_ACCOUNT`,
 1 AS `AMOUNT`,
 1 AS `TRANSACTION_TYPE`,
 1 AS `PERCENTAGE`,
 1 AS `SOURCE_AMOUNT`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mvisa_agent_view`
--

DROP TABLE IF EXISTS `mvisa_agent_view`;
/*!50001 DROP VIEW IF EXISTS `mvisa_agent_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mvisa_agent_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `IDNUM`,
 1 AS `PINNUM`,
 1 AS `MOBILE`,
 1 AS `IDPRESENT`,
 1 AS `POST_ADDR`,
 1 AS `BUS_NAME`,
 1 AS `BUS_PIN`,
 1 AS `BUS_TYPE`,
 1 AS `BUS_CODE`,
 1 AS `BUS_LOC`,
 1 AS `BUS_PSTADDR`,
 1 AS `BUS_PSTCODE`,
 1 AS `ISBUS_PIN_PRE`,
 1 AS `BUS_CERT`,
 1 AS `BANK_CODE`,
 1 AS `BRANCH_CODE`,
 1 AS `BANK_ACC_NUM`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `MERC_DISC_RATE`,
 1 AS `MERC_FULL_ID`,
 1 AS `MERC_ID`,
 1 AS `NOTF_METHOD`,
 1 AS `NOTF_DEVID`,
 1 AS `PUSH_URL`,
 1 AS `ALIAS_NAME`,
 1 AS `PRIMARY_CARD`,
 1 AS `NOTIF_MAIL`,
 1 AS `AGENT_PWD`,
 1 AS `AGENT_INIT_PWD`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_sys_user_stat_view`
--

DROP TABLE IF EXISTS `rep_sys_user_stat_view`;
/*!50001 DROP VIEW IF EXISTS `rep_sys_user_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_sys_user_stat_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `ROLE`,
 1 AS `STATUS`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mfs_permissions_view`
--

DROP TABLE IF EXISTS `mfs_permissions_view`;
/*!50001 DROP VIEW IF EXISTS `mfs_permissions_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mfs_permissions_view` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_NAME`,
 1 AS `BILLER_ACNO`,
 1 AS `BILLER_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `funds_transfer_transaction_view`
--

DROP TABLE IF EXISTS `funds_transfer_transaction_view`;
/*!50001 DROP VIEW IF EXISTS `funds_transfer_transaction_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `funds_transfer_transaction_view` AS SELECT 
 1 AS `Id`,
 1 AS `FTFROM`,
 1 AS `FTTO`,
 1 AS `FTAMOUNT`,
 1 AS `FTRESULT`,
 1 AS `FTCURRCODE`,
 1 AS `FTCHARGE`,
 1 AS `FTTRANTIME`,
 1 AS `FTCIF`,
 1 AS `FTSOURCE`,
 1 AS `FTPHONEID`,
 1 AS `FTSESSIONID`,
 1 AS `FTREFNO`,
 1 AS `FTRESULTCODE`,
 1 AS `ERRMSG`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `FTTYPE`,
 1 AS `FTSUBCHARGE`,
 1 AS `INSTITUTION_ID`,
 1 AS `FTSTEPFAILED`,
 1 AS `RESP1`,
 1 AS `RESP2`,
 1 AS `RESP3`,
 1 AS `RESP4`,
 1 AS `FTCOMMENT`,
 1 AS `beneficiary_bank`,
 1 AS `beneficiary_branch`,
 1 AS `beneficiary_currency`,
 1 AS `beneficiary_mobile`,
 1 AS `CAT1`,
 1 AS `CAT2`,
 1 AS `TRAN_DATETS`,
 1 AS `CAT3`,
 1 AS `curr_code`,
 1 AS `tip_amt`,
 1 AS `tran_amtf`,
 1 AS `ref_tab_id`,
 1 AS `tip_and_fee`,
 1 AS `conv_fee_amt`,
 1 AS `RESULTCODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agency_info_busd_view`
--

DROP TABLE IF EXISTS `agency_info_busd_view`;
/*!50001 DROP VIEW IF EXISTS `agency_info_busd_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agency_info_busd_view` AS SELECT 
 1 AS `Id`,
 1 AS `MASTER_AG_ID`,
 1 AS `BName`,
 1 AS `Desig`,
 1 AS `Nationality`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `NATIONAL_ID`,
 1 AS `EMAIL_ID`,
 1 AS `MOBILE_NUM`,
 1 AS `PREF_LANG`,
 1 AS `NOTIF_TYPE`,
 1 AS `CREATED_UID`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `special_biller_charge_type_range_view`
--

DROP TABLE IF EXISTS `special_biller_charge_type_range_view`;
/*!50001 DROP VIEW IF EXISTS `special_biller_charge_type_range_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `special_biller_charge_type_range_view` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `CHARGE_TYPE_CODE`,
 1 AS `CHARGE_VALUE`,
 1 AS `CHARGE_VALUE2`,
 1 AS `CHARGE_VALUE3`,
 1 AS `CHARGE_VALUE4`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CURRENCY_CODE`,
 1 AS `BILLER_NAME`,
 1 AS `BILLER_TYPE`,
 1 AS `BILLER_ACNO`,
 1 AS `STATUS_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `nfc_category_update_view`
--

DROP TABLE IF EXISTS `nfc_category_update_view`;
/*!50001 DROP VIEW IF EXISTS `nfc_category_update_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `nfc_category_update_view` AS SELECT 
 1 AS `Id`,
 1 AS `CATEGORY_CODE`,
 1 AS `CATEGORY_NAME`,
 1 AS `CURR_PRICE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cbaccount_view`
--

DROP TABLE IF EXISTS `cbaccount_view`;
/*!50001 DROP VIEW IF EXISTS `cbaccount_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cbaccount_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `REPORT_FREQ`,
 1 AS `ALLOW_SMS`,
 1 AS `ALLOW_EMAIL`,
 1 AS `SMS_THRES`,
 1 AS `EMAIL_THRES`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `ADDTNL_SMS1`,
 1 AS `ADDTNL_SMS2`,
 1 AS `ADDTNL_SMS3`,
 1 AS `ADDTNL_SMS4`,
 1 AS `ADDTNL_SMS5`,
 1 AS `ACCEXTN1`,
 1 AS `ACCEXTN2`,
 1 AS `ACCEXTN3`,
 1 AS `ACCEXTN4`,
 1 AS `ACCEXTN5`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `CURR_BALANCE`,
 1 AS `CURR_BALANCE_TYPE`,
 1 AS `CURR_BAL_LASTUPD`,
 1 AS `BRANCH_CODE`,
 1 AS `ALLOW_MOBILE`,
 1 AS `VIRTUAL_ACCOUNT`,
 1 AS `ALT_ACC_ID`,
 1 AS `ACCTYPE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `CNAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_funds_trnsf_tran_audit`
--

DROP TABLE IF EXISTS `rep_funds_trnsf_tran_audit`;
/*!50001 DROP VIEW IF EXISTS `rep_funds_trnsf_tran_audit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_funds_trnsf_tran_audit` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_ACCOUNT`,
 1 AS `TO_ACCOUNT`,
 1 AS `REF_NO`,
 1 AS `FROM_BENE`,
 1 AS `TO_BENE`,
 1 AS `BENE_TYPE`,
 1 AS `BENE_CODE`,
 1 AS `BENE_BANK`,
 1 AS `BENE_BRANCH`,
 1 AS `BENE_MOBILE`,
 1 AS `CURRENCY`,
 1 AS `CUST_MOBILE`,
 1 AS `CUST_REF2`,
 1 AS `BEN_CURR`,
 1 AS `BEN_COUNTRY`,
 1 AS `AMOUNT`,
 1 AS `TRAN_TIME`,
 1 AS `TRAN_RESULT_FLAG`,
 1 AS `TRAN_RESULT`,
 1 AS `FT_TYPE`,
 1 AS `CUSTOMER_ID`,
 1 AS `CUSTOMER_CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `MFREVACC`,
 1 AS `MFREVAMT`,
 1 AS `EXCACC`,
 1 AS `EXCAMT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `full_stmt_req_view`
--

DROP TABLE IF EXISTS `full_stmt_req_view`;
/*!50001 DROP VIEW IF EXISTS `full_stmt_req_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `full_stmt_req_view` AS SELECT 
 1 AS `Id`,
 1 AS `REQ_CIF`,
 1 AS `REQ_MOB`,
 1 AS `REQ_EMAIL`,
 1 AS `REQ_ACC`,
 1 AS `REQ_FORMAT`,
 1 AS `REQ_FRM_DATE`,
 1 AS `REQ_TO_DATE`,
 1 AS `COMMENTS`,
 1 AS `REQ_EMAIL1`,
 1 AS `REQ_EMAIL2`,
 1 AS `REQ_EMAIL3`,
 1 AS `REQ_EMAIL4`,
 1 AS `REQ_EMAIL5`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cheque_deposit_view`
--

DROP TABLE IF EXISTS `cheque_deposit_view`;
/*!50001 DROP VIEW IF EXISTS `cheque_deposit_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cheque_deposit_view` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_ACCOUNT_NUMBER`,
 1 AS `TO_ACCOUNT_NUMBER`,
 1 AS `CALL_BACK`,
 1 AS `CALLED_PERSON`,
 1 AS `SIGNATURE_VERIFIED`,
 1 AS `BGDATETIME`,
 1 AS `CHEQUE_NUMBER`,
 1 AS `MOBILE_NUMBER`,
 1 AS `IMAGEURL1`,
 1 AS `IMAGEURL2`,
 1 AS `IMAGEURL3`,
 1 AS `IMAGEURL4`,
 1 AS `IMAGEURL5`,
 1 AS `CHQAMT`,
 1 AS `FROM_CUST_ID`,
 1 AS `FROM_CUST_NAME`,
 1 AS `TO_CUST_ID`,
 1 AS `TO_CUST_NAME`,
 1 AS `SUBMITTED_AT`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `CHQEXTN1`,
 1 AS `CHQEXTN2`,
 1 AS `CHQEXTN3`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agency_info_update_view`
--

DROP TABLE IF EXISTS `agency_info_update_view`;
/*!50001 DROP VIEW IF EXISTS `agency_info_update_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agency_info_update_view` AS SELECT 
 1 AS `Id`,
 1 AS `AGENCY_INFO_REC_ID`,
 1 AS `REF_CUST_REC_ID`,
 1 AS `REF_CUST_CIF`,
 1 AS `REF_CUST_MOBILE`,
 1 AS `REF_CUST_NAME`,
 1 AS `DOMIBRNCH`,
 1 AS `NATIONALTY`,
 1 AS `PROFCONT1`,
 1 AS `PROFCONT2`,
 1 AS `SERVPK`,
 1 AS `BRNCHCODE`,
 1 AS `PROFPROV`,
 1 AS `PROFAGCODE`,
 1 AS `TRDNAME`,
 1 AS `PSTADDR`,
 1 AS `LRNUM`,
 1 AS `PSTCITY`,
 1 AS `PSTZIP`,
 1 AS `BUSLOC`,
 1 AS `PHYADDR`,
 1 AS `BUSSTAT`,
 1 AS `BUSNAME`,
 1 AS `BUSDESIG`,
 1 AS `BUSNATIONALITY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `SUB_AGENCY`,
 1 AS `MAST_AGCODE`,
 1 AS `served_by`,
 1 AS `agextn3`,
 1 AS `cb_min_amt`,
 1 AS `cb_max_amt`,
 1 AS `serv_comm`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `joint_account_pending_approvals_view`
--

DROP TABLE IF EXISTS `joint_account_pending_approvals_view`;
/*!50001 DROP VIEW IF EXISTS `joint_account_pending_approvals_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `joint_account_pending_approvals_view` AS SELECT 
 1 AS `ft_tran_id`,
 1 AS `ft_from`,
 1 AS `cnt`,
 1 AS `NEXT_REM_TS`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `standing_order_execution_view`
--

DROP TABLE IF EXISTS `standing_order_execution_view`;
/*!50001 DROP VIEW IF EXISTS `standing_order_execution_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `standing_order_execution_view` AS SELECT 
 1 AS `Id`,
 1 AS `REF_ORDER_ID`,
 1 AS `FROMACC`,
 1 AS `TOACC`,
 1 AS `AMOUNT`,
 1 AS `FT_REMARKS`,
 1 AS `FT_TRIGGERTS`,
 1 AS `FT_RESULT_CODE`,
 1 AS `FT_RESULT_MESSAGE`,
 1 AS `INSTITUTION_ID`,
 1 AS `STATUS_CODE`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `EXEC_DATE`,
 1 AS `EXEC_ORDER_NAME`,
 1 AS `SETUP_CHARGE1`,
 1 AS `SETUP_CHARGE2`,
 1 AS `CURRENCY_CODE`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `ORIG_CUST_ID`,
 1 AS `ORIG_CUST_NAME`,
 1 AS `ORIG_CUST_MOBILE`,
 1 AS `ORIG_CUST_GROUP`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `join_account_approvercr_view`
--

DROP TABLE IF EXISTS `join_account_approvercr_view`;
/*!50001 DROP VIEW IF EXISTS `join_account_approvercr_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `join_account_approvercr_view` AS SELECT 
 1 AS `Id`,
 1 AS `ORIG_REC_ID`,
 1 AS `ACC_NUM`,
 1 AS `REG_CUST_ID`,
 1 AS `REG_CUST_NAME`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CUST_NAME`,
 1 AS `MANDATORY`,
 1 AS `ROLE_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `OTP_GEN`,
 1 AS `OTP_EXP`,
 1 AS `max_approval_amount`,
 1 AS `MOB_NUM`,
 1 AS `ORIG_CIF`,
 1 AS `BEN_MOB_NUM`,
 1 AS `CHARGS`,
 1 AS `PAYDESC`,
 1 AS `BENBANKCODE`,
 1 AS `BENBRNCHCODE`,
 1 AS `BENBRNCHCURR`,
 1 AS `BENNAME`,
 1 AS `BENTYPE`,
 1 AS `SERV_NAME`,
 1 AS `FULL_MAP`,
 1 AS `SEQ_CODE`,
 1 AS `CATEG_CODE`,
 1 AS `UPDATE_STAT`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mfs_menu_item_view`
--

DROP TABLE IF EXISTS `mfs_menu_item_view`;
/*!50001 DROP VIEW IF EXISTS `mfs_menu_item_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mfs_menu_item_view` AS SELECT 
 1 AS `Id`,
 1 AS `MENU_ITEM_CODE`,
 1 AS `MENU_TITLE`,
 1 AS `MENU_ICON`,
 1 AS `MENU_PARENT`,
 1 AS `LICENSE_LEVEL`,
 1 AS `CATEGORY`,
 1 AS `ROLE_CODE`,
 1 AS `FEATURE_CODE`,
 1 AS `SEQ_CODE`,
 1 AS `PARENT_MENU_ITEM`,
 1 AS `PERMIT`,
 1 AS `BLOCK`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_view`
--

DROP TABLE IF EXISTS `customer_view`;
/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `VAL_ACC`,
 1 AS `NATIONAL_ID`,
 1 AS `PASSPORT`,
 1 AS `NATIONALITY`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `ID_SUBMITTED`,
 1 AS `ID_VERIFIED`,
 1 AS `PIN_NO`,
 1 AS `TERMS_SIGNED`,
 1 AS `UG_ISSUED`,
 1 AS `PREF_LANG`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `CUST_CAT`,
 1 AS `ALLOWED_PHONE_TYPE1`,
 1 AS `ALLOWED_PHONE_TYPE2`,
 1 AS `ALLOWED_PHONE_TYPE3`,
 1 AS `ALLOWED_PHONE_ID1`,
 1 AS `ALLOWED_PHONE_ID2`,
 1 AS `ALLOWED_PHONE_ID3`,
 1 AS `ALLOWED_PHONE_IDM1`,
 1 AS `ALLOWED_PHONE_IDA1`,
 1 AS `TPIN_NO`,
 1 AS `AUTH_FAIL_PIN`,
 1 AS `AUTH_FAIL_TPIN`,
 1 AS `REPORT_FREQ`,
 1 AS `CUST_EXTN1`,
 1 AS `CUST_EXTN2`,
 1 AS `CUST_EXTN3`,
 1 AS `CUST_EXTN4`,
 1 AS `INITIAL_MPIN`,
 1 AS `INITIAL_TPIN`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `CUSEXTN11`,
 1 AS `CUSEXTN12`,
 1 AS `CUSEXTN13`,
 1 AS `CUSEXTN14`,
 1 AS `CUSEXTN15`,
 1 AS `MPIN_FLDATTMPT`,
 1 AS `LAST_ATTMPTSRC`,
 1 AS `LAST_ATTMPTVER`,
 1 AS `UNLOCK_TIME`,
 1 AS `MOBILE_ACCESS`,
 1 AS `VIRTUAL_AGENCY`,
 1 AS `VIRTUAL_AGENCY_ACC`,
 1 AS `AGENCY_ID`,
 1 AS `VIRTUAL_CUSTOMER`,
 1 AS `CA_APP_ACCESS`,
 1 AS `ACCOUNT_OFFICER_ID`,
 1 AS `ACCOUNT_OFFICER_NAME`,
 1 AS `ACCSUP_NAME`,
 1 AS `MERCHANT`,
 1 AS `IB_ENABLED`,
 1 AS `IB_UID`,
 1 AS `IB_PWD`,
 1 AS `IB_DEFPWD`,
 1 AS `IB_LASTSETPWD`,
 1 AS `IB_SQ1`,
 1 AS `IB_SQ2`,
 1 AS `IB_SQ3`,
 1 AS `IB_SQ4`,
 1 AS `IB_SQ5`,
 1 AS `IB_SA1`,
 1 AS `IB_SA2`,
 1 AS `IB_SA3`,
 1 AS `IB_SA4`,
 1 AS `IB_SA5`,
 1 AS `OTP_GEN`,
 1 AS `OTP_GEN_AT`,
 1 AS `INETPWD_FLD_ATMPT`,
 1 AS `INETPWD_PWD_FLD_BLK`,
 1 AS `INETPWD_LST_FAILED_LOGINAT`,
 1 AS `INETPWD_LST_SUCCESS_LOGINAT`,
 1 AS `CORPORATE_CUSTOMER`,
 1 AS `CORPORATE_CUSTOMER_TYPE`,
 1 AS `INETB_MAKER`,
 1 AS `INETB_CHECKER`,
 1 AS `DEFAPPCIF`,
 1 AS `ORGNAME`,
 1 AS `ROLECODE`,
 1 AS `TERMSNCONDS`,
 1 AS `PREFMDOFCOMM`,
 1 AS `IBLOCKED`,
 1 AS `CPRNO`,
 1 AS `RIMNO`,
 1 AS `FBID`,
 1 AS `FBCODE`,
 1 AS `FBACTIVE`,
 1 AS `OLDSYSPWD`,
 1 AS `INET_OVRRDPWD`,
 1 AS `INET_OVRRDPWDEXP`,
 1 AS `INET_OVRRDPWDFROMDT`,
 1 AS `PIN_INVAL_CNT`,
 1 AS `PWD_INVAL_CNT`,
 1 AS `MB_LAST_LOGIN`,
 1 AS `OB_LAST_LOGIN`,
 1 AS `CUST_PREF_NAME`,
 1 AS `PIN_RLS_AT`,
 1 AS `PWD_RLS_AT`,
 1 AS `MB_CURR_LOGIN`,
 1 AS `OB_CURR_LOGIN`,
 1 AS `MB_LAST_CHANNEL`,
 1 AS `MB_CURR_CHANNEL`,
 1 AS `MPINSETDATE`,
 1 AS `TPINSETDATE`,
 1 AS `prof_mobile1`,
 1 AS `prof_mobile2`,
 1 AS `group_code`,
 1 AS `DOB`,
 1 AS `ALTPHONE`,
 1 AS `DESIG`,
 1 AS `REGBRANCH`,
 1 AS `SUB_AGENT`,
 1 AS `AGENT_NAME`,
 1 AS `AGENT_CODE`,
 1 AS `REFBY`,
 1 AS `OTPDELV`,
 1 AS `FNAME`,
 1 AS `LNAME`,
 1 AS `CEXTN1`,
 1 AS `CEXTN2`,
 1 AS `CEXTN3`,
 1 AS `CDSCNUM`,
 1 AS `BROKER_ID`,
 1 AS `GENDER`,
 1 AS `BROKER_NAME`,
 1 AS `AKIBA_REG`,
 1 AS `AKIBA_REGAT`,
 1 AS `AKIBA_REGREF`,
 1 AS `DEBMIN`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `mv_pin_no`,
 1 AS `mv_initial_pin`,
 1 AS `cust_type`,
 1 AS `mva_failed_atmpts`,
 1 AS `mva_initial_pin`,
 1 AS `mva_pin_no`,
 1 AS `mva_pinsetdate`,
 1 AS `mv_super_cif`,
 1 AS `mv_failed_atmpts`,
 1 AS `mv_pinsetdate`,
 1 AS `CATEGORY`,
 1 AS `GRPCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mobile_failed_login_view`
--

DROP TABLE IF EXISTS `mobile_failed_login_view`;
/*!50001 DROP VIEW IF EXISTS `mobile_failed_login_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mobile_failed_login_view` AS SELECT 
 1 AS `ID`,
 1 AS `username`,
 1 AS `email`,
 1 AS `source`,
 1 AS `created_at`,
 1 AS `created_by`,
 1 AS `modified_at`,
 1 AS `modified_by`,
 1 AS `CName`,
 1 AS `Institution_id`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `maker_checker_audit_view`
--

DROP TABLE IF EXISTS `maker_checker_audit_view`;
/*!50001 DROP VIEW IF EXISTS `maker_checker_audit_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `maker_checker_audit_view` AS SELECT 
 1 AS `Id`,
 1 AS `TAB_NAME`,
 1 AS `TABLE_LABEL`,
 1 AS `ACTION_NAME`,
 1 AS `COMMENTS`,
 1 AS `REC_ID`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `USER_ID`,
 1 AS `UName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_el_bp_tran_view`
--

DROP TABLE IF EXISTS `ef_el_bp_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_el_bp_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_el_bp_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `BPOPERATOR`,
 1 AS `BPAMOUNT`,
 1 AS `BPNUM`,
 1 AS `BPTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_customers_mob_banking`
--

DROP TABLE IF EXISTS `rep_customers_mob_banking`;
/*!50001 DROP VIEW IF EXISTS `rep_customers_mob_banking`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_customers_mob_banking` AS SELECT 
 1 AS `cname`,
 1 AS `val_acc`,
 1 AS `branch`,
 1 AS `national_id`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `card_account_view`
--

DROP TABLE IF EXISTS `card_account_view`;
/*!50001 DROP VIEW IF EXISTS `card_account_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `card_account_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `REPORT_FREQ`,
 1 AS `ALLOW_SMS`,
 1 AS `ALLOW_EMAIL`,
 1 AS `SMS_THRES`,
 1 AS `EMAIL_THRES`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `ADDTNL_SMS1`,
 1 AS `ADDTNL_SMS2`,
 1 AS `ADDTNL_SMS3`,
 1 AS `ADDTNL_SMS4`,
 1 AS `ADDTNL_SMS5`,
 1 AS `ACCEXTN1`,
 1 AS `ACCEXTN2`,
 1 AS `ACCEXTN3`,
 1 AS `ACCEXTN4`,
 1 AS `ACCEXTN5`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `CURR_BALANCE`,
 1 AS `CURR_BALANCE_TYPE`,
 1 AS `CURR_BAL_LASTUPD`,
 1 AS `BRANCH_CODE`,
 1 AS `ALLOW_MOBILE`,
 1 AS `VIRTUAL_ACCOUNT`,
 1 AS `ALT_ACC_ID`,
 1 AS `AH_CB_NAME`,
 1 AS `AH_CIF_NAME`,
 1 AS `JOINT_ACCOUNT`,
 1 AS `JOINT_ACCOUNT_MANDATES`,
 1 AS `PRIMARY_ACCOUNT`,
 1 AS `group_code`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bp_summ_view`
--

DROP TABLE IF EXISTS `bp_summ_view`;
/*!50001 DROP VIEW IF EXISTS `bp_summ_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bp_summ_view` AS SELECT 
 1 AS `batch_code`,
 1 AS `cnt`,
 1 AS `totamt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `merchant_view`
--

DROP TABLE IF EXISTS `merchant_view`;
/*!50001 DROP VIEW IF EXISTS `merchant_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `merchant_view` AS SELECT 
 1 AS `Id`,
 1 AS `MERCH_ID`,
 1 AS `MERCH_NAME`,
 1 AS `MOBILE`,
 1 AS `MERCH_TYPE`,
 1 AS `EMAIL`,
 1 AS `MERCH_CTG`,
 1 AS `MERCH_CODE`,
 1 AS `MERCH_ADR`,
 1 AS `MERCH_PIN`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ml_request_view`
--

DROP TABLE IF EXISTS `ml_request_view`;
/*!50001 DROP VIEW IF EXISTS `ml_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ml_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `REQ_CIF`,
 1 AS `REQ_NAME`,
 1 AS `REQ_AMT`,
 1 AS `REQ_TS`,
 1 AS `REQ_ACC`,
 1 AS `REQ_TYPE`,
 1 AS `GUR_CIF`,
 1 AS `GUR_NAME`,
 1 AS `GUR_AMT`,
 1 AS `GUR_TS`,
 1 AS `GUR_ACC`,
 1 AS `GUR_APPROVAL_AT`,
 1 AS `GUR_ACTION`,
 1 AS `CURRENCY`,
 1 AS `CB_SCORE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQ_BAL`,
 1 AS `GUR_BAL`,
 1 AS `REQ_ELIG_BAL`,
 1 AS `GUR_ELIG_BAL`,
 1 AS `REQ_MOBILE`,
 1 AS `GUR_MOBILE`,
 1 AS `REQ_MAIL`,
 1 AS `GUR_MAIL`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `spblr_chrg_type_rng_view`
--

DROP TABLE IF EXISTS `spblr_chrg_type_rng_view`;
/*!50001 DROP VIEW IF EXISTS `spblr_chrg_type_rng_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `spblr_chrg_type_rng_view` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `CHARGE_TYPE_CODE`,
 1 AS `CHARGE_VALUE`,
 1 AS `CHARGE_VALUE2`,
 1 AS `CHARGE_VALUE3`,
 1 AS `CHARGE_VALUE4`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CURRENCY_CODE`,
 1 AS `BILLER_NAME`,
 1 AS `BILLER_TYPE`,
 1 AS `BILLER_ACNO`,
 1 AS `STATUS_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_mobile_user_usage_statistics_view`
--

DROP TABLE IF EXISTS `report_mobile_user_usage_statistics_view`;
/*!50001 DROP VIEW IF EXISTS `report_mobile_user_usage_statistics_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_mobile_user_usage_statistics_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `chama_member_view`
--

DROP TABLE IF EXISTS `chama_member_view`;
/*!50001 DROP VIEW IF EXISTS `chama_member_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `chama_member_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHAMA_ACC_NUM`,
 1 AS `MEMBER_CIF`,
 1 AS `MEMBER_ACC`,
 1 AS `MEMBER_NAME`,
 1 AS `SIGNATORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `CHAMA_TITLE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `account_view`
--

DROP TABLE IF EXISTS `account_view`;
/*!50001 DROP VIEW IF EXISTS `account_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `account_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `REPORT_FREQ`,
 1 AS `ALLOW_SMS`,
 1 AS `ALLOW_EMAIL`,
 1 AS `SMS_THRES`,
 1 AS `EMAIL_THRES`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `ADDTNL_SMS1`,
 1 AS `ADDTNL_SMS2`,
 1 AS `ADDTNL_SMS3`,
 1 AS `ADDTNL_SMS4`,
 1 AS `ADDTNL_SMS5`,
 1 AS `ACCEXTN1`,
 1 AS `ACCEXTN2`,
 1 AS `ACCEXTN3`,
 1 AS `ACCEXTN4`,
 1 AS `ACCEXTN5`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `CURR_BALANCE`,
 1 AS `CURR_BALANCE_TYPE`,
 1 AS `CURR_BAL_LASTUPD`,
 1 AS `BRANCH_CODE`,
 1 AS `ALLOW_MOBILE`,
 1 AS `VIRTUAL_ACCOUNT`,
 1 AS `ALT_ACC_ID`,
 1 AS `AH_CB_NAME`,
 1 AS `AH_CIF_NAME`,
 1 AS `JOINT_ACCOUNT`,
 1 AS `JOINT_ACCOUNT_MANDATES`,
 1 AS `PRIMARY_ACCOUNT`,
 1 AS `group_code`,
 1 AS `CRDMIN`,
 1 AS `DEBMIN`,
 1 AS `STMT_PRTY`,
 1 AS `ALSALCR`,
 1 AS `ALCHQDEP`,
 1 AS `ALODAM`,
 1 AS `ALATM`,
 1 AS `ACCCTYPE`,
 1 AS `CNAME`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `GRPCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `other_bank_view`
--

DROP TABLE IF EXISTS `other_bank_view`;
/*!50001 DROP VIEW IF EXISTS `other_bank_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `other_bank_view` AS SELECT 
 1 AS `Id`,
 1 AS `BANK_ID`,
 1 AS `BANK_NAME`,
 1 AS `SWIFT_CODE`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `REF_BIN_CODE`,
 1 AS `REF_BRANCH_CODE`,
 1 AS `REF_ACCOUNT_NUMBER`,
 1 AS `REF_OTHER_BANK`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_ll_bp_tran_view`
--

DROP TABLE IF EXISTS `ef_ll_bp_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_ll_bp_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_ll_bp_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `BPOPERATOR`,
 1 AS `BPAMOUNT`,
 1 AS `BPSTD`,
 1 AS `BPNUM`,
 1 AS `BPTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_sysuser_crea_history`
--

DROP TABLE IF EXISTS `rep_sysuser_crea_history`;
/*!50001 DROP VIEW IF EXISTS `rep_sysuser_crea_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_sysuser_crea_history` AS SELECT 
 1 AS `USERNAME`,
 1 AS `ROLE`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `system_user_view`
--

DROP TABLE IF EXISTS `system_user_view`;
/*!50001 DROP VIEW IF EXISTS `system_user_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `system_user_view` AS SELECT 
 1 AS `Id`,
 1 AS `USER_ID`,
 1 AS `USER_PASSWORD`,
 1 AS `PREFIX`,
 1 AS `FIRST_NAME`,
 1 AS `MIDDLE_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `MOBILE`,
 1 AS `INSTITUTION_ID`,
 1 AS `COUNTRY`,
 1 AS `LAST_LOGIN_DATE`,
 1 AS `LAST_LOGIN_FDATE`,
 1 AS `LOGIN_ATTEMPTS`,
 1 AS `PREF_LANG`,
 1 AS `PREF_COMM`,
 1 AS `USER_ROLE_ID`,
 1 AS `SUP_ID`,
 1 AS `SEQ_Q1`,
 1 AS `SEQ_Q2`,
 1 AS `SEQ_Q3`,
 1 AS `SEQ_A1`,
 1 AS `SEQ_A2`,
 1 AS `SEQ_A3`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `PWDSETDATE`,
 1 AS `INITIAL_PWD`,
 1 AS `TRAN_ACCNT_MASTER`,
 1 AS `TRAN_ACCNT_SUB`,
 1 AS `TRAN_ACCNT_MSTMAX`,
 1 AS `TRAN_ACCNT_SUBMAX`,
 1 AS `TRAN_ACCNT_MSTUSED`,
 1 AS `TRAN_ACCNT_SUBUSED`,
 1 AS `TRAN_ACCNT_MASTER_NAME`,
 1 AS `TRAN_ACCNT_SUB_NAME`,
 1 AS `checker_id`,
 1 AS `DISTR_ID`,
 1 AS `AGENT_ID`,
 1 AS `MERCHANT`,
 1 AS `GROUP_CODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `ROLENAME`,
 1 AS `ADMIN_PERM`,
 1 AS `MAKER_PERM`,
 1 AS `CHECKER_PERM`,
 1 AS `GLOBAL_ADMIN_PERM`,
 1 AS `REPORT_PERM`,
 1 AS `AUDIT_PERM`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sms_mesg_in_view`
--

DROP TABLE IF EXISTS `sms_mesg_in_view`;
/*!50001 DROP VIEW IF EXISTS `sms_mesg_in_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sms_mesg_in_view` AS SELECT 
 1 AS `Id`,
 1 AS `CPR`,
 1 AS `MFROMADDR`,
 1 AS `MTOADDR`,
 1 AS `MMESSAGE`,
 1 AS `MMESSAGESTATUS`,
 1 AS `MRETRYCNT`,
 1 AS `MESGQIN`,
 1 AS `MESGQOUT`,
 1 AS `MESGQERR`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `NEXT_ATTEMPT`,
 1 AS `LAST_ATTEMPT`,
 1 AS `REQ_SOURCE`,
 1 AS `LANG_CODE`,
 1 AS `DESTCID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXEC_AG_CODE`,
 1 AS `CCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ticket_master_view`
--

DROP TABLE IF EXISTS `ticket_master_view`;
/*!50001 DROP VIEW IF EXISTS `ticket_master_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ticket_master_view` AS SELECT 
 1 AS `Id`,
 1 AS `TITLE`,
 1 AS `TDESC`,
 1 AS `TTYPE`,
 1 AS `TPRIORITY`,
 1 AS `TPRIORITY_SEQ`,
 1 AS `TCATEGORY`,
 1 AS `TPROJECT`,
 1 AS `TRECESTIMATE`,
 1 AS `TRESESTIMATE`,
 1 AS `TASGNTO`,
 1 AS `TCURRSTAT`,
 1 AS `TRAISED`,
 1 AS `TREPEAT_ISSUE`,
 1 AS `TACKAT`,
 1 AS `TRECAT`,
 1 AS `TRESAT`,
 1 AS `TCLSDAT`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `GROUP_CODE`,
 1 AS `contact_mobile`,
 1 AS `contact_email`,
 1 AS `CONTACT_NAME`,
 1 AS `EST_TO_COMPL`,
 1 AS `ROOT_CAUSE`,
 1 AS `SOURCE_IP`,
 1 AS `REQ_CIF`,
 1 AS `REQ_REC_ID`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `forex_rate_view`
--

DROP TABLE IF EXISTS `forex_rate_view`;
/*!50001 DROP VIEW IF EXISTS `forex_rate_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `forex_rate_view` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_CURR`,
 1 AS `TO_CURR`,
 1 AS `BUY_RATE`,
 1 AS `SELL_RATE`,
 1 AS `CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_reqeust_view`
--

DROP TABLE IF EXISTS `customer_reqeust_view`;
/*!50001 DROP VIEW IF EXISTS `customer_reqeust_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_reqeust_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_DESC`,
 1 AS `REQUEST_STATUS`,
 1 AS `REQUEST_CHG_DESC`,
 1 AS `cmobile`,
 1 AS `extn1`,
 1 AS `extn2`,
 1 AS `extn3`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `grp_code`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customers_email_alert`
--

DROP TABLE IF EXISTS `report_customers_email_alert`;
/*!50001 DROP VIEW IF EXISTS `report_customers_email_alert`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customers_email_alert` AS SELECT 
 1 AS `cname`,
 1 AS `val_acc`,
 1 AS `branch`,
 1 AS `national_id`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `airtel_tran_view`
--

DROP TABLE IF EXISTS `airtel_tran_view`;
/*!50001 DROP VIEW IF EXISTS `airtel_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `airtel_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `ATID`,
 1 AS `ORIG`,
 1 AS `DEST`,
 1 AS `TSTAMP`,
 1 AS `ATTEXT`,
 1 AS `ATUSER`,
 1 AS `ATPASS`,
 1 AS `ATCODE`,
 1 AS `ATCUSTID`,
 1 AS `ATRTMETHODID`,
 1 AS `ATRTMETHODNAME`,
 1 AS `ATACC`,
 1 AS `ATISDN`,
 1 AS `ATTDATE`,
 1 AS `ATTTIME`,
 1 AS `ATTAMT`,
 1 AS `ATSENDER`,
 1 AS `ATRESP`,
 1 AS `ATERRMSG`,
 1 AS `BANKCHARGES`,
 1 AS `SAFARICOMCHARGES`,
 1 AS `RCVBTRNSRESULT_CODE`,
 1 AS `RCVBTRNSRESULT`,
 1 AS `RCVBTRNSTS`,
 1 AS `RCVBTRNSAMT`,
 1 AS `CUSTTRNSRESULT_CODE`,
 1 AS `CUSTTRNSRESULT`,
 1 AS `CUSTTRNSTS`,
 1 AS `CUSTTRNSAMT`,
 1 AS `BANKCHRGRESULT_CODE`,
 1 AS `BANKCHRGRESULT`,
 1 AS `BANKCHRGTS`,
 1 AS `BANKCHRGAMT`,
 1 AS `AIRTELCHRGRESULT_CODE`,
 1 AS `AIRTELCHRGRESULT`,
 1 AS `AIRTELCHRGTS`,
 1 AS `AIRTELCHRGAMT`,
 1 AS `SUSPENSERESULT_CODE`,
 1 AS `SUSPENSERESULT`,
 1 AS `SUSPENSECHRGTS`,
 1 AS `SUSPENSECHRGAMT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `STATUS_DESC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_SOURCE_IP`,
 1 AS `TAXRESULT_CODE`,
 1 AS `TAXRESULT`,
 1 AS `TAXTS`,
 1 AS `TAXAMT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `merchant_payment_refund_view`
--

DROP TABLE IF EXISTS `merchant_payment_refund_view`;
/*!50001 DROP VIEW IF EXISTS `merchant_payment_refund_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `merchant_payment_refund_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_ID`,
 1 AS `RREASON`,
 1 AS `RAMOUNT`,
 1 AS `RCHARGES`,
 1 AS `RFINALAMT`,
 1 AS `RRESULT`,
 1 AS `RREQTIME`,
 1 AS `RPAYTIME`,
 1 AS `REFUNDSTATUS`,
 1 AS `ERRMSG`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `PFROM`,
 1 AS `PFROMCIF`,
 1 AS `PFROMNAME`,
 1 AS `PTO`,
 1 AS `PTOCIF`,
 1 AS `PTONAME`,
 1 AS `ITEM`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `corp_self_reg_request_view`
--

DROP TABLE IF EXISTS `corp_self_reg_request_view`;
/*!50001 DROP VIEW IF EXISTS `corp_self_reg_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `corp_self_reg_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `PREFNAME`,
 1 AS `EMPLOYER`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `NATIONALID`,
 1 AS `NATIONALITY`,
 1 AS `REGACCOUNTNO`,
 1 AS `NEEDOLBACCESS`,
 1 AS `NEEDMBACCESS`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `ROLE`,
 1 AS `DEFAPPCIF`,
 1 AS `DEFAPPCIFNAME`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `JNTACCAPPCIF1NAME`,
 1 AS `JNTACCAPPCIF2NAME`,
 1 AS `JNTACCAPPCIF3NAME`,
 1 AS `JNTACCAPPCIF4NAME`,
 1 AS `JNTACCAPPCIF5NAME`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `BULKAPPCIF1NAME`,
 1 AS `BULKAPPCIF2NAME`,
 1 AS `BULKAPPCIF3NAME`,
 1 AS `JNTACCAPPCIF1MA`,
 1 AS `JNTACCAPPCIF2MA`,
 1 AS `JNTACCAPPCIF3MA`,
 1 AS `JNTACCAPPCIF4MA`,
 1 AS `JNTACCAPPCIF5MA`,
 1 AS `BULKAPPCIF1MA`,
 1 AS `BULKAPPCIF2MA`,
 1 AS `BULKAPPCIF3MA`,
 1 AS `JNTACCAPPCIF1MNDAPP`,
 1 AS `JNTACCAPPCIF2MNDAPP`,
 1 AS `JNTACCAPPCIF3MNDAPP`,
 1 AS `JNTACCAPPCIF4MNDAPP`,
 1 AS `JNTACCAPPCIF5MNDAPP`,
 1 AS `BULKAPPCIF1MNDAPP`,
 1 AS `BULKAPPCIF2MNDAPP`,
 1 AS `BULKAPPCIF3MNDAPP`,
 1 AS `SECQ1`,
 1 AS `SECQ2`,
 1 AS `SECQ3`,
 1 AS `SECA1`,
 1 AS `SECA2`,
 1 AS `SECA3`,
 1 AS `PREFMDOFCOMM`,
 1 AS `REQUEST_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `JNTACCAPPCIF1SEQ`,
 1 AS `JNTACCAPPCIF2SEQ`,
 1 AS `JNTACCAPPCIF3SEQ`,
 1 AS `JNTACCAPPCIF4SEQ`,
 1 AS `JNTACCAPPCIF5SEQ`,
 1 AS `BULKAPPCIF1SEQ`,
 1 AS `BULKAPPCIF2SEQ`,
 1 AS `BULKAPPCIF3SEQ`,
 1 AS `JNTACCAPPCIF1ROLE`,
 1 AS `JNTACCAPPCIF2ROLE`,
 1 AS `JNTACCAPPCIF3ROLE`,
 1 AS `JNTACCAPPCIF4ROLE`,
 1 AS `JNTACCAPPCIF5ROLE`,
 1 AS `JNTACCAPPCIF6ROLE`,
 1 AS `BULKAPPCIF4`,
 1 AS `BULKAPPCIF5`,
 1 AS `BULKAPPCIF6`,
 1 AS `BULKAPPCIF4NAME`,
 1 AS `BULKAPPCIF5NAME`,
 1 AS `BULKAPPCIF6NAME`,
 1 AS `BULKAPPCIF4MA`,
 1 AS `BULKAPPCIF5MA`,
 1 AS `BULKAPPCIF6MA`,
 1 AS `BULKAPPCIF4MNDAPP`,
 1 AS `BULKAPPCIF5MNDAPP`,
 1 AS `BULKAPPCIF6MNDAPP`,
 1 AS `BULKAPPCIF4SEQ`,
 1 AS `BULKAPPCIF5SEQ`,
 1 AS `BULKAPPCIF6SEQ`,
 1 AS `BULKAPPROLE1CODE`,
 1 AS `BULKAPPROLE2CODE`,
 1 AS `BULKAPPROLE3CODE`,
 1 AS `BULKAPPROLE4CODE`,
 1 AS `BULKAPPROLE5CODE`,
 1 AS `BULKAPPROLE6CODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `join_account_approver_view`
--

DROP TABLE IF EXISTS `join_account_approver_view`;
/*!50001 DROP VIEW IF EXISTS `join_account_approver_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `join_account_approver_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CUST_NAME`,
 1 AS `MANDATORY`,
 1 AS `ROLE_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REG_CUST_ID`,
 1 AS `REG_CUST_NAME`,
 1 AS `OTP_GEN`,
 1 AS `OTP_EXP`,
 1 AS `max_approval_amount`,
 1 AS `MOB_NUM`,
 1 AS `ORIG_CIF`,
 1 AS `BEN_MOB_NUM`,
 1 AS `CHARGS`,
 1 AS `PAYDESC`,
 1 AS `BENBANKCODE`,
 1 AS `BENBRNCHCODE`,
 1 AS `BENBRNCHCURR`,
 1 AS `BENNAME`,
 1 AS `BENTYPE`,
 1 AS `SERV_NAME`,
 1 AS `FULL_MAP`,
 1 AS `SEQ_CODE`,
 1 AS `CATEG_CODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pcustomer_view`
--

DROP TABLE IF EXISTS `pcustomer_view`;
/*!50001 DROP VIEW IF EXISTS `pcustomer_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pcustomer_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `VAL_ACC`,
 1 AS `NATIONAL_ID`,
 1 AS `PASSPORT`,
 1 AS `NATIONALITY`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `ID_SUBMITTED`,
 1 AS `ID_VERIFIED`,
 1 AS `PIN_NO`,
 1 AS `TERMS_SIGNED`,
 1 AS `UG_ISSUED`,
 1 AS `PREF_LANG`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `CUST_CAT`,
 1 AS `ALLOWED_PHONE_TYPE1`,
 1 AS `ALLOWED_PHONE_TYPE2`,
 1 AS `ALLOWED_PHONE_TYPE3`,
 1 AS `ALLOWED_PHONE_ID1`,
 1 AS `ALLOWED_PHONE_ID2`,
 1 AS `ALLOWED_PHONE_ID3`,
 1 AS `ALLOWED_PHONE_IDM1`,
 1 AS `ALLOWED_PHONE_IDA1`,
 1 AS `TPIN_NO`,
 1 AS `AUTH_FAIL_PIN`,
 1 AS `AUTH_FAIL_TPIN`,
 1 AS `REPORT_FREQ`,
 1 AS `CUST_EXTN1`,
 1 AS `CUST_EXTN2`,
 1 AS `CUST_EXTN3`,
 1 AS `CUST_EXTN4`,
 1 AS `INITIAL_MPIN`,
 1 AS `INITIAL_TPIN`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `CUSEXTN11`,
 1 AS `CUSEXTN12`,
 1 AS `CUSEXTN13`,
 1 AS `CUSEXTN14`,
 1 AS `CUSEXTN15`,
 1 AS `MPIN_FLDATTMPT`,
 1 AS `LAST_ATTMPTSRC`,
 1 AS `LAST_ATTMPTVER`,
 1 AS `UNLOCK_TIME`,
 1 AS `MOBILE_ACCESS`,
 1 AS `VIRTUAL_AGENCY`,
 1 AS `VIRTUAL_AGENCY_ACC`,
 1 AS `AGENCY_ID`,
 1 AS `VIRTUAL_CUSTOMER`,
 1 AS `CA_APP_ACCESS`,
 1 AS `ACCOUNT_OFFICER_ID`,
 1 AS `ACCOUNT_OFFICER_NAME`,
 1 AS `ACCSUP_NAME`,
 1 AS `MERCHANT`,
 1 AS `IB_ENABLED`,
 1 AS `IB_UID`,
 1 AS `IB_PWD`,
 1 AS `IB_DEFPWD`,
 1 AS `IB_LASTSETPWD`,
 1 AS `IB_SQ1`,
 1 AS `IB_SQ2`,
 1 AS `IB_SQ3`,
 1 AS `IB_SQ4`,
 1 AS `IB_SQ5`,
 1 AS `IB_SA1`,
 1 AS `IB_SA2`,
 1 AS `IB_SA3`,
 1 AS `IB_SA4`,
 1 AS `IB_SA5`,
 1 AS `OTP_GEN`,
 1 AS `OTP_GEN_AT`,
 1 AS `INETPWD_FLD_ATMPT`,
 1 AS `INETPWD_PWD_FLD_BLK`,
 1 AS `INETPWD_LST_FAILED_LOGINAT`,
 1 AS `INETPWD_LST_SUCCESS_LOGINAT`,
 1 AS `CORPORATE_CUSTOMER`,
 1 AS `CORPORATE_CUSTOMER_TYPE`,
 1 AS `INETB_MAKER`,
 1 AS `INETB_CHECKER`,
 1 AS `DEFAPPCIF`,
 1 AS `ORGNAME`,
 1 AS `ROLECODE`,
 1 AS `TERMSNCONDS`,
 1 AS `PREFMDOFCOMM`,
 1 AS `IBLOCKED`,
 1 AS `CPRNO`,
 1 AS `RIMNO`,
 1 AS `FBID`,
 1 AS `FBCODE`,
 1 AS `FBACTIVE`,
 1 AS `OLDSYSPWD`,
 1 AS `INET_OVRRDPWD`,
 1 AS `INET_OVRRDPWDEXP`,
 1 AS `INET_OVRRDPWDFROMDT`,
 1 AS `PIN_INVAL_CNT`,
 1 AS `PWD_INVAL_CNT`,
 1 AS `MB_LAST_LOGIN`,
 1 AS `OB_LAST_LOGIN`,
 1 AS `CUST_PREF_NAME`,
 1 AS `PIN_RLS_AT`,
 1 AS `PWD_RLS_AT`,
 1 AS `MB_CURR_LOGIN`,
 1 AS `OB_CURR_LOGIN`,
 1 AS `MB_LAST_CHANNEL`,
 1 AS `MB_CURR_CHANNEL`,
 1 AS `MPINSETDATE`,
 1 AS `TPINSETDATE`,
 1 AS `prof_mobile1`,
 1 AS `prof_mobile2`,
 1 AS `group_code`,
 1 AS `DOB`,
 1 AS `ALTPHONE`,
 1 AS `DESIG`,
 1 AS `REGBRANCH`,
 1 AS `REFBY`,
 1 AS `OTPDELV`,
 1 AS `FNAME`,
 1 AS `LNAME`,
 1 AS `CEXTN1`,
 1 AS `CEXTN2`,
 1 AS `CEXTN3`,
 1 AS `CDSCNUM`,
 1 AS `BROKER_ID`,
 1 AS `GENDER`,
 1 AS `BROKER_NAME`,
 1 AS `AKIBA_REG`,
 1 AS `AKIBA_REGAT`,
 1 AS `AKIBA_REGREF`,
 1 AS `SUB_AGENT`,
 1 AS `AGENT_NAME`,
 1 AS `AGENT_CODE`,
 1 AS `mv_pin_no`,
 1 AS `cust_type`,
 1 AS `mva_failed_atmpts`,
 1 AS `mva_initial_pin`,
 1 AS `mva_pin_no`,
 1 AS `mva_pinsetdate`,
 1 AS `mv_super_cif`,
 1 AS `mv_initial_pin`,
 1 AS `mv_failed_atmpts`,
 1 AS `mv_pinsetdate`,
 1 AS `DEBMIN`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `CATEGORY`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `custreqtrack_view`
--

DROP TABLE IF EXISTS `custreqtrack_view`;
/*!50001 DROP VIEW IF EXISTS `custreqtrack_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `custreqtrack_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `REQUEST_DATA`,
 1 AS `REQUEST_DATA1`,
 1 AS `REQUEST_DATA2`,
 1 AS `REQUEST_DATA3`,
 1 AS `REQUEST_DATA4`,
 1 AS `REQUEST_DATA5`,
 1 AS `REQUEST_STATUS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `atp_provider_view`
--

DROP TABLE IF EXISTS `atp_provider_view`;
/*!50001 DROP VIEW IF EXISTS `atp_provider_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `atp_provider_view` AS SELECT 
 1 AS `Id`,
 1 AS `ATP_NAME`,
 1 AS `ATP_ACNO`,
 1 AS `ATP_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BRANCH_CODE`,
 1 AS `CURR_CODE`,
 1 AS `PAY_TYPE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cust_auto_reg_view`
--

DROP TABLE IF EXISTS `cust_auto_reg_view`;
/*!50001 DROP VIEW IF EXISTS `cust_auto_reg_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cust_auto_reg_view` AS SELECT 
 1 AS `Id`,
 1 AS `CUST_ID`,
 1 AS `CUST_CODE1`,
 1 AS `CUST_CODE2`,
 1 AS `CUST_CODE3`,
 1 AS `CUST_CODE4`,
 1 AS `CUST_CODE5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `spcl_blr_chrg_type_range`
--

DROP TABLE IF EXISTS `spcl_blr_chrg_type_range`;
/*!50001 DROP VIEW IF EXISTS `spcl_blr_chrg_type_range`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `spcl_blr_chrg_type_range` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `CHARGE_TYPE_CODE`,
 1 AS `CHARGE_VALUE`,
 1 AS `CHARGE_VALUE2`,
 1 AS `CHARGE_VALUE3`,
 1 AS `CHARGE_VALUE4`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CURRENCY_CODE`,
 1 AS `BILLER_NAME`,
 1 AS `BILLER_TYPE`,
 1 AS `BILLER_ACNO`,
 1 AS `STATUS_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `payee_view`
--

DROP TABLE IF EXISTS `payee_view`;
/*!50001 DROP VIEW IF EXISTS `payee_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `payee_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYEE_NAME`,
 1 AS `PAYEE_ACNO`,
 1 AS `PAYER_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sysusr_info_chg_view`
--

DROP TABLE IF EXISTS `sysusr_info_chg_view`;
/*!50001 DROP VIEW IF EXISTS `sysusr_info_chg_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sysusr_info_chg_view` AS SELECT 
 1 AS `Id`,
 1 AS `ORIG_USER_ID`,
 1 AS `USER_ID`,
 1 AS `PREFIX`,
 1 AS `FIRST_NAME`,
 1 AS `MIDDLE_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `MOBILE`,
 1 AS `INSTITUTION_ID`,
 1 AS `COUNTRY`,
 1 AS `PREF_LANG`,
 1 AS `PREF_COMM`,
 1 AS `USER_ROLE_ID`,
 1 AS `GROUP_CODE`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `ROLENAME`,
 1 AS `ADMIN_PERM`,
 1 AS `MAKER_PERM`,
 1 AS `CHECKER_PERM`,
 1 AS `GLOBAL_ADMIN_PERM`,
 1 AS `REPORT_PERM`,
 1 AS `AUDIT_PERM`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ft_fail_tran_view`
--

DROP TABLE IF EXISTS `ft_fail_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ft_fail_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ft_fail_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_ACC`,
 1 AS `FROM_CIF`,
 1 AS `TO_CIF`,
 1 AS `FROM_NAME`,
 1 AS `TO_NAME`,
 1 AS `TO_ACC`,
 1 AS `FT_AMT`,
 1 AS `FT_REM`,
 1 AS `FT_RESULT`,
 1 AS `FT_RESULT_DESC`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_account_statistics_view`
--

DROP TABLE IF EXISTS `report_account_statistics_view`;
/*!50001 DROP VIEW IF EXISTS `report_account_statistics_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_account_statistics_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `STATUS`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_dth_rc_tran_view`
--

DROP TABLE IF EXISTS `ef_dth_rc_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_dth_rc_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_dth_rc_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `DTHOPERATOR`,
 1 AS `RCAMOUNT`,
 1 AS `DTHSUBSCNO`,
 1 AS `DTHTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `web_email_failed_login_view`
--

DROP TABLE IF EXISTS `web_email_failed_login_view`;
/*!50001 DROP VIEW IF EXISTS `web_email_failed_login_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `web_email_failed_login_view` AS SELECT 
 1 AS `ID`,
 1 AS `username`,
 1 AS `email`,
 1 AS `source`,
 1 AS `created_at`,
 1 AS `created_by`,
 1 AS `modified_at`,
 1 AS `modified_by`,
 1 AS `UName`,
 1 AS `Institution_id`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `atmbranch_view`
--

DROP TABLE IF EXISTS `atmbranch_view`;
/*!50001 DROP VIEW IF EXISTS `atmbranch_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `atmbranch_view` AS SELECT 
 1 AS `Id`,
 1 AS `AB_NAME`,
 1 AS `AB_ADDRESS`,
 1 AS `AB_TYPE`,
 1 AS `AB_PHONE`,
 1 AS `AB_FAX`,
 1 AS `AB_HOURS`,
 1 AS `AB_LONG`,
 1 AS `AB_LATT`,
 1 AS `AB_MGR`,
 1 AS `AB_CITY`,
 1 AS `AB_REGION`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `DIST`,
 1 AS `LANG_CODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `joint_account_request_view`
--

DROP TABLE IF EXISTS `joint_account_request_view`;
/*!50001 DROP VIEW IF EXISTS `joint_account_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `joint_account_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NO`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MANDATE_COUNT`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agent_otp_view`
--

DROP TABLE IF EXISTS `agent_otp_view`;
/*!50001 DROP VIEW IF EXISTS `agent_otp_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agent_otp_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `OTP`,
 1 AS `OTP_TS`,
 1 AS `MOBILE`,
 1 AS `ACCOUNT`,
 1 AS `AMOUNT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REFID`,
 1 AS `CNAME`,
 1 AS `AGID`,
 1 AS `AGNAME`,
 1 AS `AGUAT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `otp_source`,
 1 AS `EXTN1_FLD`,
 1 AS `EXTN2_FLD`,
 1 AS `EXTN3_FLD`,
 1 AS `EXTN4_FLD`,
 1 AS `EXTN5_FLD`,
 1 AS `INSTITUTION_ID`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `corp_sr_add_accnt_req_view`
--

DROP TABLE IF EXISTS `corp_sr_add_accnt_req_view`;
/*!50001 DROP VIEW IF EXISTS `corp_sr_add_accnt_req_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `corp_sr_add_accnt_req_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `REGACCOUNTNO`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_data_update_view`
--

DROP TABLE IF EXISTS `customer_data_update_view`;
/*!50001 DROP VIEW IF EXISTS `customer_data_update_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_data_update_view` AS SELECT 
 1 AS `Id`,
 1 AS `CUST_RECORD_ID`,
 1 AS `ALLOWED_PHONE_ID1`,
 1 AS `ALLOWED_PHONE_ID2`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `NATIONAL_ID`,
 1 AS `PASSPORT`,
 1 AS `NATIONALITY`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `PREF_LANG`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CUST_CAT`,
 1 AS `IB_SQ1`,
 1 AS `IB_SQ2`,
 1 AS `IB_SQ3`,
 1 AS `IB_SQ4`,
 1 AS `IB_SQ5`,
 1 AS `IB_SA1`,
 1 AS `IB_SA2`,
 1 AS `IB_SA3`,
 1 AS `IB_SA4`,
 1 AS `IB_SA5`,
 1 AS `ORIG_MOBILE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `grp_code`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `online_access_request_view`
--

DROP TABLE IF EXISTS `online_access_request_view`;
/*!50001 DROP VIEW IF EXISTS `online_access_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `online_access_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `ROLE`,
 1 AS `PREFMDOFCOMM`,
 1 AS `REQUEST_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_airtime`
--

DROP TABLE IF EXISTS `report_airtime`;
/*!50001 DROP VIEW IF EXISTS `report_airtime`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_airtime` AS SELECT 
 1 AS `FROM_ACCOUNT`,
 1 AS `TO_ACCOUNT`,
 1 AS `REF_NO`,
 1 AS `CUSTOMER_ID`,
 1 AS `CUST_MOBILE`,
 1 AS `FT_TYPE`,
 1 AS `DATEVAL`,
 1 AS `VENDOR_RESPONSE`,
 1 AS `RSTATUS`,
 1 AS `AMOUNT`,
 1 AS `CUST_REF2`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agency_info_stg_view`
--

DROP TABLE IF EXISTS `agency_info_stg_view`;
/*!50001 DROP VIEW IF EXISTS `agency_info_stg_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agency_info_stg_view` AS SELECT 
 1 AS `Id`,
 1 AS `MOBILE`,
 1 AS `ACC_NUM`,
 1 AS `NATIONALID`,
 1 AS `BRANCHCODE`,
 1 AS `BR_AGENT_CODE`,
 1 AS `AGENTID`,
 1 AS `TARIFFID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXPIRY_AT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `beneficiary_view`
--

DROP TABLE IF EXISTS `beneficiary_view`;
/*!50001 DROP VIEW IF EXISTS `beneficiary_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `beneficiary_view` AS SELECT 
 1 AS `Id`,
 1 AS `BENEFICIARY_NAME`,
 1 AS `BENEFICIARY_ACNO`,
 1 AS `BENEFICIARY_TYPE`,
 1 AS `CUSTOMER_ID`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BANK_CODE`,
 1 AS `BRANCH`,
 1 AS `BENEMOBILE`,
 1 AS `BENECURR`,
 1 AS `CMT`,
 1 AS `EXTN1`,
 1 AS `benemail`,
 1 AS `benalias`,
 1 AS `bencomnt`,
 1 AS `IBAN`,
 1 AS `BENCOUNTRY`,
 1 AS `BENSWIFTCODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_mob_ftr_usage_stat_view`
--

DROP TABLE IF EXISTS `rep_mob_ftr_usage_stat_view`;
/*!50001 DROP VIEW IF EXISTS `rep_mob_ftr_usage_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_mob_ftr_usage_stat_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `ACTION_MESG`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_non_login_functionality`
--

DROP TABLE IF EXISTS `report_non_login_functionality`;
/*!50001 DROP VIEW IF EXISTS `report_non_login_functionality`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_non_login_functionality` AS SELECT 
 1 AS `MTOADDR`,
 1 AS `MSUBJECT`,
 1 AS `MMESSAGE`,
 1 AS `MESGQIN`,
 1 AS `MESGQOUT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `nfc_tag_view`
--

DROP TABLE IF EXISTS `nfc_tag_view`;
/*!50001 DROP VIEW IF EXISTS `nfc_tag_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `nfc_tag_view` AS SELECT 
 1 AS `Id`,
 1 AS `TAGCODE`,
 1 AS `CUST_ID`,
 1 AS `ACC_NUM`,
 1 AS `TAG_CATEGORY`,
 1 AS `FROM_DATE`,
 1 AS `TO_DATE`,
 1 AS `TAG_STATUS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `retail_self_reg_add_accnt_request_view`
--

DROP TABLE IF EXISTS `retail_self_reg_add_accnt_request_view`;
/*!50001 DROP VIEW IF EXISTS `retail_self_reg_add_accnt_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `retail_self_reg_add_accnt_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `REGACCOUNTNO`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sysuser_reqeust_view`
--

DROP TABLE IF EXISTS `sysuser_reqeust_view`;
/*!50001 DROP VIEW IF EXISTS `sysuser_reqeust_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sysuser_reqeust_view` AS SELECT 
 1 AS `Id`,
 1 AS `USER_REC_ID`,
 1 AS `USER_ID`,
 1 AS `UNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_DESC`,
 1 AS `REQUEST_STATUS`,
 1 AS `REQUEST_CHG_DESC`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `content_map_view`
--

DROP TABLE IF EXISTS `content_map_view`;
/*!50001 DROP VIEW IF EXISTS `content_map_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `content_map_view` AS SELECT 
 1 AS `Id`,
 1 AS `CCATG`,
 1 AS `CTYPE`,
 1 AS `CCODE`,
 1 AS `CVALUE`,
 1 AS `INSTITUTION_ID`,
 1 AS `CSEQ`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `USSD`,
 1 AS `WAP`,
 1 AS `MOBILE_ACCESS_CODE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `WEB_UI_CODE`,
 1 AS `CA_APP_ACCESS`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bulk_payment_approver_view`
--

DROP TABLE IF EXISTS `bulk_payment_approver_view`;
/*!50001 DROP VIEW IF EXISTS `bulk_payment_approver_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bulk_payment_approver_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `REG_CUST_ID`,
 1 AS `REG_CUST_NAME`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CUST_NAME`,
 1 AS `MANDATORY`,
 1 AS `ROLE_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `OTP_GEN`,
 1 AS `OTP_EXP`,
 1 AS `max_approval_amount`,
 1 AS `SEQ_CODE`,
 1 AS `CATEG_CODE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ret_sr_add_accnt_req_view`
--

DROP TABLE IF EXISTS `ret_sr_add_accnt_req_view`;
/*!50001 DROP VIEW IF EXISTS `ret_sr_add_accnt_req_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ret_sr_add_accnt_req_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `REGACCOUNTNO`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cust_act_audit_view`
--

DROP TABLE IF EXISTS `cust_act_audit_view`;
/*!50001 DROP VIEW IF EXISTS `cust_act_audit_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cust_act_audit_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CHANNEL`,
 1 AS `SCREEN`,
 1 AS `ACTION_AT`,
 1 AS `REQ_SOURCE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cif_mobile_view`
--

DROP TABLE IF EXISTS `cif_mobile_view`;
/*!50001 DROP VIEW IF EXISTS `cif_mobile_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cif_mobile_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CNAME`,
 1 AS `CURR_PIN`,
 1 AS `PRIMARY_ACC`,
 1 AS `NEW_PIN`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `charge_type_range_archive_view`
--

DROP TABLE IF EXISTS `charge_type_range_archive_view`;
/*!50001 DROP VIEW IF EXISTS `charge_type_range_archive_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `charge_type_range_archive_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHARGE_TYPE_ID`,
 1 AS `SERVICE_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `CHARGE_TYPE_CODE`,
 1 AS `CHARGE_VALUE`,
 1 AS `CHARGE_VALUE2`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `ARCHIVED_BY`,
 1 AS `ARCHIVED_AT`,
 1 AS `ARCHIVE_CMT`,
 1 AS `CHARGE_TYPE`,
 1 AS `INAME`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customer_list`
--

DROP TABLE IF EXISTS `report_customer_list`;
/*!50001 DROP VIEW IF EXISTS `report_customer_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customer_list` AS SELECT 
 1 AS `CREATED_AT`,
 1 AS `RSTATUS`,
 1 AS `MODIFIED_AT`,
 1 AS `MADE_BY`,
 1 AS `CHECKED_BY`,
 1 AS `EMAIL`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `NATIONAL_ID`,
 1 AS `MOBILE`,
 1 AS `NATIONALITY`,
 1 AS `CUST_CAT`,
 1 AS `INSTITUTION`,
 1 AS `ACC_NUM`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `biller_view`
--

DROP TABLE IF EXISTS `biller_view`;
/*!50001 DROP VIEW IF EXISTS `biller_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `biller_view` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_NAME`,
 1 AS `BILLER_ACNO`,
 1 AS `BILLER_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `FLD1NAME`,
 1 AS `FLD2NAME`,
 1 AS `FLD3NAME`,
 1 AS `FLD4NAME`,
 1 AS `FLD5NAME`,
 1 AS `FLD1CODE`,
 1 AS `FLD2CODE`,
 1 AS `FLD3CODE`,
 1 AS `FLD4CODE`,
 1 AS `FLD5CODE`,
 1 AS `FLD1TYPE`,
 1 AS `FLD2TYPE`,
 1 AS `FLD3TYPE`,
 1 AS `FLD4TYPE`,
 1 AS `FLD5TYPE`,
 1 AS `MIN_TRAN_AMT`,
 1 AS `MAX_TRAN_AMT`,
 1 AS `DLY_TRAN_AMT`,
 1 AS `BRANCH_CODE`,
 1 AS `CURR_CODE`,
 1 AS `PAY_TYPE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bulk_payment_master_view`
--

DROP TABLE IF EXISTS `bulk_payment_master_view`;
/*!50001 DROP VIEW IF EXISTS `bulk_payment_master_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bulk_payment_master_view` AS SELECT 
 1 AS `Id`,
 1 AS `FILE_NAME`,
 1 AS `NO_OF_REC`,
 1 AS `TOTAL_AMOUNT`,
 1 AS `STATUS`,
 1 AS `BATCH_CODE`,
 1 AS `SERVICE_TITLE`,
 1 AS `REQ_CIF`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `retail_self_reg_request_view`
--

DROP TABLE IF EXISTS `retail_self_reg_request_view`;
/*!50001 DROP VIEW IF EXISTS `retail_self_reg_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `retail_self_reg_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `PREFNAME`,
 1 AS `EMPLOYER`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `NATIONALID`,
 1 AS `NATIONALITY`,
 1 AS `REGACCOUNTNO`,
 1 AS `NEEDOLBACCESS`,
 1 AS `NEEDMBACCESS`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `ROLE`,
 1 AS `DEFAPPCIF`,
 1 AS `DEFAPPCIFNAME`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `JNTACCAPPCIF1NAME`,
 1 AS `JNTACCAPPCIF2NAME`,
 1 AS `JNTACCAPPCIF3NAME`,
 1 AS `JNTACCAPPCIF4NAME`,
 1 AS `JNTACCAPPCIF5NAME`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `BULKAPPCIF1NAME`,
 1 AS `BULKAPPCIF2NAME`,
 1 AS `BULKAPPCIF3NAME`,
 1 AS `JNTACCAPPCIF1MA`,
 1 AS `JNTACCAPPCIF2MA`,
 1 AS `JNTACCAPPCIF3MA`,
 1 AS `JNTACCAPPCIF4MA`,
 1 AS `JNTACCAPPCIF5MA`,
 1 AS `BULKAPPCIF1MA`,
 1 AS `BULKAPPCIF2MA`,
 1 AS `BULKAPPCIF3MA`,
 1 AS `JNTACCAPPCIF1MNDAPP`,
 1 AS `JNTACCAPPCIF2MNDAPP`,
 1 AS `JNTACCAPPCIF3MNDAPP`,
 1 AS `JNTACCAPPCIF4MNDAPP`,
 1 AS `JNTACCAPPCIF5MNDAPP`,
 1 AS `BULKAPPCIF1MNDAPP`,
 1 AS `BULKAPPCIF2MNDAPP`,
 1 AS `BULKAPPCIF3MNDAPP`,
 1 AS `SECQ1`,
 1 AS `SECQ2`,
 1 AS `SECQ3`,
 1 AS `SECA1`,
 1 AS `SECA2`,
 1 AS `SECA3`,
 1 AS `PREFMDOFCOMM`,
 1 AS `REQUEST_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `dnd_time_view`
--

DROP TABLE IF EXISTS `dnd_time_view`;
/*!50001 DROP VIEW IF EXISTS `dnd_time_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dnd_time_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `MOBILE_NUMBER`,
 1 AS `APPLY_FOR_ALL`,
 1 AS `FROM_DATE`,
 1 AS `TO_DATE`,
 1 AS `FROM_TIME`,
 1 AS `TO_TIME`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_customer_acquisition`
--

DROP TABLE IF EXISTS `view_customer_acquisition`;
/*!50001 DROP VIEW IF EXISTS `view_customer_acquisition`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_customer_acquisition` AS SELECT 
 1 AS `FIRST_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `ACCOUNT_TYPE`,
 1 AS `CUST_MOBILE`,
 1 AS `AGENT_NAME`,
 1 AS `AG_MOBILE`,
 1 AS `STATUS`,
 1 AS `REG_STATUS`,
 1 AS `CREATED_AT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_systemuser_list`
--

DROP TABLE IF EXISTS `report_systemuser_list`;
/*!50001 DROP VIEW IF EXISTS `report_systemuser_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_systemuser_list` AS SELECT 
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `FIRST_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `MOBILE`,
 1 AS `USER_ROLE_ID`,
 1 AS `MADE_BY`,
 1 AS `CHECKED_BY`,
 1 AS `RSTATUS`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `user_role_view`
--

DROP TABLE IF EXISTS `user_role_view`;
/*!50001 DROP VIEW IF EXISTS `user_role_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `user_role_view` AS SELECT 
 1 AS `Id`,
 1 AS `ROLENAME`,
 1 AS `ADMIN_PERM`,
 1 AS `MAKER_PERM`,
 1 AS `CHECKER_PERM`,
 1 AS `GLOBAL_ADMIN_PERM`,
 1 AS `REPORT_PERM`,
 1 AS `AUDIT_PERM`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ticket_comment_view`
--

DROP TABLE IF EXISTS `ticket_comment_view`;
/*!50001 DROP VIEW IF EXISTS `ticket_comment_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ticket_comment_view` AS SELECT 
 1 AS `Id`,
 1 AS `TICKET_ID`,
 1 AS `TDESC`,
 1 AS `NEW_STATUS`,
 1 AS `NEW_ASSIGNEE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `GROUP_CODE`,
 1 AS `COMMENTOR_ID`,
 1 AS `COMMENTOR_NAME`,
 1 AS `COMMENTOR_AT`,
 1 AS `SOURCE_IP`,
 1 AS `NEW_PRSEQ`,
 1 AS `NEW_RECEST`,
 1 AS `NEW_RESEST`,
 1 AS `NEW_ESTIMATE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `other_bank_branch_view`
--

DROP TABLE IF EXISTS `other_bank_branch_view`;
/*!50001 DROP VIEW IF EXISTS `other_bank_branch_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `other_bank_branch_view` AS SELECT 
 1 AS `Id`,
 1 AS `BANK_ID`,
 1 AS `BRANCH_CODE`,
 1 AS `BRANCH_NAME`,
 1 AS `SWIFT_CODE`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `corporate_view`
--

DROP TABLE IF EXISTS `corporate_view`;
/*!50001 DROP VIEW IF EXISTS `corporate_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `corporate_view` AS SELECT 
 1 AS `Id`,
 1 AS `CORPORATE_ID`,
 1 AS `CORPORATE_NAME`,
 1 AS `CONTACT_PERSON_NAME`,
 1 AS `CONTACT_PERSON_MOBILE`,
 1 AS `CONTACT_PERSON_EMAIL`,
 1 AS `REQUEST_IP`,
 1 AS `REMARKS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `paccount_view`
--

DROP TABLE IF EXISTS `paccount_view`;
/*!50001 DROP VIEW IF EXISTS `paccount_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `paccount_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CURRENCY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `REPORT_FREQ`,
 1 AS `ALLOW_SMS`,
 1 AS `ALLOW_EMAIL`,
 1 AS `SMS_THRES`,
 1 AS `EMAIL_THRES`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `ADDTNL_SMS1`,
 1 AS `ADDTNL_SMS2`,
 1 AS `ADDTNL_SMS3`,
 1 AS `ADDTNL_SMS4`,
 1 AS `ADDTNL_SMS5`,
 1 AS `ACCEXTN1`,
 1 AS `ACCEXTN2`,
 1 AS `ACCEXTN3`,
 1 AS `ACCEXTN4`,
 1 AS `ACCEXTN5`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `CURR_BALANCE`,
 1 AS `CURR_BALANCE_TYPE`,
 1 AS `CURR_BAL_LASTUPD`,
 1 AS `BRANCH_CODE`,
 1 AS `ALLOW_MOBILE`,
 1 AS `VIRTUAL_ACCOUNT`,
 1 AS `ALT_ACC_ID`,
 1 AS `AH_CB_NAME`,
 1 AS `AH_CIF_NAME`,
 1 AS `JOINT_ACCOUNT`,
 1 AS `JOINT_ACCOUNT_MANDATES`,
 1 AS `PRIMARY_ACCOUNT`,
 1 AS `group_code`,
 1 AS `CRDMIN`,
 1 AS `DEBMIN`,
 1 AS `ALSALCR`,
 1 AS `ALCHQDEP`,
 1 AS `ALODAM`,
 1 AS `ALATM`,
 1 AS `ACCCTYPE`,
 1 AS `STMT_PRTY`,
 1 AS `CNAME`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customer_statistics_view`
--

DROP TABLE IF EXISTS `report_customer_statistics_view`;
/*!50001 DROP VIEW IF EXISTS `report_customer_statistics_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customer_statistics_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `CATEGORY`,
 1 AS `STATUS`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cust_acq_view`
--

DROP TABLE IF EXISTS `cust_acq_view`;
/*!50001 DROP VIEW IF EXISTS `cust_acq_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cust_acq_view` AS SELECT 
 1 AS `Id`,
 1 AS `SALUTN`,
 1 AS `FIRST_NAME`,
 1 AS `MIDDLE_NAME`,
 1 AS `LAST_NAME`,
 1 AS `EMAIL`,
 1 AS `IMG1`,
 1 AS `IMG2`,
 1 AS `IMG3`,
 1 AS `IMG4`,
 1 AS `IMG5`,
 1 AS `SHORT_NAME`,
 1 AS `CUST_TYPE`,
 1 AS `ADDR_TYPE`,
 1 AS `COMM_TYPE`,
 1 AS `DEV_NO`,
 1 AS `DOC_ID`,
 1 AS `REF_NO`,
 1 AS `SEC_ANA_TYPE`,
 1 AS `ORG_CLASSF`,
 1 AS `ES_CLASSF`,
 1 AS `AN_TYPE`,
 1 AS `AN_CODE`,
 1 AS `NATIONAL_ID`,
 1 AS `MOBILE`,
 1 AS `DOB`,
 1 AS `ADDRESS`,
 1 AS `SUBMIT_AG_NAME`,
 1 AS `AG_MOBILE`,
 1 AS `CA_STATUS`,
 1 AS `REG_STATUS`,
 1 AS `REQ_CATEG`,
 1 AS `CURR_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `ID1Checked`,
 1 AS `ID2Checked`,
 1 AS `PhotoChecked`,
 1 AS `SignatureChecked`,
 1 AS `IPRSChecked`,
 1 AS `CBCUST_ID`,
 1 AS `CBACCNUM1`,
 1 AS `CBACCNUM2`,
 1 AS `CBACCNUM3`,
 1 AS `CBACCNUM4`,
 1 AS `RESULTCODE`,
 1 AS `RESULTDESC`,
 1 AS `BRANCH_ID`,
 1 AS `ADDR`,
 1 AS `NATURE_OF_BUS`,
 1 AS `AGENT_CODE`,
 1 AS `AGENT_CAT`,
 1 AS `DATE_CODE`,
 1 AS `ACCOUNT_OFFICER_ID`,
 1 AS `ACCOUNT_OFFICER_NAME`,
 1 AS `NATIONAL_ID_CHECKED`,
 1 AS `TIN`,
 1 AS `RES_TYPE`,
 1 AS `MAR_STATUS`,
 1 AS `EMPLOYER`,
 1 AS `ZIPCODE`,
 1 AS `CURRENCY`,
 1 AS `NATIONALITY`,
 1 AS `ADDR1`,
 1 AS `ADDR2`,
 1 AS `ADDR3`,
 1 AS `ADDR4`,
 1 AS `GENDER`,
 1 AS `CHILDCNT`,
 1 AS `OTPGEN`,
 1 AS `OTPEXP`,
 1 AS `OTPCONFIRMED`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `user_request_view`
--

DROP TABLE IF EXISTS `user_request_view`;
/*!50001 DROP VIEW IF EXISTS `user_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `user_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `USERRECID`,
 1 AS `USERID`,
 1 AS `UNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `funds_tran_tran_view`
--

DROP TABLE IF EXISTS `funds_tran_tran_view`;
/*!50001 DROP VIEW IF EXISTS `funds_tran_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `funds_tran_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `FTFROM`,
 1 AS `FTTO`,
 1 AS `FTAMOUNT`,
 1 AS `FTRESULT`,
 1 AS `FTCURRCODE`,
 1 AS `FTCHARGE`,
 1 AS `FTTRANTIME`,
 1 AS `FTCIF`,
 1 AS `FTSOURCE`,
 1 AS `FTPHONEID`,
 1 AS `FTSESSIONID`,
 1 AS `FTREFNO`,
 1 AS `FTRESULTCODE`,
 1 AS `ERRMSG`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `FTTYPE`,
 1 AS `FTSUBCHARGE`,
 1 AS `FTSTEPFAILED`,
 1 AS `RESP1`,
 1 AS `RESP2`,
 1 AS `RESP3`,
 1 AS `RESP4`,
 1 AS `FTCOMMENT`,
 1 AS `RESULTCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `service_access_view`
--

DROP TABLE IF EXISTS `service_access_view`;
/*!50001 DROP VIEW IF EXISTS `service_access_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `service_access_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHARGE_TYPE_ID`,
 1 AS `SERVICE_ID`,
 1 AS `ACTIVE_FLAG`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CHARGE_TYPE`,
 1 AS `INAME`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mpesa_tran_view`
--

DROP TABLE IF EXISTS `mpesa_tran_view`;
/*!50001 DROP VIEW IF EXISTS `mpesa_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mpesa_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `MPID`,
 1 AS `ORIG`,
 1 AS `DEST`,
 1 AS `TSTAMP`,
 1 AS `MPTEXT`,
 1 AS `MPUSER`,
 1 AS `MPPASS`,
 1 AS `MPCODE`,
 1 AS `MPCUSTID`,
 1 AS `MPRTMETHODID`,
 1 AS `MPRTMETHODNAME`,
 1 AS `MPACC`,
 1 AS `MPISDN`,
 1 AS `MPTDATE`,
 1 AS `MPTTIME`,
 1 AS `MPTAMT`,
 1 AS `MPSENDER`,
 1 AS `MPRESP`,
 1 AS `MPERRMSG`,
 1 AS `BANKCHARGES`,
 1 AS `SAFARICOMCHARGES`,
 1 AS `RCVBTRNSRESULT_CODE`,
 1 AS `RCVBTRNSRESULT`,
 1 AS `RCVBTRNSTS`,
 1 AS `RCVBTRNSAMT`,
 1 AS `CUSTTRNSRESULT_CODE`,
 1 AS `CUSTTRNSRESULT`,
 1 AS `CUSTTRNSTS`,
 1 AS `CUSTTRNSAMT`,
 1 AS `BANKCHRGRESULT_CODE`,
 1 AS `BANKCHRGRESULT`,
 1 AS `BANKCHRGTS`,
 1 AS `BANKCHRGAMT`,
 1 AS `MPESACHRGRESULT_CODE`,
 1 AS `MPESACHRGRESULT`,
 1 AS `MPESACHRGTS`,
 1 AS `MPESACHRGAMT`,
 1 AS `SUSPENSERESULT_CODE`,
 1 AS `SUSPENSERESULT`,
 1 AS `SUSPENSECHRGTS`,
 1 AS `SUSPENSECHRGAMT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `STATUS_DESC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_SOURCE_IP`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `employer_view`
--

DROP TABLE IF EXISTS `employer_view`;
/*!50001 DROP VIEW IF EXISTS `employer_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `employer_view` AS SELECT 
 1 AS `Id`,
 1 AS `EMPLOYER_ID`,
 1 AS `EMPLOYER_NAME`,
 1 AS `OTHER_INFO`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `health_check_view`
--

DROP TABLE IF EXISTS `health_check_view`;
/*!50001 DROP VIEW IF EXISTS `health_check_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `health_check_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHECK_TITLE`,
 1 AS `CHECK_CODE`,
 1 AS `CHECK_CLASS`,
 1 AS `CHECK_METHOD`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CHECK_ID`,
 1 AS `CHECK_TS`,
 1 AS `CHECK_STATUS`,
 1 AS `CHECK_STATUS_MESSAGE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `charge_type_range_view`
--

DROP TABLE IF EXISTS `charge_type_range_view`;
/*!50001 DROP VIEW IF EXISTS `charge_type_range_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `charge_type_range_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHARGE_TYPE_ID`,
 1 AS `SERVICE_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `CHARGE_TYPE_CODE`,
 1 AS `CHARGE_VALUE`,
 1 AS `CHARGE_VALUE2`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CURRENCY_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHARGE_TYPE`,
 1 AS `INAME`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `misc_request_view`
--

DROP TABLE IF EXISTS `misc_request_view`;
/*!50001 DROP VIEW IF EXISTS `misc_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `misc_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `REQUEST_CODE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `EXTN11`,
 1 AS `EXTN12`,
 1 AS `EXTN13`,
 1 AS `EXTN14`,
 1 AS `EXTN15`,
 1 AS `INSTITUTION_ID`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CURR_APP_STATUS`,
 1 AS `made_by`,
 1 AS `made_at`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_tran_limits_view`
--

DROP TABLE IF EXISTS `customer_tran_limits_view`;
/*!50001 DROP VIEW IF EXISTS `customer_tran_limits_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_tran_limits_view` AS SELECT 
 1 AS `Id`,
 1 AS `CUST_ID`,
 1 AS `MIN_TRAN_AMOUNT`,
 1 AS `MAX_TRAN_AMOUNT`,
 1 AS `MAX_FREQUENCY`,
 1 AS `DAILY_AMT_LIMIT`,
 1 AS `LIMIT_TYPE`,
 1 AS `TRAN_TYPE_CODE`,
 1 AS `TRAN_TYPE_DESC`,
 1 AS `TEMP_START_DATE`,
 1 AS `TEMP_END_DATE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ticket_status_view`
--

DROP TABLE IF EXISTS `ticket_status_view`;
/*!50001 DROP VIEW IF EXISTS `ticket_status_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ticket_status_view` AS SELECT 
 1 AS `Id`,
 1 AS `TICKET_ID`,
 1 AS `TNEWSTATUSCMNT`,
 1 AS `TNEWSTATUS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `GROUP_CODE`,
 1 AS `COMMENTOR_ID`,
 1 AS `COMMENTOR_NAME`,
 1 AS `COMMENTOR_AT`,
 1 AS `SOURCE_IP`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_mobile_bp_tran_view`
--

DROP TABLE IF EXISTS `ef_mobile_bp_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_mobile_bp_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_mobile_bp_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `RCOPERATOR`,
 1 AS `RCAMOUNT`,
 1 AS `RCMOBILE`,
 1 AS `RCTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `alert_rule_view`
--

DROP TABLE IF EXISTS `alert_rule_view`;
/*!50001 DROP VIEW IF EXISTS `alert_rule_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `alert_rule_view` AS SELECT 
 1 AS `Id`,
 1 AS `TRANSACTION`,
 1 AS `RULE_FLD1`,
 1 AS `RULE_FLD2`,
 1 AS `RULE_FLD3`,
 1 AS `RULE_FLD4`,
 1 AS `RULE_FLD5`,
 1 AS `RULE_FLD6`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_mob_user_usage_stat_view`
--

DROP TABLE IF EXISTS `rep_mob_user_usage_stat_view`;
/*!50001 DROP VIEW IF EXISTS `rep_mob_user_usage_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_mob_user_usage_stat_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `airtime_voucher_view`
--

DROP TABLE IF EXISTS `airtime_voucher_view`;
/*!50001 DROP VIEW IF EXISTS `airtime_voucher_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `airtime_voucher_view` AS SELECT 
 1 AS `Id`,
 1 AS `PROVIDER`,
 1 AS `AIRTIME_CODE`,
 1 AS `AIRTIME_VALUE`,
 1 AS `CURRENCY`,
 1 AS `EXPIRY_AT`,
 1 AS `INT_DATA_VALUE`,
 1 AS `ALLOTED_MOBILE`,
 1 AS `ALLOTED_AT`,
 1 AS `ALLOTED_CHANNEL`,
 1 AS `AIRTIME_STATUS`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `SERIAL_NO`,
 1 AS `BATCH_NO`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_gs_bp_tran_view`
--

DROP TABLE IF EXISTS `ef_gs_bp_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_gs_bp_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_gs_bp_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYMENT_REF`,
 1 AS `BPOPERATOR`,
 1 AS `BPAMOUNT`,
 1 AS `BPNUM`,
 1 AS `BPTYPE`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `RCTRAN_RESULT_CODE`,
 1 AS `RCTRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sb_event_stat_view`
--

DROP TABLE IF EXISTS `sb_event_stat_view`;
/*!50001 DROP VIEW IF EXISTS `sb_event_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sb_event_stat_view` AS SELECT 
 1 AS `Id`,
 1 AS `EVENT_ID`,
 1 AS `TBP_FBID`,
 1 AS `TBP_FBNAME`,
 1 AS `TBP_MAIL`,
 1 AS `TBP_MOBILE`,
 1 AS `TBP_STATUS`,
 1 AS `REMINDERS_SENT`,
 1 AS `LAST_REM_AT`,
 1 AS `TBP_COMMENTS`,
 1 AS `TBP_VOUCHER`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `TBP_AMT`,
 1 AS `event_name`,
 1 AS `event_status`,
 1 AS `event_category`,
 1 AS `event_split_type`,
 1 AS `event_paidcnt`,
 1 AS `event_pendingcnt`,
 1 AS `event_frndcnt`,
 1 AS `event_amt`,
 1 AS `event_createts`,
 1 AS `event_desc`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bond_reg_dtl_view`
--

DROP TABLE IF EXISTS `bond_reg_dtl_view`;
/*!50001 DROP VIEW IF EXISTS `bond_reg_dtl_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bond_reg_dtl_view` AS SELECT 
 1 AS `Id`,
 1 AS `FNAME`,
 1 AS `LNAME`,
 1 AS `MOBILE`,
 1 AS `VIR_ACC_NUM`,
 1 AS `INV_ACC_NUM`,
 1 AS `DOB`,
 1 AS `CIF`,
 1 AS `PIN`,
 1 AS `MESSAGE`,
 1 AS `LOAN_TERM`,
 1 AS `REG_STATUS`,
 1 AS `NATIONAL_ID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `remember_me_view`
--

DROP TABLE IF EXISTS `remember_me_view`;
/*!50001 DROP VIEW IF EXISTS `remember_me_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `remember_me_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `FEATURE_CODE`,
 1 AS `PARAMS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `intf_call_log_view`
--

DROP TABLE IF EXISTS `intf_call_log_view`;
/*!50001 DROP VIEW IF EXISTS `intf_call_log_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `intf_call_log_view` AS SELECT 
 1 AS `Id`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_MAP_ID`,
 1 AS `REQUEST_MAP`,
 1 AS `MESSAGE`,
 1 AS `RESULT`,
 1 AS `REQUEST_TS`,
 1 AS `RESPONSE_TS`,
 1 AS `ERROR_MESG`,
 1 AS `CHARGES`,
 1 AS `REQUESTOR_ID`,
 1 AS `SESSION_ID`,
 1 AS `REQUEST_SOURCE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `RESPONSE_MAP`,
 1 AS `CUST_NAME`,
 1 AS `CID`,
 1 AS `dateval`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ft_request_view`
--

DROP TABLE IF EXISTS `ft_request_view`;
/*!50001 DROP VIEW IF EXISTS `ft_request_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ft_request_view` AS SELECT 
 1 AS `Id`,
 1 AS `FROM_ACC`,
 1 AS `FROM_CIF`,
 1 AS `TO_CIF`,
 1 AS `FROM_NAME`,
 1 AS `TO_NAME`,
 1 AS `TO_ACC`,
 1 AS `FT_AMT`,
 1 AS `FT_REM`,
 1 AS `FT_RESULT`,
 1 AS `FT_RESULT_DESC`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mvisa_merchant_view`
--

DROP TABLE IF EXISTS `mvisa_merchant_view`;
/*!50001 DROP VIEW IF EXISTS `mvisa_merchant_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mvisa_merchant_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `IDNUM`,
 1 AS `PINNUM`,
 1 AS `MOBILE`,
 1 AS `IDPRESENT`,
 1 AS `SIGNOK`,
 1 AS `POST_ADDR`,
 1 AS `BUS_NAME`,
 1 AS `BUS_PIN`,
 1 AS `BUS_TYPE`,
 1 AS `BUS_CODE`,
 1 AS `BUS_LOC`,
 1 AS `BUS_PSTADDR`,
 1 AS `BUS_PSTCODE`,
 1 AS `ISBUS_PIN_PRE`,
 1 AS `BUS_CERT`,
 1 AS `BANK_CODE`,
 1 AS `BRANCH_CODE`,
 1 AS `BANK_ACC_NUM`,
 1 AS `MERC_DISC_RATE`,
 1 AS `MERC_FULL_ID`,
 1 AS `MERC_ID`,
 1 AS `NOTF_METHOD`,
 1 AS `NOTF_DEVID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `PUSH_URL`,
 1 AS `ALIAS_NAME`,
 1 AS `PRIMARY_CARD`,
 1 AS `MERC_PWD`,
 1 AS `NOTIF_MAIL`,
 1 AS `MERC_INIT_PWD`,
 1 AS `addtn_mob1`,
 1 AS `addtn_mob2`,
 1 AS `addtn_mob3`,
 1 AS `addtn_mob4`,
 1 AS `addtn_mob5`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `service_list_view`
--

DROP TABLE IF EXISTS `service_list_view`;
/*!50001 DROP VIEW IF EXISTS `service_list_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `service_list_view` AS SELECT 
 1 AS `Id`,
 1 AS `SCODE`,
 1 AS `SNAME`,
 1 AS `SCATG`,
 1 AS `SCATG1`,
 1 AS `SCATG2`,
 1 AS `SPARENT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `ACTIVE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `web_login_failed_login_view`
--

DROP TABLE IF EXISTS `web_login_failed_login_view`;
/*!50001 DROP VIEW IF EXISTS `web_login_failed_login_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `web_login_failed_login_view` AS SELECT 
 1 AS `ID`,
 1 AS `username`,
 1 AS `email`,
 1 AS `source`,
 1 AS `created_at`,
 1 AS `created_by`,
 1 AS `modified_at`,
 1 AS `modified_by`,
 1 AS `UName`,
 1 AS `Institution_id`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customers_estatements`
--

DROP TABLE IF EXISTS `report_customers_estatements`;
/*!50001 DROP VIEW IF EXISTS `report_customers_estatements`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customers_estatements` AS SELECT 
 1 AS `cname`,
 1 AS `val_acc`,
 1 AS `branch`,
 1 AS `national_id`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_systemuser_creation_history`
--

DROP TABLE IF EXISTS `report_systemuser_creation_history`;
/*!50001 DROP VIEW IF EXISTS `report_systemuser_creation_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_systemuser_creation_history` AS SELECT 
 1 AS `USERNAME`,
 1 AS `ROLE`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rtl_sr_add_accnt_request`
--

DROP TABLE IF EXISTS `rtl_sr_add_accnt_request`;
/*!50001 DROP VIEW IF EXISTS `rtl_sr_add_accnt_request`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rtl_sr_add_accnt_request` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `MOBILE`,
 1 AS `REGACCOUNTNO`,
 1 AS `JNTACCOUNT`,
 1 AS `MANDCNT`,
 1 AS `JNTACCAPPCIF1`,
 1 AS `JNTACCAPPCIF2`,
 1 AS `JNTACCAPPCIF3`,
 1 AS `JNTACCAPPCIF4`,
 1 AS `JNTACCAPPCIF5`,
 1 AS `BULKAPPCIF1`,
 1 AS `BULKAPPCIF2`,
 1 AS `BULKAPPCIF3`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `charge_type_view`
--

DROP TABLE IF EXISTS `charge_type_view`;
/*!50001 DROP VIEW IF EXISTS `charge_type_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `charge_type_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHARGE_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `eod_requests_view`
--

DROP TABLE IF EXISTS `eod_requests_view`;
/*!50001 DROP VIEW IF EXISTS `eod_requests_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `eod_requests_view` AS SELECT 
 1 AS `Id`,
 1 AS `ACC_NUM`,
 1 AS `AMOUNT`,
 1 AS `REQUEST_TYPE`,
 1 AS `PERCENTAGE`,
 1 AS `MATURITY_DATE`,
 1 AS `FREQUENCY`,
 1 AS `AUTO_DEBIT`,
 1 AS `INSTITUTION_ID`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_reqeust_viewwgc`
--

DROP TABLE IF EXISTS `customer_reqeust_viewwgc`;
/*!50001 DROP VIEW IF EXISTS `customer_reqeust_viewwgc`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_reqeust_viewwgc` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `REQUEST_TYPE`,
 1 AS `COMMENTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `REQUEST_DESC`,
 1 AS `REQUEST_STATUS`,
 1 AS `REQUEST_CHG_DESC`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`,
 1 AS `group_code`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pin_migration_view`
--

DROP TABLE IF EXISTS `pin_migration_view`;
/*!50001 DROP VIEW IF EXISTS `pin_migration_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pin_migration_view` AS SELECT 
 1 AS `Id`,
 1 AS `CUST_ID`,
 1 AS `OLD_PWD`,
 1 AS `NEW_PWD`,
 1 AS `PREF_TYPE`,
 1 AS `COMMENTS`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_channel_usage`
--

DROP TABLE IF EXISTS `report_channel_usage`;
/*!50001 DROP VIEW IF EXISTS `report_channel_usage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_channel_usage` AS SELECT 
 1 AS `CIF`,
 1 AS `CUST_NAME`,
 1 AS `CUST_MOBILE`,
 1 AS `SESSIONID`,
 1 AS `CREATED_AT`,
 1 AS `LASTACC`,
 1 AS `CLOSED_AT`,
 1 AS `CLOSE_TYPE`,
 1 AS `REQSOURCE`,
 1 AS `DATEVAL`,
 1 AS `DIFFTIMESECONDS`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_category_view_cbz`
--

DROP TABLE IF EXISTS `customer_category_view_cbz`;
/*!50001 DROP VIEW IF EXISTS `customer_category_view_cbz`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_category_view_cbz` AS SELECT 
 1 AS `Id`,
 1 AS `CATEGORY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHARGE_TYPE`,
 1 AS `CHARGE_VALUE`,
 1 AS `PER_DAY_LIMIT`,
 1 AS `PER_TRAN_LIMIT`,
 1 AS `MIN_TRAN_LIMIT`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `SERVICE_ID`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agency_details_view`
--

DROP TABLE IF EXISTS `agency_details_view`;
/*!50001 DROP VIEW IF EXISTS `agency_details_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agency_details_view` AS SELECT 
 1 AS `Id`,
 1 AS `DOMIBRNCH`,
 1 AS `NATIONALTY`,
 1 AS `PROFCONT1`,
 1 AS `PROFCONT2`,
 1 AS `SERVPK`,
 1 AS `BRNCHCODE`,
 1 AS `PROFPROV`,
 1 AS `PROFAGCODE`,
 1 AS `TRDNAME`,
 1 AS `PSTADDR`,
 1 AS `LRNUM`,
 1 AS `PSTCITY`,
 1 AS `PSTZIP`,
 1 AS `BUSLOC`,
 1 AS `PHYADDR`,
 1 AS `BUSSTAT`,
 1 AS `BUSNAME`,
 1 AS `BUSDESIG`,
 1 AS `BUSNATIONALITY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `MAST_AGCODE`,
 1 AS `accnum1`,
 1 AS `accnum2`,
 1 AS `accnum3`,
 1 AS `ag_type`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_funds_transfer_trans_view`
--

DROP TABLE IF EXISTS `report_funds_transfer_trans_view`;
/*!50001 DROP VIEW IF EXISTS `report_funds_transfer_trans_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_funds_transfer_trans_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `AMOUNT`,
 1 AS `CHARGES`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mail_mesg_view`
--

DROP TABLE IF EXISTS `mail_mesg_view`;
/*!50001 DROP VIEW IF EXISTS `mail_mesg_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mail_mesg_view` AS SELECT 
 1 AS `Id`,
 1 AS `MFROMADDR`,
 1 AS `MTOADDR`,
 1 AS `MCCADDR`,
 1 AS `MSUBJECT`,
 1 AS `MMESSAGE`,
 1 AS `MRETRYCNT`,
 1 AS `MESGQIN`,
 1 AS `MESGQOUT`,
 1 AS `MESGQERR`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `NEXT_ATTEMPT`,
 1 AS `LAST_ATTEMPT`,
 1 AS `SCHEDULE_TS`,
 1 AS `EXEC_AG_CODE`,
 1 AS `CCODE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `paybill_view`
--

DROP TABLE IF EXISTS `paybill_view`;
/*!50001 DROP VIEW IF EXISTS `paybill_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `paybill_view` AS SELECT 
 1 AS `Id`,
 1 AS `PB_TYPE`,
 1 AS `ACC_NUM`,
 1 AS `ACC_NAME`,
 1 AS `CIF`,
 1 AS `PB_DESC`,
 1 AS `PB_CODE`,
 1 AS `PB_VAL`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `EXTN6`,
 1 AS `EXTN7`,
 1 AS `EXTN8`,
 1 AS `EXTN9`,
 1 AS `EXTN10`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_audit_log`
--

DROP TABLE IF EXISTS `report_audit_log`;
/*!50001 DROP VIEW IF EXISTS `report_audit_log`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_audit_log` AS SELECT 
 1 AS `Id`,
 1 AS `ENTITY_NAME`,
 1 AS `INSTITUTION_ID`,
 1 AS `MESSAGE`,
 1 AS `ACTION_TYPE`,
 1 AS `USER_ID`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_mpesa_to_account`
--

DROP TABLE IF EXISTS `report_mpesa_to_account`;
/*!50001 DROP VIEW IF EXISTS `report_mpesa_to_account`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_mpesa_to_account` AS SELECT 
 1 AS `CREATED_AT`,
 1 AS `CUSTOMER_ID`,
 1 AS `CUST_MOBILE`,
 1 AS `FROM_ACCOUNT`,
 1 AS `FT_TYPE`,
 1 AS `REF_NO`,
 1 AS `AMOUNT`,
 1 AS `RSTATUS`,
 1 AS `CUST_REF2`,
 1 AS `ISO_REF_NO`,
 1 AS `ISO_RSTATUS`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `nfc_category_view`
--

DROP TABLE IF EXISTS `nfc_category_view`;
/*!50001 DROP VIEW IF EXISTS `nfc_category_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `nfc_category_view` AS SELECT 
 1 AS `Id`,
 1 AS `CATEGORY_CODE`,
 1 AS `CATEGORY_NAME`,
 1 AS `CURR_PRICE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_mobile_feature_usage_statistics_view`
--

DROP TABLE IF EXISTS `report_mobile_feature_usage_statistics_view`;
/*!50001 DROP VIEW IF EXISTS `report_mobile_feature_usage_statistics_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_mobile_feature_usage_statistics_view` AS SELECT 
 1 AS `INSTITUTION_ID`,
 1 AS `INSTITUTION`,
 1 AS `DATEVAL`,
 1 AS `ACTION_MESG`,
 1 AS `COUNT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customers_sms_alert`
--

DROP TABLE IF EXISTS `report_customers_sms_alert`;
/*!50001 DROP VIEW IF EXISTS `report_customers_sms_alert`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customers_sms_alert` AS SELECT 
 1 AS `cname`,
 1 AS `val_acc`,
 1 AS `branch`,
 1 AS `national_id`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `cust_extn3`,
 1 AS `cust_extn2`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bulk_payment_approvercr_view`
--

DROP TABLE IF EXISTS `bulk_payment_approvercr_view`;
/*!50001 DROP VIEW IF EXISTS `bulk_payment_approvercr_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bulk_payment_approvercr_view` AS SELECT 
 1 AS `Id`,
 1 AS `ORIG_REC_ID`,
 1 AS `ACC_NUM`,
 1 AS `REG_CUST_ID`,
 1 AS `REG_CUST_NAME`,
 1 AS `ALIAS`,
 1 AS `CUST_ID`,
 1 AS `CUST_NAME`,
 1 AS `MANDATORY`,
 1 AS `ROLE_CODE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `OTP_GEN`,
 1 AS `OTP_EXP`,
 1 AS `max_approval_amount`,
 1 AS `SEQ_CODE`,
 1 AS `CATEG_CODE`,
 1 AS `UPDATE_STAT`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sweep_order_view`
--

DROP TABLE IF EXISTS `sweep_order_view`;
/*!50001 DROP VIEW IF EXISTS `sweep_order_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sweep_order_view` AS SELECT 
 1 AS `Id`,
 1 AS `REQ_CIF`,
 1 AS `REQ_CNAME`,
 1 AS `REQ_SOURCE`,
 1 AS `SWEEP_NAME`,
 1 AS `SWEEP_TYPE`,
 1 AS `FROMACC`,
 1 AS `TOACC`,
 1 AS `AMOUNT`,
 1 AS `FT_REMARKS`,
 1 AS `SWEEP_STATUS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BankBranchCode`,
 1 AS `BEN_NAME`,
 1 AS `PAY_DESC`,
 1 AS `BANK_SWIFT_CODE`,
 1 AS `BEN_DTL1`,
 1 AS `BEN_DTL2`,
 1 AS `BEN_DTL3`,
 1 AS `BANK_CODE`,
 1 AS `BRANCH_CODE`,
 1 AS `BEN_TYPE`,
 1 AS `CURRENCY_CODE`,
 1 AS `SWEEP_FREQ`,
 1 AS `SWEEP_STARTTS`,
 1 AS `SWEEP_FINISHTS`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agency_info_view`
--

DROP TABLE IF EXISTS `agency_info_view`;
/*!50001 DROP VIEW IF EXISTS `agency_info_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agency_info_view` AS SELECT 
 1 AS `Id`,
 1 AS `REF_CUST_REC_ID`,
 1 AS `REF_CUST_CIF`,
 1 AS `REF_CUST_MOBILE`,
 1 AS `REF_CUST_NAME`,
 1 AS `DOMIBRNCH`,
 1 AS `NATIONALTY`,
 1 AS `PROFCONT1`,
 1 AS `PROFCONT2`,
 1 AS `SERVPK`,
 1 AS `BRNCHCODE`,
 1 AS `PROFPROV`,
 1 AS `PROFAGCODE`,
 1 AS `TRDNAME`,
 1 AS `PSTADDR`,
 1 AS `LRNUM`,
 1 AS `PSTCITY`,
 1 AS `PSTZIP`,
 1 AS `BUSLOC`,
 1 AS `PHYADDR`,
 1 AS `BUSSTAT`,
 1 AS `BUSNAME`,
 1 AS `BUSDESIG`,
 1 AS `BUSNATIONALITY`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `SUB_AGENCY`,
 1 AS `MAST_AGCODE`,
 1 AS `MERORAG`,
 1 AS `served_by`,
 1 AS `safoutcode`,
 1 AS `airoutcode`,
 1 AS `agextn1`,
 1 AS `agextn2`,
 1 AS `agextn3`,
 1 AS `agextn4`,
 1 AS `agextn5`,
 1 AS `cb_min_amt`,
 1 AS `cb_max_amt`,
 1 AS `serv_comm`,
 1 AS `merpayurl`,
 1 AS `agextn6`,
 1 AS `agextn7`,
 1 AS `agextn8`,
 1 AS `agextn9`,
 1 AS `agextn10`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agent_details_view`
--

DROP TABLE IF EXISTS `agent_details_view`;
/*!50001 DROP VIEW IF EXISTS `agent_details_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agent_details_view` AS SELECT 
 1 AS `ACC_NUM`,
 1 AS `CUST_ID`,
 1 AS `ALIAS`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `agent_requests_view`
--

DROP TABLE IF EXISTS `agent_requests_view`;
/*!50001 DROP VIEW IF EXISTS `agent_requests_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `agent_requests_view` AS SELECT 
 1 AS `Id`,
 1 AS `REQ_CIF`,
 1 AS `REQ_MOB`,
 1 AS `REQ_NAME`,
 1 AS `REQ_TYPE`,
 1 AS `COMMENTS`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `EXTN4`,
 1 AS `EXTN5`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sms_stat_view`
--

DROP TABLE IF EXISTS `sms_stat_view`;
/*!50001 DROP VIEW IF EXISTS `sms_stat_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sms_stat_view` AS SELECT 
 1 AS `DATEVAL`,
 1 AS `status`,
 1 AS `cnt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `chama_master_view`
--

DROP TABLE IF EXISTS `chama_master_view`;
/*!50001 DROP VIEW IF EXISTS `chama_master_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `chama_master_view` AS SELECT 
 1 AS `Id`,
 1 AS `CHAMA_ACC_NUM`,
 1 AS `CHAMA_TITLE`,
 1 AS `CHAMA_ALIAS`,
 1 AS `CHAMA_OTHER_INFO`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `primar_cif`,
 1 AS `primar_mob`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cust_req_audit_view`
--

DROP TABLE IF EXISTS `cust_req_audit_view`;
/*!50001 DROP VIEW IF EXISTS `cust_req_audit_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cust_req_audit_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `REQ_TYPE`,
 1 AS `REQ_CONTENT`,
 1 AS `REQ_STATUS`,
 1 AS `REQ_AT`,
 1 AS `REQ_SOURCE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `standing_order_view`
--

DROP TABLE IF EXISTS `standing_order_view`;
/*!50001 DROP VIEW IF EXISTS `standing_order_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `standing_order_view` AS SELECT 
 1 AS `Id`,
 1 AS `PAYER_CODE`,
 1 AS `FROMACC`,
 1 AS `TOACC`,
 1 AS `AMOUNT`,
 1 AS `FREQUENCY`,
 1 AS `FT_REMARKS`,
 1 AS `FT_TRIGGERTS`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BENE_RECORD_ID`,
 1 AS `BPCATEGORY1`,
 1 AS `BPCATEGORY2`,
 1 AS `EXPIRE_AFTER`,
 1 AS `ORDER_NAME`,
 1 AS `ORIG_CUST_ID`,
 1 AS `ORIG_CUST_NAME`,
 1 AS `ORIG_CUST_MOBILE`,
 1 AS `ORIG_CUST_GROUP`,
 1 AS `BankBranchCode`,
 1 AS `BEN_NAME`,
 1 AS `PAY_DESC`,
 1 AS `BANK_SWIFT_CODE`,
 1 AS `BEN_DTL1`,
 1 AS `BEN_DTL2`,
 1 AS `BEN_DTL3`,
 1 AS `BANK_CODE`,
 1 AS `BRANCH_CODE`,
 1 AS `BENE_TYPE`,
 1 AS `REQ_CIF`,
 1 AS `REQ_CNAME`,
 1 AS `BATCH_CODE`,
 1 AS `CURRENCY_CODE`,
 1 AS `PSTATUS`,
 1 AS `SERVICE_TITLE`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_RESULT`,
 1 AS `DISP_STAT`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `goods_list_view`
--

DROP TABLE IF EXISTS `goods_list_view`;
/*!50001 DROP VIEW IF EXISTS `goods_list_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `goods_list_view` AS SELECT 
 1 AS `Id`,
 1 AS `GOODS_CAT`,
 1 AS `GOODS_NAME`,
 1 AS `GOODS_COST`,
 1 AS `GOODS_TYPE`,
 1 AS `GOODS_DESC`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ef_charge_tran_view`
--

DROP TABLE IF EXISTS `ef_charge_tran_view`;
/*!50001 DROP VIEW IF EXISTS `ef_charge_tran_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ef_charge_tran_view` AS SELECT 
 1 AS `Id`,
 1 AS `CARD_NO`,
 1 AS `CARD_NAME`,
 1 AS `CARD_EXPMON`,
 1 AS `CARD_EXPYR`,
 1 AS `CARD_CVV`,
 1 AS `CARD_TYPE`,
 1 AS `WALLET_ACC`,
 1 AS `AMOUNT`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `CURRENCY`,
 1 AS `TRAN_DESC`,
 1 AS `TRAN_RESULT_CODE`,
 1 AS `TRAN_RESULT_DESC`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `INSTITUTION_ID`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `interest_type_range_view`
--

DROP TABLE IF EXISTS `interest_type_range_view`;
/*!50001 DROP VIEW IF EXISTS `interest_type_range_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `interest_type_range_view` AS SELECT 
 1 AS `Id`,
 1 AS `INTEREST_TYPE_ID`,
 1 AS `SERVICE_ID`,
 1 AS `RANGE_FROM`,
 1 AS `RANGE_TO`,
 1 AS `INTEREST_TYPE_CODE`,
 1 AS `INTEREST_VALUE`,
 1 AS `INTEREST_VALUE2`,
 1 AS `INTEREST_VALUE3`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `ARCHIVED_AT`,
 1 AS `ARCHIVED_BY`,
 1 AS `CURRENCY_CODE`,
 1 AS `CHARGE_TYPE`,
 1 AS `INAME`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `SERVICE_CODE`,
 1 AS `SERVICE_NAME`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `report_customers_mobile_banking`
--

DROP TABLE IF EXISTS `report_customers_mobile_banking`;
/*!50001 DROP VIEW IF EXISTS `report_customers_mobile_banking`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `report_customers_mobile_banking` AS SELECT 
 1 AS `cname`,
 1 AS `val_acc`,
 1 AS `branch`,
 1 AS `national_id`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cbcustomer_view`
--

DROP TABLE IF EXISTS `cbcustomer_view`;
/*!50001 DROP VIEW IF EXISTS `cbcustomer_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cbcustomer_view` AS SELECT 
 1 AS `Id`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `VAL_ACC`,
 1 AS `NATIONAL_ID`,
 1 AS `PASSPORT`,
 1 AS `NATIONALITY`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `ID_SUBMITTED`,
 1 AS `ID_VERIFIED`,
 1 AS `PIN_NO`,
 1 AS `TERMS_SIGNED`,
 1 AS `UG_ISSUED`,
 1 AS `PREF_LANG`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `BLOCKED_FLAG`,
 1 AS `CUST_CAT`,
 1 AS `ALLOWED_PHONE_TYPE1`,
 1 AS `ALLOWED_PHONE_TYPE2`,
 1 AS `ALLOWED_PHONE_TYPE3`,
 1 AS `ALLOWED_PHONE_ID1`,
 1 AS `ALLOWED_PHONE_ID2`,
 1 AS `ALLOWED_PHONE_ID3`,
 1 AS `TPIN_NO`,
 1 AS `AUTH_FAIL_PIN`,
 1 AS `AUTH_FAIL_TPIN`,
 1 AS `REPORT_FREQ`,
 1 AS `CUST_EXTN1`,
 1 AS `CUST_EXTN2`,
 1 AS `CUST_EXTN3`,
 1 AS `CUST_EXTN4`,
 1 AS `INITIAL_MPIN`,
 1 AS `INITIAL_TPIN`,
 1 AS `EMAIL_ALERT_TYPE`,
 1 AS `SMS_ALERT_TYPE`,
 1 AS `ADDTNL_MAIL1`,
 1 AS `ADDTNL_MAIL2`,
 1 AS `ADDTNL_MAIL3`,
 1 AS `ADDTNL_MAIL4`,
 1 AS `ADDTNL_MAIL5`,
 1 AS `CUSEXTN11`,
 1 AS `CUSEXTN12`,
 1 AS `CUSEXTN13`,
 1 AS `CUSEXTN14`,
 1 AS `CUSEXTN15`,
 1 AS `MPIN_FLDATTMPT`,
 1 AS `LAST_ATTMPTSRC`,
 1 AS `LAST_ATTMPTVER`,
 1 AS `UNLOCK_TIME`,
 1 AS `MOBILE_ACCESS`,
 1 AS `VIRTUAL_AGENCY`,
 1 AS `VIRTUAL_AGENCY_ACC`,
 1 AS `AGENCY_ID`,
 1 AS `VIRTUAL_CUSTOMER`,
 1 AS `CA_APP_ACCESS`,
 1 AS `IName`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `CATEGORY`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `joint_acc_pend_app_view`
--

DROP TABLE IF EXISTS `joint_acc_pend_app_view`;
/*!50001 DROP VIEW IF EXISTS `joint_acc_pend_app_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `joint_acc_pend_app_view` AS SELECT 
 1 AS `ft_tran_id`,
 1 AS `ft_from`,
 1 AS `cnt`,
 1 AS `NEXT_REM_TS`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_data_update1_view`
--

DROP TABLE IF EXISTS `customer_data_update1_view`;
/*!50001 DROP VIEW IF EXISTS `customer_data_update1_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_data_update1_view` AS SELECT 
 1 AS `Id`,
 1 AS `ALLOWED_PHONE_ID1`,
 1 AS `ALLOWED_PHONE_ID2`,
 1 AS `CUST_RECORD_ID`,
 1 AS `CIF`,
 1 AS `CNAME`,
 1 AS `NATIONAL_ID`,
 1 AS `PASSPORT`,
 1 AS `NATIONALITY`,
 1 AS `MOBILE`,
 1 AS `EMAIL`,
 1 AS `PREF_LANG`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `CUST_CAT`,
 1 AS `IB_SQ1`,
 1 AS `IB_SQ2`,
 1 AS `IB_SQ3`,
 1 AS `IB_SQ4`,
 1 AS `IB_SQ5`,
 1 AS `IB_SA1`,
 1 AS `IB_SA2`,
 1 AS `IB_SA3`,
 1 AS `IB_SA4`,
 1 AS `IB_SA5`,
 1 AS `ORIG_MOBILE`,
 1 AS `EXTN1`,
 1 AS `EXTN2`,
 1 AS `EXTN3`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `biller_type_view`
--

DROP TABLE IF EXISTS `biller_type_view`;
/*!50001 DROP VIEW IF EXISTS `biller_type_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `biller_type_view` AS SELECT 
 1 AS `Id`,
 1 AS `BILLER_CODE`,
 1 AS `BILLER_ACNO`,
 1 AS `BILLER_TYPE`,
 1 AS `INSTITUTION_ID`,
 1 AS `MADE_BY`,
 1 AS `MADE_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `MAKER_LAST_CMT`,
 1 AS `CHECKER_LAST_CMT`,
 1 AS `CURR_APP_STATUS`,
 1 AS `ADMIN_LAST_CMT`,
 1 AS `RSTATUS`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `MODIFIED_AT`,
 1 AS `MODIFIED_BY`,
 1 AS `FLD1NAME`,
 1 AS `FLD2NAME`,
 1 AS `FLD3NAME`,
 1 AS `FLD4NAME`,
 1 AS `FLD5NAME`,
 1 AS `FLD1CODE`,
 1 AS `FLD2CODE`,
 1 AS `FLD3CODE`,
 1 AS `FLD4CODE`,
 1 AS `FLD5CODE`,
 1 AS `FLD1TYPE`,
 1 AS `FLD2TYPE`,
 1 AS `FLD3TYPE`,
 1 AS `FLD4TYPE`,
 1 AS `FLD5TYPE`,
 1 AS `MIN_TRAN_AMT`,
 1 AS `MAX_TRAN_AMT`,
 1 AS `DLY_TRAN_AMT`,
 1 AS `BRANCH_CODE`,
 1 AS `CURR_CODE`,
 1 AS `PAY_TYPE`,
 1 AS `STATUS_NAME`,
 1 AS `CURR_APP_STATUS_NAME`,
 1 AS `IName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rep_customer_crea_history`
--

DROP TABLE IF EXISTS `rep_customer_crea_history`;
/*!50001 DROP VIEW IF EXISTS `rep_customer_crea_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rep_customer_crea_history` AS SELECT 
 1 AS `CUST_NAME`,
 1 AS `CUST_MOB`,
 1 AS `CUST_AC`,
 1 AS `CREATED_BY`,
 1 AS `CREATED_AT`,
 1 AS `CHECKED_BY`,
 1 AS `CHECKED_AT`,
 1 AS `DATEVAL`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `customer_reqeust1_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_reqeust1_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_reqeust1_view` AS (select `er`.`Id` AS `Id`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`er`.`COMMENTS` AS `COMMENTS`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`er`.`REQUEST_DESC` AS `REQUEST_DESC`,`er`.`REQUEST_STATUS` AS `REQUEST_STATUS`,`er`.`REQUEST_CHG_DESC` AS `REQUEST_CHG_DESC`,`er`.`cmobile` AS `cmobile`,`er`.`extn1` AS `extn1`,`er`.`extn2` AS `extn2`,`er`.`extn3` AS `extn3`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`customer_reqeust` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_funds_transfer_transaction_audit`
--

/*!50001 DROP VIEW IF EXISTS `report_funds_transfer_transaction_audit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_funds_transfer_transaction_audit` AS select `ft`.`Id` AS `Id`,`ft`.`FROM_ACCOUNT` AS `FROM_ACCOUNT`,`ft`.`TO_ACCOUNT` AS `TO_ACCOUNT`,`ft`.`REF_NO` AS `REF_NO`,`ft`.`FROM_BENE` AS `FROM_BENE`,`ft`.`TO_BENE` AS `TO_BENE`,`ft`.`BENE_TYPE` AS `BENE_TYPE`,`ft`.`BENE_CODE` AS `BENE_CODE`,`ft`.`BENE_BANK` AS `BENE_BANK`,`ft`.`BENE_BRANCH` AS `BENE_BRANCH`,`ft`.`BENE_MOBILE` AS `BENE_MOBILE`,`ft`.`CURRENCY` AS `CURRENCY`,`ft`.`CUST_MOBILE` AS `CUST_MOBILE`,`ft`.`CUST_REF2` AS `CUST_REF2`,`ft`.`BEN_CURR` AS `BEN_CURR`,`ft`.`BEN_COUNTRY` AS `BEN_COUNTRY`,`ft`.`AMOUNT` AS `AMOUNT`,`ft`.`TRAN_TIME` AS `TRAN_TIME`,`ft`.`TRAN_RESULT_FLAG` AS `TRAN_RESULT_FLAG`,`ft`.`TRAN_RESULT` AS `TRAN_RESULT`,`ft`.`FT_TYPE` AS `FT_TYPE`,`ft`.`CUSTOMER_ID` AS `CUSTOMER_ID`,`ft`.`CUSTOMER_CATEGORY` AS `CUSTOMER_CATEGORY`,`ft`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ft`.`EXTN1` AS `EXTN1`,`ft`.`EXTN2` AS `EXTN2`,`ft`.`EXTN3` AS `EXTN3`,`ft`.`EXTN4` AS `EXTN4`,`ft`.`EXTN5` AS `EXTN5`,`ft`.`rstatus` AS `RSTATUS`,`ft`.`CREATED_BY` AS `CREATED_BY`,`ft`.`CREATED_AT` AS `CREATED_AT`,`ft`.`MODIFIED_AT` AS `MODIFIED_AT`,`ft`.`MODIFIED_BY` AS `MODIFIED_BY`,`ft`.`MFREVACC` AS `MFREVACC`,`ft`.`MFREVAMT` AS `MFREVAMT`,`ft`.`EXCACC` AS `EXCACC`,`ft`.`EXCAMT` AS `EXCAMT`,date_format(`ft`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `funds_transfer_transaction_audit` `ft` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `loan_detail_view`
--

/*!50001 DROP VIEW IF EXISTS `loan_detail_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `loan_detail_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`AMOUNT` AS `AMOUNT`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`EMAIL` AS `EMAIL`,`blr`.`LOAN_TERM` AS `LOAN_TERM`,`blr`.`PRODUCT` AS `PRODUCT`,`blr`.`PERCENTAGE` AS `PERCENTAGE`,`blr`.`ADDRESS` AS `ADDRESS`,`blr`.`NATIONAL_ID` AS `NATIONAL_ID`,`blr`.`EMI_AMT` AS `EMI_AMT`,`blr`.`AGE` AS `AGE`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`loan_detail` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `corp_self_reg_add_accnt_request_view`
--

/*!50001 DROP VIEW IF EXISTS `corp_self_reg_add_accnt_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `corp_self_reg_add_accnt_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`corp_self_reg_add_accnt_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mail_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `mail_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mail_stat_view` AS select date_format(`mm`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL`,`mm`.`MSUBJECT` AS `category`,`mm`.`RSTATUS` AS `status`,count(0) AS `cnt` from `mail_mesg` `mm` group by date_format(`mm`.`CREATED_AT`,'%Y%m%d'),`mm`.`MSUBJECT`,`mm`.`RSTATUS` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `full_stmt_temp_view`
--

/*!50001 DROP VIEW IF EXISTS `full_stmt_temp_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `full_stmt_temp_view` AS select `f`.`ID` AS `ID`,`f`.`ACCOUNT_ID` AS `ACCOUNT_ID`,`f`.`NAME` AS `NAME`,`f`.`PARTICULARS` AS `PARTICULARS`,`f`.`AMOUNT` AS `AMOUNT`,`f`.`PRODUCT` AS `PRODUCT`,`f`.`ADDRESS` AS `ADDRESS`,`f`.`OPERATOR` AS `OPERATOR`,`f`.`CLIENTID` AS `CLIENTID`,`f`.`BRANCH1` AS `BRANCH1`,`f`.`BRANCH2` AS `BRANCH2`,`f`.`CURRENCY` AS `CURRENCY`,`f`.`CLEARBALANCE` AS `CLEARBALANCE`,`f`.`EFFECTS` AS `EFFECTS`,`f`.`TDATE` AS `TDATE`,`f`.`TVALUE` AS `TVALUE`,`f`.`TTYPE` AS `TTYPE`,`f`.`RSTATUS` AS `RSTATUS`,`f`.`CREATED_BY` AS `CREATED_BY`,`f`.`CREATED_AT` AS `CREATED_AT`,`f`.`MODIFIED_AT` AS `MODIFIED_AT`,`f`.`MODIFIED_BY` AS `MODIFIED_BY`,`f`.`REPORT_ID` AS `REPORT_ID`,date_format(`f`.`TDATE`,'%Y%m%d') AS `DATEVAL` from `full_stmt_temp` `f` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_funds_tran_trans_view`
--

/*!50001 DROP VIEW IF EXISTS `rep_funds_tran_trans_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_funds_tran_trans_view` AS select `av`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`av`.`IName` AS `INSTITUTION`,date_format(`ft`.`FTTRANTIME`,'%Y%m%d') AS `DATEVAL`,sum(`ft`.`FTAMOUNT`) AS `AMOUNT`,sum(`ft`.`FTCHARGE`) AS `CHARGES` from (`funds_transfer_transaction_view` `ft` join `account_view` `av`) where ((`ft`.`FTRESULTCODE` = '1') and (`ft`.`FTFROM` = `av`.`ACC_NUM`)) group by `av`.`INSTITUTION_ID`,`av`.`IName`,date_format(`ft`.`FTTRANTIME`,'%Y%m%d') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mobile_access_log_view`
--

/*!50001 DROP VIEW IF EXISTS `mobile_access_log_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mobile_access_log_view` AS select `ms`.`Id` AS `Id`,`ms`.`CIFNO` AS `CIFNO`,`ms`.`SESSIONID` AS `SESSIONID`,`ms`.`STATUS` AS `STATUS`,`ms`.`LASTACC` AS `LASTACC`,`ms`.`CREATED_BY` AS `CREATED_BY`,`ms`.`CREATED_AT` AS `CREATED_AT`,`ms`.`MODIFIED_AT` AS `MODIFIED_AT`,`ms`.`MODIFIED_BY` AS `MODIFIED_BY`,`ms`.`LAST_FT_FROM` AS `LAST_FT_FROM`,`ms`.`LAST_FT_TO` AS `LAST_FT_TO`,`ms`.`LAST_FT_AMT` AS `LAST_FT_AMT`,`ms`.`LAST_FT_REMARKS` AS `LAST_FT_REMARKS`,`ms`.`LAST_PHONE_TYPE` AS `LAST_PHONE_TYPE`,`ms`.`LAST_PHONE_ID` AS `LAST_PHONE_ID`,`cm`.`CCODE` AS `ACTION_MESG`,`cu`.`CNAME` AS `CNAME`,`cu`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cu`.`IName` AS `INAME` from (((`mobile_session2` `ms` join `mobilejsonrequest` `mr`) join `customer_view` `cu`) join `content_map` `cm`) where ((convert(`ms`.`SESSIONID` using utf8) = `mr`.`SessionId`) and (convert(`ms`.`CIFNO` using utf8) = `cu`.`CIF`) and (`mr`.`ActionId` = `cm`.`CVALUE`) and (`cm`.`CTYPE` = 'MOBILE_ACTION_CODE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_user_activity`
--

/*!50001 DROP VIEW IF EXISTS `report_user_activity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_user_activity` AS select `web_access_log`.`USER_ID` AS `USER_ID`,`web_access_log`.`SOURCE` AS `SOURCE`,`web_access_log`.`SERVICE` AS `SERVICE`,`web_access_log`.`SESSIONID` AS `SESSIONID`,`web_access_log`.`CREATED_AT` AS `DATEVAL` from `web_access_log` where (1 = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_system_user_statistics_view`
--

/*!50001 DROP VIEW IF EXISTS `report_system_user_statistics_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_system_user_statistics_view` AS select `suc`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`suc`.`IName` AS `INSTITUTION`,`suc`.`ROLENAME` AS `ROLE`,`suc`.`CURR_APP_STATUS_NAME` AS `STATUS`,count(0) AS `COUNT` from `system_user_view` `suc` group by `suc`.`INSTITUTION_ID`,`suc`.`IName`,`suc`.`ROLENAME`,`suc`.`CURR_APP_STATUS_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `card_view`
--

/*!50001 DROP VIEW IF EXISTS `card_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `card_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CARD_NUM` AS `CARD_NUM`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CURRENCY` AS `CURRENCY`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`PRIMARY_CARD` AS `PRIMARY_CARD`,`blr`.`CARDTYPE` AS `CARDTYPE`,`blr`.`ALLOW_SMS` AS `ALLOW_SMS`,`blr`.`ALLOW_EMAIL` AS `ALLOW_EMAIL`,`blr`.`SMS_THRES` AS `SMS_THRES`,`blr`.`EMAIL_THRES` AS `EMAIL_THRES`,`blr`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`blr`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`blr`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`blr`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`blr`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`blr`.`ADDTNL_SMS1` AS `ADDTNL_SMS1`,`blr`.`ADDTNL_SMS2` AS `ADDTNL_SMS2`,`blr`.`ADDTNL_SMS3` AS `ADDTNL_SMS3`,`blr`.`ADDTNL_SMS4` AS `ADDTNL_SMS4`,`blr`.`ADDTNL_SMS5` AS `ADDTNL_SMS5`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`EXPIRY_AT` AS `EXPIRY_AT`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`acc_num` AS `acc_num`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`card` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mfs_exc_err_view`
--

/*!50001 DROP VIEW IF EXISTS `mfs_exc_err_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mfs_exc_err_view` AS (select `blr`.`Id` AS `Id`,`blr`.`EXC_NAME` AS `EXC_NAME`,`blr`.`EXC_LOCATION` AS `EXC_LOCATION`,`blr`.`FEATURE` AS `FEATURE`,`blr`.`STACKTRACE` AS `STACKTRACE`,`blr`.`EXC_DETAILS` AS `EXC_DETAILS`,`blr`.`EXC_FILE_NAME` AS `EXC_FILE_NAME`,`blr`.`SERVICE_TITLE` AS `SERVICE_TITLE`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`REQ_MOB` AS `REQ_MOB`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mfs_exc_err` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `intel_async`
--

/*!50001 DROP VIEW IF EXISTS `intel_async`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `intel_async` AS select `cust_acq`.`Id` AS `Id`,`cust_acq`.`SALUTN` AS `SALUTN`,`cust_acq`.`FIRST_NAME` AS `FIRST_NAME`,`cust_acq`.`MIDDLE_NAME` AS `MIDDLE_NAME`,`cust_acq`.`LAST_NAME` AS `LAST_NAME`,`cust_acq`.`EMAIL` AS `EMAIL`,`cust_acq`.`IMG1` AS `IMG1`,`cust_acq`.`IMG2` AS `IMG2`,`cust_acq`.`IMG3` AS `IMG3`,`cust_acq`.`IMG4` AS `IMG4`,`cust_acq`.`IMG5` AS `IMG5`,`cust_acq`.`RES_TYPE` AS `RES_TYPE`,`cust_acq`.`CURRENCY` AS `CURRENCY`,`cust_acq`.`ZIPCODE` AS `ZIPCODE`,`cust_acq`.`ADDR1` AS `ADDR1`,`cust_acq`.`ADDR2` AS `ADDR2`,`cust_acq`.`ADDR3` AS `ADDR3`,`cust_acq`.`ADDR4` AS `ADDR4`,`cust_acq`.`OTPGEN` AS `OTPGEN`,`cust_acq`.`OTPEXP` AS `OTPEXP`,`cust_acq`.`OTPCONFIRMED` AS `OTPCONFIRMED`,`cust_acq`.`CHILDCNT` AS `CHILDCNT`,`cust_acq`.`GENDER` AS `GENDER`,`cust_acq`.`NATIONALITY` AS `NATIONALITY`,`cust_acq`.`MAR_STATUS` AS `MAR_STATUS`,`cust_acq`.`EMPLOYER` AS `EMPLOYER`,`cust_acq`.`TIN` AS `TIN`,`cust_acq`.`SHORT_NAME` AS `SHORT_NAME`,`cust_acq`.`CUST_TYPE` AS `CUST_TYPE`,`cust_acq`.`ADDR_TYPE` AS `ADDR_TYPE`,`cust_acq`.`COMM_TYPE` AS `COMM_TYPE`,`cust_acq`.`DEV_NO` AS `DEV_NO`,`cust_acq`.`DOC_ID` AS `DOC_ID`,`cust_acq`.`REF_NO` AS `REF_NO`,`cust_acq`.`SEC_ANA_TYPE` AS `SEC_ANA_TYPE`,`cust_acq`.`ORG_CLASSF` AS `ORG_CLASSF`,`cust_acq`.`ES_CLASSF` AS `ES_CLASSF`,`cust_acq`.`AN_TYPE` AS `AN_TYPE`,`cust_acq`.`AN_CODE` AS `AN_CODE`,`cust_acq`.`NATIONAL_ID` AS `NATIONAL_ID`,`cust_acq`.`MOBILE` AS `MOBILE`,`cust_acq`.`DOB` AS `DOB`,`cust_acq`.`ADDRESS` AS `ADDRESS`,`cust_acq`.`SUBMIT_AG_NAME` AS `SUBMIT_AG_NAME`,`cust_acq`.`AG_MOBILE` AS `AG_MOBILE`,`cust_acq`.`CA_STATUS` AS `CA_STATUS`,`cust_acq`.`REG_STATUS` AS `REG_STATUS`,`cust_acq`.`REQ_CATEG` AS `REQ_CATEG`,`cust_acq`.`CURR_CODE` AS `CURR_CODE`,`cust_acq`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cust_acq`.`MADE_BY` AS `MADE_BY`,`cust_acq`.`MADE_AT` AS `MADE_AT`,`cust_acq`.`CHECKED_BY` AS `CHECKED_BY`,`cust_acq`.`CHECKED_AT` AS `CHECKED_AT`,`cust_acq`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cust_acq`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cust_acq`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cust_acq`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cust_acq`.`RSTATUS` AS `RSTATUS`,`cust_acq`.`CREATED_BY` AS `CREATED_BY`,`cust_acq`.`CREATED_AT` AS `CREATED_AT`,`cust_acq`.`MODIFIED_AT` AS `MODIFIED_AT`,`cust_acq`.`MODIFIED_BY` AS `MODIFIED_BY`,`cust_acq`.`ID1Checked` AS `ID1Checked`,`cust_acq`.`ID2Checked` AS `ID2Checked`,`cust_acq`.`PhotoChecked` AS `PhotoChecked`,`cust_acq`.`SignatureChecked` AS `SignatureChecked`,`cust_acq`.`IPRSChecked` AS `IPRSChecked`,`cust_acq`.`CBCUST_ID` AS `CBCUST_ID`,`cust_acq`.`CBACCNUM1` AS `CBACCNUM1`,`cust_acq`.`CBACCNUM2` AS `CBACCNUM2`,`cust_acq`.`CBACCNUM3` AS `CBACCNUM3`,`cust_acq`.`CBACCNUM4` AS `CBACCNUM4`,`cust_acq`.`RESULTCODE` AS `RESULTCODE`,`cust_acq`.`RESULTDESC` AS `RESULTDESC`,`cust_acq`.`BRANCH_ID` AS `BRANCH_ID`,`cust_acq`.`ADDR` AS `ADDR`,`cust_acq`.`NATURE_OF_BUS` AS `NATURE_OF_BUS`,`cust_acq`.`AGENT_CODE` AS `AGENT_CODE`,`cust_acq`.`AGENT_CAT` AS `AGENT_CAT`,`cust_acq`.`ACCOUNT_OFFICER_ID` AS `ACCOUNT_OFFICER_ID`,`cust_acq`.`ACCOUNT_OFFICER_NAME` AS `ACCOUNT_OFFICER_NAME`,`cust_acq`.`NATIONAL_ID_CHECKED` AS `NATIONAL_ID_CHECKED`,`cust_acq`.`DATE_CODE` AS `DATE_CODE` from `cust_acq` where ((`cust_acq`.`REG_STATUS` = 'A0') or (`cust_acq`.`REG_STATUS` = 'A1') or (`cust_acq`.`REG_STATUS` = 'A2') or (`cust_acq`.`REG_STATUS` = 'B0') or (`cust_acq`.`REG_STATUS` = 'B1') or (`cust_acq`.`REG_STATUS` = 'B2') or (`cust_acq`.`REG_STATUS` = 'C0') or (`cust_acq`.`REG_STATUS` = 'C1') or (`cust_acq`.`REG_STATUS` = 'C2')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lnm_tran_master_view`
--

/*!50001 DROP VIEW IF EXISTS `lnm_tran_master_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lnm_tran_master_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BANK_CODE` AS `BANK_CODE`,`blr`.`LNM_SHORT_CODE` AS `LNM_SHORT_CODE`,`blr`.`LNM_REF_NUM` AS `LNM_REF_NUM`,`blr`.`LNM_TRAN_DATE` AS `LNM_TRAN_DATE`,`blr`.`LNM_STATUS` AS `LNM_STATUS`,`blr`.`MERCH_INFO` AS `MERCH_INFO`,`blr`.`TRAN_ACC_ID` AS `TRAN_ACC_ID`,`blr`.`TRAN_TYPE` AS `TRAN_TYPE`,`blr`.`NARRATION` AS `NARRATION`,`blr`.`TRAN_AMT` AS `TRAN_AMT`,`blr`.`WDL_AMT` AS `WDL_AMT`,`blr`.`FILE_NAME` AS `FILE_NAME`,`blr`.`POSTING_TYPE` AS `POSTING_TYPE`,`blr`.`SENDER_NAME` AS `SENDER_NAME`,`blr`.`SENDER_NUMBER` AS `SENDER_NUMBER`,`blr`.`PROCESSED_AT` AS `PROCESSED_AT`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`lnm_tran_master` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_mobile_access_log_view`
--

/*!50001 DROP VIEW IF EXISTS `report_mobile_access_log_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_mobile_access_log_view` AS select `ms`.`Id` AS `Id`,`ms`.`CIFNO` AS `CIFNO`,`ms`.`SESSIONID` AS `SESSIONID`,`ms`.`STATUS` AS `STATUS`,`ms`.`LASTACC` AS `LASTACC`,`ms`.`CREATED_BY` AS `CREATED_BY`,`ms`.`CREATED_AT` AS `CREATED_AT`,`ms`.`MODIFIED_AT` AS `MODIFIED_AT`,`ms`.`MODIFIED_BY` AS `MODIFIED_BY`,`ms`.`LAST_FT_FROM` AS `LAST_FT_FROM`,`ms`.`LAST_FT_TO` AS `LAST_FT_TO`,`ms`.`LAST_FT_AMT` AS `LAST_FT_AMT`,`ms`.`LAST_FT_REMARKS` AS `LAST_FT_REMARKS`,date_format(`ms`.`LASTACC`,'%Y%m%d%H%i%S') AS `DATEVAL`,`ms`.`LAST_PHONE_TYPE` AS `LAST_PHONE_TYPE`,`ms`.`LAST_PHONE_ID` AS `LAST_PHONE_ID`,`cm`.`CCODE` AS `ACTION_MESG`,`cu`.`CNAME` AS `CNAME`,`cu`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cu`.`IName` AS `INAME` from (((`mobile_session2` `ms` join `mobilejsonrequest` `mr`) join `customer_view` `cu`) join `content_map` `cm`) where ((convert(`ms`.`SESSIONID` using utf8) = `mr`.`SessionId`) and (convert(`ms`.`CIFNO` using utf8) = `cu`.`CIF`) and (`mr`.`ActionId` = `cm`.`CVALUE`) and (`cm`.`CTYPE` = 'MOBILE_ACTION_CODE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mfs_alt_accnum_view`
--

/*!50001 DROP VIEW IF EXISTS `mfs_alt_accnum_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mfs_alt_accnum_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MASTER_ACCOUNT` AS `MASTER_ACCOUNT`,`blr`.`MASTER_ACCOUNTH_NAME` AS `MASTER_ACCOUNTH_NAME`,`blr`.`ALTERNATE_ACCOUNT` AS `ALTERNATE_ACCOUNT`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mfs_alt_accnum` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_async_account_opening`
--

/*!50001 DROP VIEW IF EXISTS `report_async_account_opening`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_async_account_opening` AS select `async_task`.`METHODNAME` AS `SERVICE_NAME`,`async_task`.`ASINPUT` AS `DETAILS`,`async_task`.`ASOUTPUT` AS `RESULT`,date_format(`async_task`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `async_task` where (`async_task`.`METHODNAME` = 'createAccountAsync') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sms_mesg_view`
--

/*!50001 DROP VIEW IF EXISTS `sms_mesg_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sms_mesg_view` AS select `sm`.`Id` AS `Id`,`sm`.`MFROMADDR` AS `MFROMADDR`,`sm`.`MTOADDR` AS `MTOADDR`,`sm`.`MMESSAGE` AS `MMESSAGE`,`sm`.`MRETRYCNT` AS `MRETRYCNT`,`sm`.`MESGQIN` AS `MESGQIN`,`sm`.`MESGQOUT` AS `MESGQOUT`,`sm`.`MESGQERR` AS `MESGQERR`,`sm`.`RSTATUS` AS `RSTATUS`,`sm`.`CREATED_BY` AS `CREATED_BY`,`sm`.`CREATED_AT` AS `CREATED_AT`,`sm`.`MODIFIED_AT` AS `MODIFIED_AT`,`sm`.`MODIFIED_BY` AS `MODIFIED_BY`,`sm`.`NEXT_ATTEMPT` AS `NEXT_ATTEMPT`,`sm`.`LAST_ATTEMPT` AS `LAST_ATTEMPT`,`sm`.`SCHEDULE_TS` AS `SCHEDULE_TS`,`sm`.`REQ_SOURCE` AS `REQ_SOURCE`,`sm`.`LANG_CODE` AS `LANG_CODE`,`sm`.`DESTCID` AS `DESTCID`,`sm`.`EXTN1` AS `EXTN1`,`sm`.`EXTN2` AS `EXTN2`,`sm`.`EXTN3` AS `EXTN3`,`sm`.`EXEC_AG_CODE` AS `EXEC_AG_CODE`,`cm`.`CCODE` AS `CCODE` from (`sms_mesg` `sm` join `content_map` `cm`) where ((`cm`.`CTYPE` = 'MESG_COMMN_CODE') and (`sm`.`RSTATUS` = `cm`.`CVALUE`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_view`
--

/*!50001 DROP VIEW IF EXISTS `report_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_view` AS select `rm`.`Id` AS `Id`,`rm`.`RCODE` AS `RCODE`,`rm`.`RPARAMETERS` AS `RPARAMETERS`,`rm`.`RUSERID` AS `RUSERID`,`rm`.`RRETRYCNT` AS `RRETRYCNT`,`rm`.`RFORMAT` AS `RFORMAT`,`rm`.`ROUT` AS `ROUT`,`rm`.`RERR` AS `RERR`,`rm`.`RSTATUS` AS `RSTATUS`,`rm`.`CREATED_BY` AS `CREATED_BY`,`rm`.`CREATED_AT` AS `CREATED_AT`,`rm`.`MODIFIED_AT` AS `MODIFIED_AT`,`rm`.`MODIFIED_BY` AS `MODIFIED_BY`,`rm`.`RURL` AS `RURL`,`rm`.`AGCODE` AS `AGCODE`,(case `rm`.`RSTATUS` when 1 then 'Done' when 0 then 'In Queue' end) AS `RESULTCODE`,concat(`suv`.`FIRST_NAME`,' ',`suv`.`LAST_NAME`) AS `UName`,`suv`.`IName` AS `INAME`,`suv`.`INSTITUTION_ID` AS `INSTITUTION_ID` from (`report_mesg` `rm` join `system_user_view` `suv`) where (`rm`.`RUSERID` = `suv`.`Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_cheque_deposit`
--

/*!50001 DROP VIEW IF EXISTS `report_cheque_deposit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_cheque_deposit` AS select `c`.`FROM_ACCOUNT_NUMBER` AS `FROM_ACCOUNT_NUMBER`,`c`.`TO_ACCOUNT_NUMBER` AS `TO_ACCOUNT_NUMBER`,`c`.`CHEQUE_NUMBER` AS `CHEQUE_NUMBER`,`c`.`MOBILE_NUMBER` AS `MOBILE_NUMBER`,`c`.`IMAGEURL1` AS `IMAGEURL1`,`c`.`IMAGEURL2` AS `IMAGEURL2`,`c`.`CHQAMT` AS `CHQAMT`,`c`.`MOBILE_NUMBER` AS `CUST_ID`,`c`.`CREATED_AT` AS `CREATED_AT`,`c`.`RSTATUS` AS `RSTATUS`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `cheque_deposit` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bond_view`
--

/*!50001 DROP VIEW IF EXISTS `bond_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bond_view` AS (select `blr`.`Id` AS `Id`,`blr`.`SUB_REC_ID` AS `SUB_REC_ID`,`blr`.`CIF` AS `CIF`,`blr`.`BOND_NAME` AS `BOND_NAME`,`blr`.`BOND_VALUE` AS `BOND_VALUE`,`blr`.`PURCH_DATE` AS `PURCH_DATE`,`blr`.`BOND_STATUS` AS `BOND_STATUS`,`blr`.`BOND_MATURITY` AS `BOND_MATURITY`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`REF_NO` AS `REF_NO`,`blr`.`BONDCODE` AS `BONDCODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`bond` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_mobile_recharge_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_mobile_recharge_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_mobile_recharge_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`RCOPERATOR` AS `RCOPERATOR`,`er`.`RCAMOUNT` AS `RCAMOUNT`,`er`.`RCMOBILE` AS `RCMOBILE`,`er`.`RCTYPE` AS `RCTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_mobile_recharge_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monitor_ft_transactions_view`
--

/*!50001 DROP VIEW IF EXISTS `monitor_ft_transactions_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `monitor_ft_transactions_view` AS select `report_funds_transfer_transaction_audit`.`FROM_ACCOUNT` AS `FROM_ACCOUNT`,`report_funds_transfer_transaction_audit`.`TO_ACCOUNT` AS `TO_ACCOUNT`,`report_funds_transfer_transaction_audit`.`REF_NO` AS `REF_NO`,`report_funds_transfer_transaction_audit`.`CUSTOMER_ID` AS `CUSTOMER_ID`,`report_funds_transfer_transaction_audit`.`CUST_MOBILE` AS `CUST_MOBILE`,`report_funds_transfer_transaction_audit`.`FT_TYPE` AS `FT_TYPE`,date_format(`report_funds_transfer_transaction_audit`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL`,`report_funds_transfer_transaction_audit`.`EXTN2` AS `VENDOR_RESPONSE`,`report_funds_transfer_transaction_audit`.`RSTATUS` AS `RSTATUS`,`report_funds_transfer_transaction_audit`.`AMOUNT` AS `AMOUNT`,`report_funds_transfer_transaction_audit`.`CUST_REF2` AS `CUST_REF2` from `report_funds_transfer_transaction_audit` where (1 = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `merchant_credit_request_view`
--

/*!50001 DROP VIEW IF EXISTS `merchant_credit_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `merchant_credit_request_view` AS select `ac`.`Id` AS `Id`,`ac`.`PAYMENT_REQUEST_ID` AS `PAYMENT_REQUEST_ID`,`ac`.`CREDIT_REQUEST_TS` AS `CREDIT_REQUEST_TS`,`ac`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ac`.`MADE_BY` AS `MADE_BY`,`ac`.`MADE_AT` AS `MADE_AT`,`ac`.`CHECKED_BY` AS `CHECKED_BY`,`ac`.`CHECKED_AT` AS `CHECKED_AT`,`ac`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ac`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ac`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ac`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ac`.`RSTATUS` AS `RSTATUS`,`ac`.`CREATED_BY` AS `CREATED_BY`,`ac`.`CREATED_AT` AS `CREATED_AT`,`ac`.`MODIFIED_AT` AS `MODIFIED_AT`,`ac`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`cu`.`PFROM` AS `PFROM`,`cu`.`PFROMCIF` AS `PFROMCIF`,`cu`.`PFROMNAME` AS `PFROMNAME`,`cu`.`PTO` AS `PTO`,`cu`.`PTOCIF` AS `PTOCIF`,`cu`.`PTONAME` AS `PTONAME`,`cu`.`ITEM` AS `ITEM`,`cu`.`PAMOUNT` AS `PAMOUNT`,`cu`.`PCATEGORY` AS `PCATEGORY`,`cu`.`PCHARGES` AS `PCHARGES`,`cu`.`PDISC` AS `PDISC`,`cu`.`PFINALAMT` AS `PFINALAMT`,`cu`.`PRESULT` AS `PRESULT`,`cu`.`PCURRCODE` AS `PCURRCODE`,`cu`.`PCHARGE` AS `PCHARGE`,`cu`.`PREQTIME` AS `PREQTIME`,`cu`.`PPAYTIME` AS `PPAYTIME`,`cu`.`PPAYSTATUS` AS `PPAYSTATUS`,`cu`.`EXTN1` AS `EXTN1`,`cu`.`EXTN2` AS `EXTN2`,`cu`.`EXTN3` AS `EXTN3`,`cu`.`EXTN4` AS `EXTN4`,`cu`.`ITEM_TYPE` AS `ITEM_TYPE`,`cu`.`CHARGE_TYPE` AS `CHARGE_TYPE`,`cu`.`DISCOUNT_TYPE` AS `DISCOUNT_TYPE`,`cu`.`PAYMENT_TYPE` AS `PAYMENT_TYPE`,`cu`.`MERCHANT_REC_ID` AS `MERCHANT_REC_ID`,`cu`.`CUSTOMER_REC_ID` AS `CUSTOMER_REC_ID`,`cu`.`CUSTOMER_ACC_REC_ID` AS `CUSTOMER_ACC_REC_ID`,`cu`.`CREDIT_APPL_DATE` AS `CREDIT_APPL_DATE`,`cu`.`CREDIT_PLAN` AS `CREDIT_PLAN`,`cu`.`CREDIT_APP_DATE` AS `CREDIT_APP_DATE` from ((((`merchant_credit_request` `ac` left join `institution` `inst` on((`ac`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `merchant_payment` `cu`) where ((`ac`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ac`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ac`.`PAYMENT_REQUEST_ID` = `cu`.`Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `card_code_view`
--

/*!50001 DROP VIEW IF EXISTS `card_code_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `card_code_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CARDCODE` AS `CARDCODE`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`ACC_ID` AS `ACC_ID`,`blr`.`CARD_CATEGORY` AS `CARD_CATEGORY`,`blr`.`FROM_DATE` AS `FROM_DATE`,`blr`.`TO_DATE` AS `TO_DATE`,`blr`.`CARD_STATUS` AS `CARD_STATUS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`card_code` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_customer_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `rep_customer_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_customer_stat_view` AS select `customer_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`customer_view`.`IName` AS `INSTITUTION`,`customer_view`.`CATEGORY` AS `CATEGORY`,`customer_view`.`CURR_APP_STATUS_NAME` AS `STATUS`,count(0) AS `COUNT` from `customer_view` group by `customer_view`.`INSTITUTION_ID`,`customer_view`.`IName`,`customer_view`.`CATEGORY`,`customer_view`.`CURR_APP_STATUS_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_category_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_category_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_category_view` AS select `cc`.`Id` AS `Id`,`cc`.`CATEGORY` AS `CATEGORY`,`cc`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cc`.`CHARGE_TYPE` AS `CHARGE_TYPE`,`cc`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`cc`.`PER_DAY_LIMIT` AS `PER_DAY_LIMIT`,`cc`.`PER_TRAN_LIMIT` AS `PER_TRAN_LIMIT`,`cc`.`MIN_TRAN_LIMIT` AS `MIN_TRAN_LIMIT`,`cc`.`MADE_BY` AS `MADE_BY`,`cc`.`MADE_AT` AS `MADE_AT`,`cc`.`CHECKED_BY` AS `CHECKED_BY`,`cc`.`CHECKED_AT` AS `CHECKED_AT`,`cc`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cc`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cc`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cc`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cc`.`RSTATUS` AS `RSTATUS`,`cc`.`CREATED_BY` AS `CREATED_BY`,`cc`.`CREATED_AT` AS `CREATED_AT`,'dummy' AS `SERVICE_ID`,`cc`.`MODIFIED_AT` AS `MODIFIED_AT`,`cc`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`customer_category` `cc` left join `institution` `inst` on((`cc`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`cc`.`RSTATUS` = `sc`.`STATUS_ID`) and (`cc`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customer_creation_history`
--

/*!50001 DROP VIEW IF EXISTS `report_customer_creation_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customer_creation_history` AS select `c`.`cname` AS `CUST_NAME`,`c`.`MOBILE` AS `CUST_MOB`,`c`.`VAL_ACC` AS `CUST_AC`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`MADE_BY`)) AS `CREATED_BY`,`c`.`MADE_AT` AS `CREATED_AT`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CHECKED_BY`)) AS `CHECKED_BY`,`c`.`CHECKED_AT` AS `CHECKED_AT`,date_format(`c`.`MADE_AT`,'%Y%m%d') AS `DATEVAL` from `customer` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kits_bulk_uplds_view`
--

/*!50001 DROP VIEW IF EXISTS `kits_bulk_uplds_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kits_bulk_uplds_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FILE_NAME` AS `FILE_NAME`,`blr`.`NO_OF_REC` AS `NO_OF_REC`,`blr`.`STATUS` AS `STATUS`,`blr`.`BATCH_CODE` AS `BATCH_CODE`,`blr`.`SERVICE_TITLE` AS `SERVICE_TITLE`,`blr`.`DESCRIPTION` AS `DESCRIPTION`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`kits_bulk_uplds` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `account_request_view`
--

/*!50001 DROP VIEW IF EXISTS `account_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `account_request_view` AS (select `er`.`Id` AS `Id`,`er`.`ACCRECID` AS `ACCRECID`,`er`.`ACCNUM` AS `ACCNUM`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`er`.`COMMENTS` AS `COMMENTS`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`account_request` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cbib_bank_view`
--

/*!50001 DROP VIEW IF EXISTS `cbib_bank_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cbib_bank_view` AS (select `atp`.`Id` AS `Id`,`atp`.`BANK_CODE` AS `BANK_CODE`,`atp`.`BANK_NAME` AS `BANK_NAME`,`atp`.`FTACC` AS `FTACC`,`atp`.`CHARGESACC` AS `CHARGESACC`,`atp`.`CHARGE_CATEGORY` AS `CHARGE_CATEGORY`,`atp`.`STATUS_CODE` AS `STATUS_CODE`,`atp`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atp`.`MADE_BY` AS `MADE_BY`,`atp`.`MADE_AT` AS `MADE_AT`,`atp`.`CHECKED_BY` AS `CHECKED_BY`,`atp`.`CHECKED_AT` AS `CHECKED_AT`,`atp`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atp`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atp`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atp`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atp`.`RSTATUS` AS `RSTATUS`,`atp`.`CREATED_BY` AS `CREATED_BY`,`atp`.`CREATED_AT` AS `CREATED_AT`,`atp`.`MODIFIED_AT` AS `MODIFIED_AT`,`atp`.`MODIFIED_BY` AS `MODIFIED_BY`,`atp`.`BANK_CHARGES_ACCOUNT` AS `BANK_CHARGES_ACCOUNT`,`atp`.`MF_CHARGES_ACCOUNT` AS `MF_CHARGES_ACCOUNT`,`atp`.`BANK_CHARGES_CATEGORY` AS `BANK_CHARGES_CATEGORY`,`atp`.`MF_CHARGES_CATEGORY` AS `MF_CHARGES_CATEGORY`,`atp`.`BANK_URL` AS `BANK_URL`,`atp`.`BANK_ENC_KEY` AS `BANK_ENC_KEY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cbib_bank` `atp` left join `institution` `inst` on((`atp`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atp`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atp`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kits_other_bank_view`
--

/*!50001 DROP VIEW IF EXISTS `kits_other_bank_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kits_other_bank_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BANK_ID` AS `BANK_ID`,`blr`.`BANK_NAME` AS `BANK_NAME`,`blr`.`SWIFT_CODE` AS `SWIFT_CODE`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`REF_BIN_CODE` AS `REF_BIN_CODE`,`blr`.`REF_BRANCH_CODE` AS `REF_BRANCH_CODE`,`blr`.`REF_ACCOUNT_NUMBER` AS `REF_ACCOUNT_NUMBER`,`blr`.`REF_OTHER_BANK` AS `REF_OTHER_BANK`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`kits_other_bank` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kits_accounts_view`
--

/*!50001 DROP VIEW IF EXISTS `kits_accounts_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kits_accounts_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CURRENCY` AS `CURRENCY`,`blr`.`NATIONAL_ID` AS `NATIONAL_ID`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`blr`.`ACCEXTN1` AS `ACCEXTN1`,`blr`.`ACCEXTN2` AS `ACCEXTN2`,`blr`.`ACCEXTN3` AS `ACCEXTN3`,`blr`.`ACCEXTN4` AS `ACCEXTN4`,`blr`.`ACCEXTN5` AS `ACCEXTN5`,`blr`.`ACCEXTN6` AS `ACCEXTN6`,`blr`.`ACCEXTN7` AS `ACCEXTN7`,`blr`.`ACCEXTN8` AS `ACCEXTN8`,`blr`.`ACCEXTN9` AS `ACCEXTN9`,`blr`.`ACCEXTN10` AS `ACCEXTN10`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`ALT_ACC_ID` AS `ALT_ACC_ID`,`blr`.`JOINT_ACCOUNT` AS `JOINT_ACCOUNT`,`blr`.`JOINT_ACCOUNT_MANDATES` AS `JOINT_ACCOUNT_MANDATES`,`blr`.`PRIMARY_ACCOUNT` AS `PRIMARY_ACCOUNT`,`blr`.`group_code` AS `group_code`,`blr`.`ACCCTYPE` AS `ACCCTYPE`,`blr`.`card_num` AS `card_num`,`blr`.`card_expiry` AS `card_expiry`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`kits_accounts` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_dtc_bp_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_dtc_bp_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_dtc_bp_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`BPOPERATOR` AS `BPOPERATOR`,`er`.`BPAMOUNT` AS `BPAMOUNT`,`er`.`BPMOBILE` AS `BPMOBILE`,`er`.`BPTYPE` AS `BPTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_dtc_bp_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_dtc_recharge_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_dtc_recharge_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_dtc_recharge_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`RCOPERATOR` AS `RCOPERATOR`,`er`.`RCAMOUNT` AS `RCAMOUNT`,`er`.`RCMOBILE` AS `RCMOBILE`,`er`.`RCTYPE` AS `RCTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_dtc_recharge_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `goods_category_view`
--

/*!50001 DROP VIEW IF EXISTS `goods_category_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `goods_category_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CAT_NAME` AS `CAT_NAME`,`blr`.`CAT_TYPE` AS `CAT_TYPE`,`blr`.`CAT_DESCRIPTION` AS `CAT_DESCRIPTION`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`goods_category` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_permissions_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_permissions_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_permissions_view` AS select `cgsl`.`Id` AS `Id`,`cgsl`.`CGID` AS `CGID`,`cgsl`.`SLID` AS `SLID`,`cgsl`.`MADE_BY` AS `MADE_BY`,`cgsl`.`MADE_AT` AS `MADE_AT`,`cgsl`.`CHECKED_BY` AS `CHECKED_BY`,`cgsl`.`CHECKED_AT` AS `CHECKED_AT`,`cgsl`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cgsl`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cgsl`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cgsl`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cgsl`.`RSTATUS` AS `RSTATUS`,`cgsl`.`CREATED_BY` AS `CREATED_BY`,`cgsl`.`CREATED_AT` AS `CREATED_AT`,`cgsl`.`MODIFIED_AT` AS `MODIFIED_AT`,`cgsl`.`MODIFIED_BY` AS `MODIFIED_BY`,`ccv`.`CATEGORY` AS `CATEGORY`,`ccv`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ccv`.`IName` AS `INAME`,`sl`.`SCODE` AS `SCODE`,`sl`.`SNAME` AS `SNAME`,`sl`.`SPARENT` AS `SPARENT` from ((`customer_group_service_list` `cgsl` join `customer_category_view` `ccv`) join `service_list` `sl`) where ((`cgsl`.`CGID` = `ccv`.`Id`) and (`cgsl`.`SLID` = `sl`.`Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mobile_menu_map_view`
--

/*!50001 DROP VIEW IF EXISTS `mobile_menu_map_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mobile_menu_map_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MENU_TYPE` AS `MENU_TYPE`,`blr`.`SCREEN_ID` AS `SCREEN_ID`,`blr`.`FTEXT` AS `FTEXT`,`blr`.`FHEIGHT` AS `FHEIGHT`,`blr`.`FWIDTH` AS `FWIDTH`,`blr`.`FSEQ` AS `FSEQ`,`blr`.`FSESSCONT` AS `FSESSCONT`,`blr`.`FCONTTYPE` AS `FCONTTYPE`,`blr`.`FFLDLEN` AS `FFLDLEN`,`blr`.`FFLDCODE` AS `FFLDCODE`,`blr`.`FFLDTYPE` AS `FFLDTYPE`,`blr`.`NEWSESS` AS `NEWSESS`,`blr`.`ACTIVE_FLAG` AS `ACTIVE_FLAG`,`blr`.`PARENT_ID` AS `PARENT_ID`,`blr`.`SERVICE_ID` AS `SERVICE_ID`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`LANGCODE` AS `LANGCODE`,`blr`.`CONTENT_LENGTH` AS `CONTENT_LENGTH`,`blr`.`ACTION_ID` AS `ACTION_ID`,`blr`.`OVERRIDE_CODE` AS `OVERRIDE_CODE`,`blr`.`LANG2_MSG` AS `LANG2_MSG`,`blr`.`LANG3_MSG` AS `LANG3_MSG`,`blr`.`LANG4_MSG` AS `LANG4_MSG`,`blr`.`ACCESS_CODE` AS `ACCESS_CODE`,`blr`.`USSD` AS `USSD`,`blr`.`WAP` AS `WAP`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`IMAGE_ICON` AS `IMAGE_ICON`,`blr`.`ALLOW_VIRTUAL_AGENT` AS `ALLOW_VIRTUAL_AGENT`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mobile_menu_map` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mvisa_ext_merchant_view`
--

/*!50001 DROP VIEW IF EXISTS `mvisa_ext_merchant_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mvisa_ext_merchant_view` AS (select `blr`.`Id` AS `Id`,`blr`.`EXT_MV_MERC_ID` AS `EXT_MV_MERC_ID`,`blr`.`MERC_NAME` AS `MERC_NAME`,`blr`.`PRIMARY_ID` AS `PRIMARY_ID`,`blr`.`SEC_ID` AS `SEC_ID`,`blr`.`MCC` AS `MCC`,`blr`.`CITY` AS `CITY`,`blr`.`CONVFEEPERC` AS `CONVFEEPERC`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mvisa_ext_merchant` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `eod_tran_master_view`
--

/*!50001 DROP VIEW IF EXISTS `eod_tran_master_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `eod_tran_master_view` AS (select `blr`.`Id` AS `Id`,`blr`.`to_account` AS `TO_ACCOUNT`,`blr`.`FROM_ACCOUNT` AS `FROM_ACCOUNT`,`blr`.`AMOUNT` AS `AMOUNT`,`blr`.`TRANSACTION_TYPE` AS `TRANSACTION_TYPE`,`blr`.`PERCENTAGE` AS `PERCENTAGE`,`blr`.`SOURCE_AMOUNT` AS `SOURCE_AMOUNT`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`eod_tran_master` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mvisa_agent_view`
--

/*!50001 DROP VIEW IF EXISTS `mvisa_agent_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mvisa_agent_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`IDNUM` AS `IDNUM`,`blr`.`PINNUM` AS `PINNUM`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`IDPRESENT` AS `IDPRESENT`,`blr`.`POST_ADDR` AS `POST_ADDR`,`blr`.`BUS_NAME` AS `BUS_NAME`,`blr`.`BUS_PIN` AS `BUS_PIN`,`blr`.`BUS_TYPE` AS `BUS_TYPE`,`blr`.`BUS_CODE` AS `BUS_CODE`,`blr`.`BUS_LOC` AS `BUS_LOC`,`blr`.`BUS_PSTADDR` AS `BUS_PSTADDR`,`blr`.`BUS_PSTCODE` AS `BUS_PSTCODE`,`blr`.`ISBUS_PIN_PRE` AS `ISBUS_PIN_PRE`,`blr`.`BUS_CERT` AS `BUS_CERT`,`blr`.`BANK_CODE` AS `BANK_CODE`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`BANK_ACC_NUM` AS `BANK_ACC_NUM`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`MERC_DISC_RATE` AS `MERC_DISC_RATE`,`blr`.`MERC_FULL_ID` AS `MERC_FULL_ID`,`blr`.`MERC_ID` AS `MERC_ID`,`blr`.`NOTF_METHOD` AS `NOTF_METHOD`,`blr`.`NOTF_DEVID` AS `NOTF_DEVID`,`blr`.`PUSH_URL` AS `PUSH_URL`,`blr`.`ALIAS_NAME` AS `ALIAS_NAME`,`blr`.`PRIMARY_CARD` AS `PRIMARY_CARD`,`blr`.`NOTIF_MAIL` AS `NOTIF_MAIL`,`blr`.`AGENT_PWD` AS `AGENT_PWD`,`blr`.`AGENT_INIT_PWD` AS `AGENT_INIT_PWD`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mvisa_agent` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_sys_user_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `rep_sys_user_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_sys_user_stat_view` AS select `suc`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`suc`.`IName` AS `INSTITUTION`,`suc`.`ROLENAME` AS `ROLE`,`suc`.`CURR_APP_STATUS_NAME` AS `STATUS`,count(0) AS `COUNT` from `system_user_view` `suc` group by `suc`.`INSTITUTION_ID`,`suc`.`IName`,`suc`.`ROLENAME`,`suc`.`CURR_APP_STATUS_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mfs_permissions_view`
--

/*!50001 DROP VIEW IF EXISTS `mfs_permissions_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mfs_permissions_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BILLER_NAME` AS `BILLER_NAME`,`blr`.`BILLER_ACNO` AS `BILLER_ACNO`,`blr`.`BILLER_TYPE` AS `BILLER_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`biller` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `funds_transfer_transaction_view`
--

/*!50001 DROP VIEW IF EXISTS `funds_transfer_transaction_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `funds_transfer_transaction_view` AS select `ftt`.`Id` AS `Id`,`ftt`.`FTFROM` AS `FTFROM`,`ftt`.`FTTO` AS `FTTO`,`ftt`.`FTAMOUNT` AS `FTAMOUNT`,`ftt`.`FTRESULT` AS `FTRESULT`,`ftt`.`FTCURRCODE` AS `FTCURRCODE`,`ftt`.`FTCHARGE` AS `FTCHARGE`,`ftt`.`FTTRANTIME` AS `FTTRANTIME`,`ftt`.`FTCIF` AS `FTCIF`,`ftt`.`FTSOURCE` AS `FTSOURCE`,`ftt`.`FTPHONEID` AS `FTPHONEID`,`ftt`.`FTSESSIONID` AS `FTSESSIONID`,`ftt`.`FTREFNO` AS `FTREFNO`,`ftt`.`FTRESULTCODE` AS `FTRESULTCODE`,`ftt`.`ERRMSG` AS `ERRMSG`,`ftt`.`RSTATUS` AS `RSTATUS`,`ftt`.`CREATED_BY` AS `CREATED_BY`,`ftt`.`CREATED_AT` AS `CREATED_AT`,`ftt`.`MODIFIED_AT` AS `MODIFIED_AT`,`ftt`.`MODIFIED_BY` AS `MODIFIED_BY`,`ftt`.`FTTYPE` AS `FTTYPE`,`ftt`.`FTSUBCHARGE` AS `FTSUBCHARGE`,`ftt`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ftt`.`FTSTEPFAILED` AS `FTSTEPFAILED`,`ftt`.`RESP1` AS `RESP1`,`ftt`.`RESP2` AS `RESP2`,`ftt`.`RESP3` AS `RESP3`,`ftt`.`RESP4` AS `RESP4`,`ftt`.`FTCOMMENT` AS `FTCOMMENT`,`ftt`.`beneficiary_bank` AS `beneficiary_bank`,`ftt`.`beneficiary_branch` AS `beneficiary_branch`,`ftt`.`beneficiary_currency` AS `beneficiary_currency`,`ftt`.`beneficiary_mobile` AS `beneficiary_mobile`,`ftt`.`CAT1` AS `CAT1`,`ftt`.`CAT2` AS `CAT2`,`ftt`.`TRAN_DATETS` AS `TRAN_DATETS`,`ftt`.`CAT3` AS `CAT3`,`ftt`.`curr_code` AS `curr_code`,`ftt`.`tip_amt` AS `tip_amt`,`ftt`.`tran_amtf` AS `tran_amtf`,`ftt`.`ref_tab_id` AS `ref_tab_id`,`ftt`.`tip_and_fee` AS `tip_and_fee`,`ftt`.`conv_fee_amt` AS `conv_fee_amt`,(case `ftt`.`FTRESULTCODE` when 1 then 'Yes' when 0 then 'No' end) AS `RESULTCODE`,'STATUS_NAME' AS `STATUS_NAME`,'STATUS_NAME' AS `CURR_APP_STATUS_NAME`,'4' AS `IName` from `funds_transfer_transaction` `ftt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agency_info_busd_view`
--

/*!50001 DROP VIEW IF EXISTS `agency_info_busd_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agency_info_busd_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MASTER_AG_ID` AS `MASTER_AG_ID`,`blr`.`BName` AS `BName`,`blr`.`Desig` AS `Desig`,`blr`.`Nationality` AS `Nationality`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`NATIONAL_ID` AS `NATIONAL_ID`,`blr`.`EMAIL_ID` AS `EMAIL_ID`,`blr`.`MOBILE_NUM` AS `MOBILE_NUM`,`blr`.`PREF_LANG` AS `PREF_LANG`,`blr`.`NOTIF_TYPE` AS `NOTIF_TYPE`,`blr`.`CREATED_UID` AS `CREATED_UID`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agency_info_busd` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `special_biller_charge_type_range_view`
--

/*!50001 DROP VIEW IF EXISTS `special_biller_charge_type_range_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `special_biller_charge_type_range_view` AS select `s`.`Id` AS `Id`,`s`.`BILLER_ID` AS `BILLER_ID`,`s`.`RANGE_FROM` AS `RANGE_FROM`,`s`.`RANGE_TO` AS `RANGE_TO`,`s`.`CHARGE_TYPE_CODE` AS `CHARGE_TYPE_CODE`,`s`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`s`.`CHARGE_VALUE2` AS `CHARGE_VALUE2`,`s`.`CHARGE_VALUE3` AS `CHARGE_VALUE3`,`s`.`CHARGE_VALUE4` AS `CHARGE_VALUE4`,`s`.`MADE_BY` AS `MADE_BY`,`s`.`MADE_AT` AS `MADE_AT`,`s`.`CHECKED_BY` AS `CHECKED_BY`,`s`.`CHECKED_AT` AS `CHECKED_AT`,`s`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`s`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`s`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`s`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`s`.`RSTATUS` AS `RSTATUS`,`s`.`CREATED_BY` AS `CREATED_BY`,`s`.`CREATED_AT` AS `CREATED_AT`,`s`.`MODIFIED_AT` AS `MODIFIED_AT`,`s`.`MODIFIED_BY` AS `MODIFIED_BY`,`s`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`b`.`BILLER_NAME` AS `BILLER_NAME`,`b`.`BILLER_TYPE` AS `BILLER_TYPE`,`b`.`BILLER_ACNO` AS `BILLER_ACNO`,`sc`.`STATUS_NAME` AS `STATUS_NAME` from ((`special_biller_charge_type_range` `s` join `biller` `b`) join `status_code` `sc`) where ((`s`.`BILLER_ID` = `b`.`Id`) and (`s`.`CURR_APP_STATUS` = `sc`.`STATUS_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `nfc_category_update_view`
--

/*!50001 DROP VIEW IF EXISTS `nfc_category_update_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `nfc_category_update_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CATEGORY_CODE` AS `CATEGORY_CODE`,`blr`.`CATEGORY_NAME` AS `CATEGORY_NAME`,`blr`.`CURR_PRICE` AS `CURR_PRICE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`nfc_category_update` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cbaccount_view`
--

/*!50001 DROP VIEW IF EXISTS `cbaccount_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cbaccount_view` AS select `ac`.`Id` AS `Id`,`ac`.`ACC_NUM` AS `ACC_NUM`,`ac`.`ALIAS` AS `ALIAS`,`ac`.`CUST_ID` AS `CUST_ID`,`ac`.`CURRENCY` AS `CURRENCY`,`ac`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ac`.`MADE_BY` AS `MADE_BY`,`ac`.`MADE_AT` AS `MADE_AT`,`ac`.`CHECKED_BY` AS `CHECKED_BY`,`ac`.`CHECKED_AT` AS `CHECKED_AT`,`ac`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ac`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ac`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ac`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ac`.`RSTATUS` AS `RSTATUS`,`ac`.`CREATED_BY` AS `CREATED_BY`,`ac`.`CREATED_AT` AS `CREATED_AT`,`ac`.`MODIFIED_AT` AS `MODIFIED_AT`,`ac`.`MODIFIED_BY` AS `MODIFIED_BY`,`ac`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`ac`.`REPORT_FREQ` AS `REPORT_FREQ`,`ac`.`ALLOW_SMS` AS `ALLOW_SMS`,`ac`.`ALLOW_EMAIL` AS `ALLOW_EMAIL`,`ac`.`SMS_THRES` AS `SMS_THRES`,`ac`.`EMAIL_THRES` AS `EMAIL_THRES`,`ac`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`ac`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`ac`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`ac`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`ac`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`ac`.`ADDTNL_SMS1` AS `ADDTNL_SMS1`,`ac`.`ADDTNL_SMS2` AS `ADDTNL_SMS2`,`ac`.`ADDTNL_SMS3` AS `ADDTNL_SMS3`,`ac`.`ADDTNL_SMS4` AS `ADDTNL_SMS4`,`ac`.`ADDTNL_SMS5` AS `ADDTNL_SMS5`,`ac`.`ACCEXTN1` AS `ACCEXTN1`,`ac`.`ACCEXTN2` AS `ACCEXTN2`,`ac`.`ACCEXTN3` AS `ACCEXTN3`,`ac`.`ACCEXTN4` AS `ACCEXTN4`,`ac`.`ACCEXTN5` AS `ACCEXTN5`,`ac`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`ac`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`ac`.`CURR_BALANCE` AS `CURR_BALANCE`,`ac`.`CURR_BALANCE_TYPE` AS `CURR_BALANCE_TYPE`,`ac`.`CURR_BAL_LASTUPD` AS `CURR_BAL_LASTUPD`,`ac`.`BRANCH_CODE` AS `BRANCH_CODE`,`ac`.`ALLOW_MOBILE` AS `ALLOW_MOBILE`,`ac`.`VIRTUAL_ACCOUNT` AS `VIRTUAL_ACCOUNT`,`ac`.`ALT_ACC_ID` AS `ALT_ACC_ID`,`ac`.`ACCTYPE` AS `ACCTYPE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`cu`.`cname` AS `CNAME` from ((((`cbaccount` `ac` left join `institution` `inst` on((`ac`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `customer` `cu`) where ((`ac`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ac`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ac`.`CUST_ID` = `cu`.`CIF`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_funds_trnsf_tran_audit`
--

/*!50001 DROP VIEW IF EXISTS `rep_funds_trnsf_tran_audit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_funds_trnsf_tran_audit` AS select `ft`.`Id` AS `Id`,`ft`.`FROM_ACCOUNT` AS `FROM_ACCOUNT`,`ft`.`TO_ACCOUNT` AS `TO_ACCOUNT`,`ft`.`REF_NO` AS `REF_NO`,`ft`.`FROM_BENE` AS `FROM_BENE`,`ft`.`TO_BENE` AS `TO_BENE`,`ft`.`BENE_TYPE` AS `BENE_TYPE`,`ft`.`BENE_CODE` AS `BENE_CODE`,`ft`.`BENE_BANK` AS `BENE_BANK`,`ft`.`BENE_BRANCH` AS `BENE_BRANCH`,`ft`.`BENE_MOBILE` AS `BENE_MOBILE`,`ft`.`CURRENCY` AS `CURRENCY`,`ft`.`CUST_MOBILE` AS `CUST_MOBILE`,`ft`.`CUST_REF2` AS `CUST_REF2`,`ft`.`BEN_CURR` AS `BEN_CURR`,`ft`.`BEN_COUNTRY` AS `BEN_COUNTRY`,`ft`.`AMOUNT` AS `AMOUNT`,`ft`.`TRAN_TIME` AS `TRAN_TIME`,`ft`.`TRAN_RESULT_FLAG` AS `TRAN_RESULT_FLAG`,`ft`.`TRAN_RESULT` AS `TRAN_RESULT`,`ft`.`FT_TYPE` AS `FT_TYPE`,`ft`.`CUSTOMER_ID` AS `CUSTOMER_ID`,`ft`.`CUSTOMER_CATEGORY` AS `CUSTOMER_CATEGORY`,`ft`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ft`.`EXTN1` AS `EXTN1`,`ft`.`EXTN2` AS `EXTN2`,`ft`.`EXTN3` AS `EXTN3`,`ft`.`EXTN4` AS `EXTN4`,`ft`.`EXTN5` AS `EXTN5`,`ft`.`rstatus` AS `RSTATUS`,`ft`.`CREATED_BY` AS `CREATED_BY`,`ft`.`CREATED_AT` AS `CREATED_AT`,`ft`.`MODIFIED_AT` AS `MODIFIED_AT`,`ft`.`MODIFIED_BY` AS `MODIFIED_BY`,`ft`.`MFREVACC` AS `MFREVACC`,`ft`.`MFREVAMT` AS `MFREVAMT`,`ft`.`EXCACC` AS `EXCACC`,`ft`.`EXCAMT` AS `EXCAMT`,date_format(`ft`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `funds_transfer_transaction_audit` `ft` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `full_stmt_req_view`
--

/*!50001 DROP VIEW IF EXISTS `full_stmt_req_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `full_stmt_req_view` AS (select `blr`.`Id` AS `Id`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`REQ_MOB` AS `REQ_MOB`,`blr`.`REQ_EMAIL` AS `REQ_EMAIL`,`blr`.`REQ_ACC` AS `REQ_ACC`,`blr`.`REQ_FORMAT` AS `REQ_FORMAT`,`blr`.`REQ_FRM_DATE` AS `REQ_FRM_DATE`,`blr`.`REQ_TO_DATE` AS `REQ_TO_DATE`,`blr`.`COMMENTS` AS `COMMENTS`,`blr`.`REQ_EMAIL1` AS `REQ_EMAIL1`,`blr`.`REQ_EMAIL2` AS `REQ_EMAIL2`,`blr`.`REQ_EMAIL3` AS `REQ_EMAIL3`,`blr`.`REQ_EMAIL4` AS `REQ_EMAIL4`,`blr`.`REQ_EMAIL5` AS `REQ_EMAIL5`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`full_stmt_req` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cheque_deposit_view`
--

/*!50001 DROP VIEW IF EXISTS `cheque_deposit_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cheque_deposit_view` AS (select `er`.`Id` AS `Id`,`er`.`FROM_ACCOUNT_NUMBER` AS `FROM_ACCOUNT_NUMBER`,`er`.`TO_ACCOUNT_NUMBER` AS `TO_ACCOUNT_NUMBER`,`er`.`CALL_BACK` AS `CALL_BACK`,`er`.`CALLED_PERSON` AS `CALLED_PERSON`,`er`.`SIGNATURE_VERIFIED` AS `SIGNATURE_VERIFIED`,`er`.`BGDATETIME` AS `BGDATETIME`,`er`.`CHEQUE_NUMBER` AS `CHEQUE_NUMBER`,`er`.`MOBILE_NUMBER` AS `MOBILE_NUMBER`,`er`.`IMAGEURL1` AS `IMAGEURL1`,`er`.`IMAGEURL2` AS `IMAGEURL2`,`er`.`IMAGEURL3` AS `IMAGEURL3`,`er`.`IMAGEURL4` AS `IMAGEURL4`,`er`.`IMAGEURL5` AS `IMAGEURL5`,`er`.`CHQAMT` AS `CHQAMT`,`er`.`FROM_CUST_ID` AS `FROM_CUST_ID`,`er`.`FROM_CUST_NAME` AS `FROM_CUST_NAME`,`er`.`TO_CUST_ID` AS `TO_CUST_ID`,`er`.`TO_CUST_NAME` AS `TO_CUST_NAME`,`er`.`SUBMITTED_AT` AS `SUBMITTED_AT`,`er`.`EXTN1` AS `EXTN1`,`er`.`EXTN2` AS `EXTN2`,`er`.`EXTN3` AS `EXTN3`,`er`.`EXTN4` AS `EXTN4`,`er`.`EXTN5` AS `EXTN5`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`CHQEXTN1` AS `CHQEXTN1`,`er`.`CHQEXTN2` AS `CHQEXTN2`,`er`.`CHQEXTN3` AS `CHQEXTN3`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cheque_deposit` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agency_info_update_view`
--

/*!50001 DROP VIEW IF EXISTS `agency_info_update_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agency_info_update_view` AS (select `blr`.`Id` AS `Id`,`blr`.`AGENCY_INFO_REC_ID` AS `AGENCY_INFO_REC_ID`,`blr`.`REF_CUST_REC_ID` AS `REF_CUST_REC_ID`,`blr`.`REF_CUST_CIF` AS `REF_CUST_CIF`,`blr`.`REF_CUST_MOBILE` AS `REF_CUST_MOBILE`,`blr`.`REF_CUST_NAME` AS `REF_CUST_NAME`,`blr`.`DOMIBRNCH` AS `DOMIBRNCH`,`blr`.`NATIONALTY` AS `NATIONALTY`,`blr`.`PROFCONT1` AS `PROFCONT1`,`blr`.`PROFCONT2` AS `PROFCONT2`,`blr`.`SERVPK` AS `SERVPK`,`blr`.`BRNCHCODE` AS `BRNCHCODE`,`blr`.`PROFPROV` AS `PROFPROV`,`blr`.`PROFAGCODE` AS `PROFAGCODE`,`blr`.`TRDNAME` AS `TRDNAME`,`blr`.`PSTADDR` AS `PSTADDR`,`blr`.`LRNUM` AS `LRNUM`,`blr`.`PSTCITY` AS `PSTCITY`,`blr`.`PSTZIP` AS `PSTZIP`,`blr`.`BUSLOC` AS `BUSLOC`,`blr`.`PHYADDR` AS `PHYADDR`,`blr`.`BUSSTAT` AS `BUSSTAT`,`blr`.`BUSNAME` AS `BUSNAME`,`blr`.`BUSDESIG` AS `BUSDESIG`,`blr`.`BUSNATIONALITY` AS `BUSNATIONALITY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`SUB_AGENCY` AS `SUB_AGENCY`,`blr`.`MAST_AGCODE` AS `MAST_AGCODE`,`blr`.`served_by` AS `served_by`,`blr`.`agextn3` AS `agextn3`,`blr`.`cb_min_amt` AS `cb_min_amt`,`blr`.`cb_max_amt` AS `cb_max_amt`,`blr`.`serv_comm` AS `serv_comm`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agency_info_update` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `joint_account_pending_approvals_view`
--

/*!50001 DROP VIEW IF EXISTS `joint_account_pending_approvals_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `joint_account_pending_approvals_view` AS select distinct `joint_account_approvals`.`FT_TRAN_ID` AS `ft_tran_id`,`joint_account_approvals`.`FT_FROM` AS `ft_from`,count(0) AS `cnt`,max(`joint_account_approvals`.`NEXT_REM_TS`) AS `NEXT_REM_TS` from `joint_account_approvals` where (`joint_account_approvals`.`OVERALL_APPROVAL_STATUS` = 'Pending Other Approvals') group by `joint_account_approvals`.`FT_TRAN_ID`,`joint_account_approvals`.`FT_FROM` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `standing_order_execution_view`
--

/*!50001 DROP VIEW IF EXISTS `standing_order_execution_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `standing_order_execution_view` AS select `soe`.`Id` AS `Id`,`soe`.`REF_ORDER_ID` AS `REF_ORDER_ID`,`soe`.`FROMACC` AS `FROMACC`,`soe`.`TOACC` AS `TOACC`,`soe`.`AMOUNT` AS `AMOUNT`,`soe`.`FT_REMARKS` AS `FT_REMARKS`,`soe`.`FT_TRIGGERTS` AS `FT_TRIGGERTS`,`soe`.`FT_RESULT_CODE` AS `FT_RESULT_CODE`,`soe`.`FT_RESULT_MESSAGE` AS `FT_RESULT_MESSAGE`,`soe`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`soe`.`STATUS_CODE` AS `STATUS_CODE`,`soe`.`MADE_BY` AS `MADE_BY`,`soe`.`MADE_AT` AS `MADE_AT`,`soe`.`CHECKED_BY` AS `CHECKED_BY`,`soe`.`CHECKED_AT` AS `CHECKED_AT`,`soe`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`soe`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`soe`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`soe`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`soe`.`RSTATUS` AS `RSTATUS`,`soe`.`CREATED_BY` AS `CREATED_BY`,`soe`.`CREATED_AT` AS `CREATED_AT`,`soe`.`MODIFIED_AT` AS `MODIFIED_AT`,`soe`.`MODIFIED_BY` AS `MODIFIED_BY`,`soe`.`EXEC_DATE` AS `EXEC_DATE`,`soe`.`EXEC_ORDER_NAME` AS `EXEC_ORDER_NAME`,`soe`.`SETUP_CHARGE1` AS `SETUP_CHARGE1`,`soe`.`SETUP_CHARGE2` AS `SETUP_CHARGE2`,`soe`.`CURRENCY_CODE` AS `CURRENCY_CODE`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`sc`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`so`.`ORIG_CUST_ID` AS `ORIG_CUST_ID`,`so`.`ORIG_CUST_NAME` AS `ORIG_CUST_NAME`,`so`.`ORIG_CUST_MOBILE` AS `ORIG_CUST_MOBILE`,`so`.`ORIG_CUST_GROUP` AS `ORIG_CUST_GROUP` from (((`standing_order_execution` `soe` left join `institution` `inst` on((`soe`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `standing_order` `so`) where ((`soe`.`CURR_APP_STATUS` = `sc`.`STATUS_ID`) and (`soe`.`REF_ORDER_ID` = `so`.`Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `join_account_approvercr_view`
--

/*!50001 DROP VIEW IF EXISTS `join_account_approvercr_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `join_account_approvercr_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ORIG_REC_ID` AS `ORIG_REC_ID`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`REG_CUST_ID` AS `REG_CUST_ID`,`blr`.`REG_CUST_NAME` AS `REG_CUST_NAME`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CUST_NAME` AS `CUST_NAME`,`blr`.`MANDATORY` AS `MANDATORY`,`blr`.`ROLE_CODE` AS `ROLE_CODE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`OTP_GEN` AS `OTP_GEN`,`blr`.`OTP_EXP` AS `OTP_EXP`,`blr`.`max_approval_amount` AS `max_approval_amount`,`blr`.`MOB_NUM` AS `MOB_NUM`,`blr`.`ORIG_CIF` AS `ORIG_CIF`,`blr`.`BEN_MOB_NUM` AS `BEN_MOB_NUM`,`blr`.`CHARGS` AS `CHARGS`,`blr`.`PAYDESC` AS `PAYDESC`,`blr`.`BENBANKCODE` AS `BENBANKCODE`,`blr`.`BENBRNCHCODE` AS `BENBRNCHCODE`,`blr`.`BENBRNCHCURR` AS `BENBRNCHCURR`,`blr`.`BENNAME` AS `BENNAME`,`blr`.`BENTYPE` AS `BENTYPE`,`blr`.`SERV_NAME` AS `SERV_NAME`,`blr`.`FULL_MAP` AS `FULL_MAP`,`blr`.`SEQ_CODE` AS `SEQ_CODE`,`blr`.`CATEG_CODE` AS `CATEG_CODE`,`blr`.`UPDATE_STAT` AS `UPDATE_STAT`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`join_account_approvercr` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mfs_menu_item_view`
--

/*!50001 DROP VIEW IF EXISTS `mfs_menu_item_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mfs_menu_item_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MENU_ITEM_CODE` AS `MENU_ITEM_CODE`,`blr`.`MENU_TITLE` AS `MENU_TITLE`,`blr`.`MENU_ICON` AS `MENU_ICON`,`blr`.`MENU_PARENT` AS `MENU_PARENT`,`blr`.`LICENSE_LEVEL` AS `LICENSE_LEVEL`,`blr`.`CATEGORY` AS `CATEGORY`,`blr`.`ROLE_CODE` AS `ROLE_CODE`,`blr`.`FEATURE_CODE` AS `FEATURE_CODE`,`blr`.`SEQ_CODE` AS `SEQ_CODE`,`blr`.`PARENT_MENU_ITEM` AS `PARENT_MENU_ITEM`,`blr`.`PERMIT` AS `PERMIT`,`blr`.`BLOCK` AS `BLOCK`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mfs_menu_item` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_view` AS select `c`.`Id` AS `Id`,`c`.`CIF` AS `CIF`,`c`.`CNAME` AS `CNAME`,`c`.`VAL_ACC` AS `VAL_ACC`,`c`.`NATIONAL_ID` AS `NATIONAL_ID`,`c`.`PASSPORT` AS `PASSPORT`,`c`.`NATIONALITY` AS `NATIONALITY`,`c`.`MOBILE` AS `MOBILE`,`c`.`EMAIL` AS `EMAIL`,`c`.`ID_SUBMITTED` AS `ID_SUBMITTED`,`c`.`ID_VERIFIED` AS `ID_VERIFIED`,`c`.`PIN_NO` AS `PIN_NO`,`c`.`TERMS_SIGNED` AS `TERMS_SIGNED`,`c`.`UG_ISSUED` AS `UG_ISSUED`,`c`.`PREF_LANG` AS `PREF_LANG`,`c`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`c`.`MADE_BY` AS `MADE_BY`,`c`.`MADE_AT` AS `MADE_AT`,`c`.`CHECKED_BY` AS `CHECKED_BY`,`c`.`CHECKED_AT` AS `CHECKED_AT`,`c`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`c`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`c`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`c`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`c`.`RSTATUS` AS `RSTATUS`,`c`.`CREATED_BY` AS `CREATED_BY`,`c`.`CREATED_AT` AS `CREATED_AT`,`c`.`MODIFIED_AT` AS `MODIFIED_AT`,`c`.`MODIFIED_BY` AS `MODIFIED_BY`,`c`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`c`.`CUST_CAT` AS `CUST_CAT`,`c`.`ALLOWED_PHONE_TYPE1` AS `ALLOWED_PHONE_TYPE1`,`c`.`ALLOWED_PHONE_TYPE2` AS `ALLOWED_PHONE_TYPE2`,`c`.`ALLOWED_PHONE_TYPE3` AS `ALLOWED_PHONE_TYPE3`,`c`.`ALLOWED_PHONE_ID1` AS `ALLOWED_PHONE_ID1`,`c`.`ALLOWED_PHONE_ID2` AS `ALLOWED_PHONE_ID2`,`c`.`ALLOWED_PHONE_ID3` AS `ALLOWED_PHONE_ID3`,`c`.`ALLOWED_PHONE_IDM1` AS `ALLOWED_PHONE_IDM1`,`c`.`ALLOWED_PHONE_IDA1` AS `ALLOWED_PHONE_IDA1`,`c`.`TPIN_NO` AS `TPIN_NO`,`c`.`AUTH_FAIL_PIN` AS `AUTH_FAIL_PIN`,`c`.`AUTH_FAIL_TPIN` AS `AUTH_FAIL_TPIN`,`c`.`REPORT_FREQ` AS `REPORT_FREQ`,`c`.`CUST_EXTN1` AS `CUST_EXTN1`,`c`.`CUST_EXTN2` AS `CUST_EXTN2`,`c`.`CUST_EXTN3` AS `CUST_EXTN3`,`c`.`CUST_EXTN4` AS `CUST_EXTN4`,`c`.`INITIAL_MPIN` AS `INITIAL_MPIN`,`c`.`INITIAL_TPIN` AS `INITIAL_TPIN`,`c`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`c`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`c`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`c`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`c`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`c`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`c`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`c`.`CUSEXTN11` AS `CUSEXTN11`,`c`.`CUSEXTN12` AS `CUSEXTN12`,`c`.`CUSEXTN13` AS `CUSEXTN13`,`c`.`CUSEXTN14` AS `CUSEXTN14`,`c`.`CUSEXTN15` AS `CUSEXTN15`,`c`.`MPIN_FLDATTMPT` AS `MPIN_FLDATTMPT`,`c`.`LAST_ATTMPTSRC` AS `LAST_ATTMPTSRC`,`c`.`LAST_ATTMPTVER` AS `LAST_ATTMPTVER`,`c`.`UNLOCK_TIME` AS `UNLOCK_TIME`,`c`.`MOBILE_ACCESS` AS `MOBILE_ACCESS`,`c`.`VIRTUAL_AGENCY` AS `VIRTUAL_AGENCY`,`c`.`VIRTUAL_AGENCY_ACC` AS `VIRTUAL_AGENCY_ACC`,`c`.`AGENCY_ID` AS `AGENCY_ID`,`c`.`VIRTUAL_CUSTOMER` AS `VIRTUAL_CUSTOMER`,`c`.`CA_APP_ACCESS` AS `CA_APP_ACCESS`,`c`.`ACCOUNT_OFFICER_ID` AS `ACCOUNT_OFFICER_ID`,`c`.`ACCOUNT_OFFICER_NAME` AS `ACCOUNT_OFFICER_NAME`,`c`.`ACCSUP_NAME` AS `ACCSUP_NAME`,`c`.`MERCHANT` AS `MERCHANT`,`c`.`IB_ENABLED` AS `IB_ENABLED`,`c`.`IB_UID` AS `IB_UID`,`c`.`IB_PWD` AS `IB_PWD`,`c`.`IB_DEFPWD` AS `IB_DEFPWD`,`c`.`IB_LASTSETPWD` AS `IB_LASTSETPWD`,`c`.`IB_SQ1` AS `IB_SQ1`,`c`.`IB_SQ2` AS `IB_SQ2`,`c`.`IB_SQ3` AS `IB_SQ3`,`c`.`IB_SQ4` AS `IB_SQ4`,`c`.`IB_SQ5` AS `IB_SQ5`,`c`.`IB_SA1` AS `IB_SA1`,`c`.`IB_SA2` AS `IB_SA2`,`c`.`IB_SA3` AS `IB_SA3`,`c`.`IB_SA4` AS `IB_SA4`,`c`.`IB_SA5` AS `IB_SA5`,`c`.`OTP_GEN` AS `OTP_GEN`,`c`.`OTP_GEN_AT` AS `OTP_GEN_AT`,`c`.`INETPWD_FLD_ATMPT` AS `INETPWD_FLD_ATMPT`,`c`.`INETPWD_PWD_FLD_BLK` AS `INETPWD_PWD_FLD_BLK`,`c`.`INETPWD_LST_FAILED_LOGINAT` AS `INETPWD_LST_FAILED_LOGINAT`,`c`.`INETPWD_LST_SUCCESS_LOGINAT` AS `INETPWD_LST_SUCCESS_LOGINAT`,`c`.`CORPORATE_CUSTOMER` AS `CORPORATE_CUSTOMER`,`c`.`CORPORATE_CUSTOMER_TYPE` AS `CORPORATE_CUSTOMER_TYPE`,`c`.`INETB_MAKER` AS `INETB_MAKER`,`c`.`INETB_CHECKER` AS `INETB_CHECKER`,`c`.`DEFAPPCIF` AS `DEFAPPCIF`,`c`.`ORGNAME` AS `ORGNAME`,`c`.`ROLECODE` AS `ROLECODE`,`c`.`TERMSNCONDS` AS `TERMSNCONDS`,`c`.`PREFMDOFCOMM` AS `PREFMDOFCOMM`,`c`.`IBLOCKED` AS `IBLOCKED`,`c`.`CPRNO` AS `CPRNO`,`c`.`RIMNO` AS `RIMNO`,`c`.`FBID` AS `FBID`,`c`.`FBCODE` AS `FBCODE`,`c`.`FBACTIVE` AS `FBACTIVE`,`c`.`OLDSYSPWD` AS `OLDSYSPWD`,`c`.`INET_OVRRDPWD` AS `INET_OVRRDPWD`,`c`.`INET_OVRRDPWDEXP` AS `INET_OVRRDPWDEXP`,`c`.`INET_OVRRDPWDFROMDT` AS `INET_OVRRDPWDFROMDT`,`c`.`PIN_INVAL_CNT` AS `PIN_INVAL_CNT`,`c`.`PWD_INVAL_CNT` AS `PWD_INVAL_CNT`,`c`.`MB_LAST_LOGIN` AS `MB_LAST_LOGIN`,`c`.`OB_LAST_LOGIN` AS `OB_LAST_LOGIN`,`c`.`CUST_PREF_NAME` AS `CUST_PREF_NAME`,`c`.`PIN_RLS_AT` AS `PIN_RLS_AT`,`c`.`PWD_RLS_AT` AS `PWD_RLS_AT`,`c`.`MB_CURR_LOGIN` AS `MB_CURR_LOGIN`,`c`.`OB_CURR_LOGIN` AS `OB_CURR_LOGIN`,`c`.`MB_LAST_CHANNEL` AS `MB_LAST_CHANNEL`,`c`.`MB_CURR_CHANNEL` AS `MB_CURR_CHANNEL`,`c`.`MPINSETDATE` AS `MPINSETDATE`,`c`.`TPINSETDATE` AS `TPINSETDATE`,`c`.`prof_mobile1` AS `prof_mobile1`,`c`.`prof_mobile2` AS `prof_mobile2`,`c`.`group_code` AS `group_code`,`c`.`DOB` AS `DOB`,`c`.`ALTPHONE` AS `ALTPHONE`,`c`.`DESIG` AS `DESIG`,`c`.`REGBRANCH` AS `REGBRANCH`,`c`.`SUB_AGENT` AS `SUB_AGENT`,`c`.`AGENT_NAME` AS `AGENT_NAME`,`c`.`AGENT_CODE` AS `AGENT_CODE`,`c`.`REFBY` AS `REFBY`,`c`.`OTPDELV` AS `OTPDELV`,`c`.`FNAME` AS `FNAME`,`c`.`LNAME` AS `LNAME`,`c`.`CEXTN1` AS `CEXTN1`,`c`.`CEXTN2` AS `CEXTN2`,`c`.`CEXTN3` AS `CEXTN3`,`c`.`CDSCNUM` AS `CDSCNUM`,`c`.`BROKER_ID` AS `BROKER_ID`,`c`.`GENDER` AS `GENDER`,`c`.`BROKER_NAME` AS `BROKER_NAME`,`c`.`AKIBA_REG` AS `AKIBA_REG`,`c`.`AKIBA_REGAT` AS `AKIBA_REGAT`,`c`.`AKIBA_REGREF` AS `AKIBA_REGREF`,`c`.`DEBMIN` AS `DEBMIN`,`c`.`IName` AS `IName`,`c`.`STATUS_NAME` AS `STATUS_NAME`,`c`.`CURR_APP_STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`c`.`mv_pin_no` AS `mv_pin_no`,`c`.`mv_initial_pin` AS `mv_initial_pin`,`c`.`cust_type` AS `cust_type`,`c`.`mva_failed_atmpts` AS `mva_failed_atmpts`,`c`.`mva_initial_pin` AS `mva_initial_pin`,`c`.`mva_pin_no` AS `mva_pin_no`,`c`.`mva_pinsetdate` AS `mva_pinsetdate`,`c`.`mv_super_cif` AS `mv_super_cif`,`c`.`mv_failed_atmpts` AS `mv_failed_atmpts`,`c`.`mv_pinsetdate` AS `mv_pinsetdate`,`c`.`CATEGORY` AS `CATEGORY`,`s`.`GROUP_CODE` AS `GRPCODE` from (`pcustomer_view` `c` left join `system_user` `s` on((`c`.`CREATED_BY` = `s`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mobile_failed_login_view`
--

/*!50001 DROP VIEW IF EXISTS `mobile_failed_login_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mobile_failed_login_view` AS select `fl`.`ID` AS `ID`,`fl`.`username` AS `username`,`fl`.`email` AS `email`,`fl`.`source` AS `source`,`fl`.`created_at` AS `created_at`,`fl`.`created_by` AS `created_by`,`fl`.`modified_at` AS `modified_at`,`fl`.`modified_by` AS `modified_by`,`cv`.`CNAME` AS `CName`,`cv`.`INSTITUTION_ID` AS `Institution_id`,`cv`.`IName` AS `IName` from (`failed_login` `fl` left join `customer_view` `cv` on((`fl`.`username` = `cv`.`CIF`))) where (`fl`.`source` like 'Mobile%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `maker_checker_audit_view`
--

/*!50001 DROP VIEW IF EXISTS `maker_checker_audit_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `maker_checker_audit_view` AS select `mca`.`Id` AS `Id`,`mca`.`TAB_NAME` AS `TAB_NAME`,`mca`.`TABLE_LABEL` AS `TABLE_LABEL`,`mca`.`ACTION_NAME` AS `ACTION_NAME`,`mca`.`COMMENTS` AS `COMMENTS`,`mca`.`REC_ID` AS `REC_ID`,`mca`.`RSTATUS` AS `RSTATUS`,`mca`.`CREATED_BY` AS `CREATED_BY`,`mca`.`CREATED_AT` AS `CREATED_AT`,`mca`.`MODIFIED_AT` AS `MODIFIED_AT`,`mca`.`MODIFIED_BY` AS `MODIFIED_BY`,`ui`.`USER_ID` AS `USER_ID`,concat(`ui`.`FIRST_NAME`,' ',`ui`.`LAST_NAME`) AS `UName` from (`maker_checker_audit` `mca` join `system_user` `ui`) where (`mca`.`CREATED_BY` = `ui`.`Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_el_bp_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_el_bp_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_el_bp_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`BPOPERATOR` AS `BPOPERATOR`,`er`.`BPAMOUNT` AS `BPAMOUNT`,`er`.`BPNUM` AS `BPNUM`,`er`.`BPTYPE` AS `BPTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_el_bp_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_customers_mob_banking`
--

/*!50001 DROP VIEW IF EXISTS `rep_customers_mob_banking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_customers_mob_banking` AS select `customer`.`cname` AS `cname`,`customer`.`VAL_ACC` AS `val_acc`,substr(`customer`.`VAL_ACC`,2,3) AS `branch`,`customer`.`NATIONAL_ID` AS `national_id`,`customer`.`MOBILE` AS `mobile`,`customer`.`EMAIL` AS `email`,date_format(`customer`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `customer` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `card_account_view`
--

/*!50001 DROP VIEW IF EXISTS `card_account_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `card_account_view` AS (select `er`.`Id` AS `Id`,`er`.`ACC_NUM` AS `ACC_NUM`,`er`.`ALIAS` AS `ALIAS`,`er`.`CUST_ID` AS `CUST_ID`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`er`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`er`.`REPORT_FREQ` AS `REPORT_FREQ`,`er`.`ALLOW_SMS` AS `ALLOW_SMS`,`er`.`ALLOW_EMAIL` AS `ALLOW_EMAIL`,`er`.`SMS_THRES` AS `SMS_THRES`,`er`.`EMAIL_THRES` AS `EMAIL_THRES`,`er`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`er`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`er`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`er`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`er`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`er`.`ADDTNL_SMS1` AS `ADDTNL_SMS1`,`er`.`ADDTNL_SMS2` AS `ADDTNL_SMS2`,`er`.`ADDTNL_SMS3` AS `ADDTNL_SMS3`,`er`.`ADDTNL_SMS4` AS `ADDTNL_SMS4`,`er`.`ADDTNL_SMS5` AS `ADDTNL_SMS5`,`er`.`ACCEXTN1` AS `ACCEXTN1`,`er`.`ACCEXTN2` AS `ACCEXTN2`,`er`.`ACCEXTN3` AS `ACCEXTN3`,`er`.`ACCEXTN4` AS `ACCEXTN4`,`er`.`ACCEXTN5` AS `ACCEXTN5`,`er`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`er`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`er`.`CURR_BALANCE` AS `CURR_BALANCE`,`er`.`CURR_BALANCE_TYPE` AS `CURR_BALANCE_TYPE`,`er`.`CURR_BAL_LASTUPD` AS `CURR_BAL_LASTUPD`,`er`.`BRANCH_CODE` AS `BRANCH_CODE`,`er`.`ALLOW_MOBILE` AS `ALLOW_MOBILE`,`er`.`VIRTUAL_ACCOUNT` AS `VIRTUAL_ACCOUNT`,`er`.`ALT_ACC_ID` AS `ALT_ACC_ID`,`er`.`AH_CB_NAME` AS `AH_CB_NAME`,`er`.`AH_CIF_NAME` AS `AH_CIF_NAME`,`er`.`JOINT_ACCOUNT` AS `JOINT_ACCOUNT`,`er`.`JOINT_ACCOUNT_MANDATES` AS `JOINT_ACCOUNT_MANDATES`,`er`.`PRIMARY_ACCOUNT` AS `PRIMARY_ACCOUNT`,`er`.`group_code` AS `group_code`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`card_account` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bp_summ_view`
--

/*!50001 DROP VIEW IF EXISTS `bp_summ_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bp_summ_view` AS select `bulk_payment`.`BATCH_CODE` AS `batch_code`,count(0) AS `cnt`,sum(`bulk_payment`.`AMOUNT`) AS `totamt` from `bulk_payment` group by `bulk_payment`.`BATCH_CODE` order by 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `merchant_view`
--

/*!50001 DROP VIEW IF EXISTS `merchant_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `merchant_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MERCH_ID` AS `MERCH_ID`,`blr`.`MERCH_NAME` AS `MERCH_NAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`MERCH_TYPE` AS `MERCH_TYPE`,`blr`.`EMAIL` AS `EMAIL`,`blr`.`MERCH_CTG` AS `MERCH_CTG`,`blr`.`MERCH_CODE` AS `MERCH_CODE`,`blr`.`MERCH_ADR` AS `MERCH_ADR`,`blr`.`MERCH_PIN` AS `MERCH_PIN`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`merchant` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ml_request_view`
--

/*!50001 DROP VIEW IF EXISTS `ml_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ml_request_view` AS (select `atb`.`Id` AS `Id`,`atb`.`REQ_CIF` AS `REQ_CIF`,`atb`.`REQ_NAME` AS `REQ_NAME`,`atb`.`REQ_AMT` AS `REQ_AMT`,`atb`.`REQ_TS` AS `REQ_TS`,`atb`.`REQ_ACC` AS `REQ_ACC`,`atb`.`REQ_TYPE` AS `REQ_TYPE`,`atb`.`GUR_CIF` AS `GUR_CIF`,`atb`.`GUR_NAME` AS `GUR_NAME`,`atb`.`GUR_AMT` AS `GUR_AMT`,`atb`.`GUR_TS` AS `GUR_TS`,`atb`.`GUR_ACC` AS `GUR_ACC`,`atb`.`GUR_APPROVAL_AT` AS `GUR_APPROVAL_AT`,`atb`.`GUR_ACTION` AS `GUR_ACTION`,`atb`.`CURRENCY` AS `CURRENCY`,`atb`.`CB_SCORE` AS `CB_SCORE`,`atb`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atb`.`MADE_BY` AS `MADE_BY`,`atb`.`MADE_AT` AS `MADE_AT`,`atb`.`CHECKED_BY` AS `CHECKED_BY`,`atb`.`CHECKED_AT` AS `CHECKED_AT`,`atb`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atb`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atb`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atb`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atb`.`RSTATUS` AS `RSTATUS`,`atb`.`CREATED_BY` AS `CREATED_BY`,`atb`.`CREATED_AT` AS `CREATED_AT`,`atb`.`MODIFIED_AT` AS `MODIFIED_AT`,`atb`.`MODIFIED_BY` AS `MODIFIED_BY`,`atb`.`REQ_BAL` AS `REQ_BAL`,`atb`.`GUR_BAL` AS `GUR_BAL`,`atb`.`REQ_ELIG_BAL` AS `REQ_ELIG_BAL`,`atb`.`GUR_ELIG_BAL` AS `GUR_ELIG_BAL`,`atb`.`REQ_MOBILE` AS `REQ_MOBILE`,`atb`.`GUR_MOBILE` AS `GUR_MOBILE`,`atb`.`REQ_MAIL` AS `REQ_MAIL`,`atb`.`GUR_MAIL` AS `GUR_MAIL`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ml_request` `atb` left join `institution` `inst` on((`atb`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atb`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atb`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `spblr_chrg_type_rng_view`
--

/*!50001 DROP VIEW IF EXISTS `spblr_chrg_type_rng_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `spblr_chrg_type_rng_view` AS select `s`.`Id` AS `Id`,`s`.`BILLER_ID` AS `BILLER_ID`,`s`.`RANGE_FROM` AS `RANGE_FROM`,`s`.`RANGE_TO` AS `RANGE_TO`,`s`.`CHARGE_TYPE_CODE` AS `CHARGE_TYPE_CODE`,`s`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`s`.`CHARGE_VALUE2` AS `CHARGE_VALUE2`,`s`.`CHARGE_VALUE3` AS `CHARGE_VALUE3`,`s`.`CHARGE_VALUE4` AS `CHARGE_VALUE4`,`s`.`MADE_BY` AS `MADE_BY`,`s`.`MADE_AT` AS `MADE_AT`,`s`.`CHECKED_BY` AS `CHECKED_BY`,`s`.`CHECKED_AT` AS `CHECKED_AT`,`s`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`s`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`s`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`s`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`s`.`RSTATUS` AS `RSTATUS`,`s`.`CREATED_BY` AS `CREATED_BY`,`s`.`CREATED_AT` AS `CREATED_AT`,`s`.`MODIFIED_AT` AS `MODIFIED_AT`,`s`.`MODIFIED_BY` AS `MODIFIED_BY`,`s`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`b`.`BILLER_NAME` AS `BILLER_NAME`,`b`.`BILLER_TYPE` AS `BILLER_TYPE`,`b`.`BILLER_ACNO` AS `BILLER_ACNO`,`sc`.`STATUS_NAME` AS `STATUS_NAME` from ((`special_biller_charge_type_range` `s` join `biller` `b`) join `status_code` `sc`) where ((`s`.`BILLER_ID` = `b`.`Id`) and (`s`.`CURR_APP_STATUS` = `sc`.`STATUS_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_mobile_user_usage_statistics_view`
--

/*!50001 DROP VIEW IF EXISTS `report_mobile_user_usage_statistics_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_mobile_user_usage_statistics_view` AS select `mobile_access_log_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`mobile_access_log_view`.`INAME` AS `INSTITUTION`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') AS `DATEVAL`,count(distinct `mobile_access_log_view`.`CIFNO`) AS `COUNT` from `mobile_access_log_view` group by `mobile_access_log_view`.`INSTITUTION_ID`,`mobile_access_log_view`.`INAME`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `chama_member_view`
--

/*!50001 DROP VIEW IF EXISTS `chama_member_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `chama_member_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CHAMA_ACC_NUM` AS `CHAMA_ACC_NUM`,`blr`.`MEMBER_CIF` AS `MEMBER_CIF`,`blr`.`MEMBER_ACC` AS `MEMBER_ACC`,`blr`.`MEMBER_NAME` AS `MEMBER_NAME`,`blr`.`SIGNATORY` AS `SIGNATORY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`blr`.`CHAMA_TITLE` AS `CHAMA_TITLE`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`chama_member` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `account_view`
--

/*!50001 DROP VIEW IF EXISTS `account_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `account_view` AS select `a`.`Id` AS `Id`,`a`.`ACC_NUM` AS `ACC_NUM`,`a`.`ALIAS` AS `ALIAS`,`a`.`CUST_ID` AS `CUST_ID`,`a`.`CURRENCY` AS `CURRENCY`,`a`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`a`.`MADE_BY` AS `MADE_BY`,`a`.`MADE_AT` AS `MADE_AT`,`a`.`CHECKED_BY` AS `CHECKED_BY`,`a`.`CHECKED_AT` AS `CHECKED_AT`,`a`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`a`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`a`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`a`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`a`.`RSTATUS` AS `RSTATUS`,`a`.`CREATED_BY` AS `CREATED_BY`,`a`.`CREATED_AT` AS `CREATED_AT`,`a`.`MODIFIED_AT` AS `MODIFIED_AT`,`a`.`MODIFIED_BY` AS `MODIFIED_BY`,`a`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`a`.`REPORT_FREQ` AS `REPORT_FREQ`,`a`.`ALLOW_SMS` AS `ALLOW_SMS`,`a`.`ALLOW_EMAIL` AS `ALLOW_EMAIL`,`a`.`SMS_THRES` AS `SMS_THRES`,`a`.`EMAIL_THRES` AS `EMAIL_THRES`,`a`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`a`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`a`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`a`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`a`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`a`.`ADDTNL_SMS1` AS `ADDTNL_SMS1`,`a`.`ADDTNL_SMS2` AS `ADDTNL_SMS2`,`a`.`ADDTNL_SMS3` AS `ADDTNL_SMS3`,`a`.`ADDTNL_SMS4` AS `ADDTNL_SMS4`,`a`.`ADDTNL_SMS5` AS `ADDTNL_SMS5`,`a`.`ACCEXTN1` AS `ACCEXTN1`,`a`.`ACCEXTN2` AS `ACCEXTN2`,`a`.`ACCEXTN3` AS `ACCEXTN3`,`a`.`ACCEXTN4` AS `ACCEXTN4`,`a`.`ACCEXTN5` AS `ACCEXTN5`,`a`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`a`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`a`.`CURR_BALANCE` AS `CURR_BALANCE`,`a`.`CURR_BALANCE_TYPE` AS `CURR_BALANCE_TYPE`,`a`.`CURR_BAL_LASTUPD` AS `CURR_BAL_LASTUPD`,`a`.`BRANCH_CODE` AS `BRANCH_CODE`,`a`.`ALLOW_MOBILE` AS `ALLOW_MOBILE`,`a`.`VIRTUAL_ACCOUNT` AS `VIRTUAL_ACCOUNT`,`a`.`ALT_ACC_ID` AS `ALT_ACC_ID`,`a`.`AH_CB_NAME` AS `AH_CB_NAME`,`a`.`AH_CIF_NAME` AS `AH_CIF_NAME`,`a`.`JOINT_ACCOUNT` AS `JOINT_ACCOUNT`,`a`.`JOINT_ACCOUNT_MANDATES` AS `JOINT_ACCOUNT_MANDATES`,`a`.`PRIMARY_ACCOUNT` AS `PRIMARY_ACCOUNT`,`a`.`group_code` AS `group_code`,`a`.`CRDMIN` AS `CRDMIN`,`a`.`DEBMIN` AS `DEBMIN`,`a`.`STMT_PRTY` AS `STMT_PRTY`,`a`.`ALSALCR` AS `ALSALCR`,`a`.`ALCHQDEP` AS `ALCHQDEP`,`a`.`ALODAM` AS `ALODAM`,`a`.`ALATM` AS `ALATM`,`a`.`ACCCTYPE` AS `ACCCTYPE`,`a`.`CNAME` AS `CNAME`,`a`.`IName` AS `IName`,`a`.`STATUS_NAME` AS `STATUS_NAME`,`a`.`CURR_APP_STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`s`.`GROUP_CODE` AS `GRPCODE` from (`paccount_view` `a` left join `system_user` `s` on((`a`.`CREATED_BY` = `s`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `other_bank_view`
--

/*!50001 DROP VIEW IF EXISTS `other_bank_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `other_bank_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BANK_ID` AS `BANK_ID`,`blr`.`BANK_NAME` AS `BANK_NAME`,`blr`.`SWIFT_CODE` AS `SWIFT_CODE`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`REF_BIN_CODE` AS `REF_BIN_CODE`,`blr`.`REF_BRANCH_CODE` AS `REF_BRANCH_CODE`,`blr`.`REF_ACCOUNT_NUMBER` AS `REF_ACCOUNT_NUMBER`,`blr`.`REF_OTHER_BANK` AS `REF_OTHER_BANK`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`other_bank` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_ll_bp_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_ll_bp_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_ll_bp_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`BPOPERATOR` AS `BPOPERATOR`,`er`.`BPAMOUNT` AS `BPAMOUNT`,`er`.`BPSTD` AS `BPSTD`,`er`.`BPNUM` AS `BPNUM`,`er`.`BPTYPE` AS `BPTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_ll_bp_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_sysuser_crea_history`
--

/*!50001 DROP VIEW IF EXISTS `rep_sysuser_crea_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_sysuser_crea_history` AS select `c`.`USER_ID` AS `USERNAME`,(select `user_role`.`ROLENAME` from `user_role` where (`user_role`.`Id` = `c`.`USER_ROLE_ID`)) AS `ROLE`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CREATED_BY`)) AS `CREATED_BY`,`c`.`CREATED_AT` AS `CREATED_AT`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CHECKED_BY`)) AS `CHECKED_BY`,`c`.`CHECKED_AT` AS `CHECKED_AT`,(select `institution`.`INAME` from `institution` where (`institution`.`Id` = `c`.`INSTITUTION_ID`)) AS `INSTITUTION`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `system_user` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `system_user_view`
--

/*!50001 DROP VIEW IF EXISTS `system_user_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `system_user_view` AS (select `su`.`Id` AS `Id`,`su`.`USER_ID` AS `USER_ID`,`su`.`USER_PASSWORD` AS `USER_PASSWORD`,`su`.`PREFIX` AS `PREFIX`,`su`.`FIRST_NAME` AS `FIRST_NAME`,`su`.`MIDDLE_NAME` AS `MIDDLE_NAME`,`su`.`LAST_NAME` AS `LAST_NAME`,`su`.`EMAIL` AS `EMAIL`,`su`.`MOBILE` AS `MOBILE`,`su`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`su`.`COUNTRY` AS `COUNTRY`,`su`.`LAST_LOGIN_DATE` AS `LAST_LOGIN_DATE`,`su`.`LAST_LOGIN_FDATE` AS `LAST_LOGIN_FDATE`,`su`.`LOGIN_ATTEMPTS` AS `LOGIN_ATTEMPTS`,`su`.`PREF_LANG` AS `PREF_LANG`,`su`.`PREF_COMM` AS `PREF_COMM`,`su`.`USER_ROLE_ID` AS `USER_ROLE_ID`,`su`.`SUP_ID` AS `SUP_ID`,`su`.`SEQ_Q1` AS `SEQ_Q1`,`su`.`SEQ_Q2` AS `SEQ_Q2`,`su`.`SEQ_Q3` AS `SEQ_Q3`,`su`.`SEQ_A1` AS `SEQ_A1`,`su`.`SEQ_A2` AS `SEQ_A2`,`su`.`SEQ_A3` AS `SEQ_A3`,`su`.`MADE_BY` AS `MADE_BY`,`su`.`MADE_AT` AS `MADE_AT`,`su`.`CHECKED_BY` AS `CHECKED_BY`,`su`.`CHECKED_AT` AS `CHECKED_AT`,`su`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`su`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`su`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`su`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`su`.`RSTATUS` AS `RSTATUS`,`su`.`CREATED_BY` AS `CREATED_BY`,`su`.`CREATED_AT` AS `CREATED_AT`,`su`.`MODIFIED_AT` AS `MODIFIED_AT`,`su`.`MODIFIED_BY` AS `MODIFIED_BY`,`su`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`su`.`PWDSETDATE` AS `PWDSETDATE`,`su`.`INITIAL_PWD` AS `INITIAL_PWD`,`su`.`TRAN_ACCNT_MASTER` AS `TRAN_ACCNT_MASTER`,`su`.`TRAN_ACCNT_SUB` AS `TRAN_ACCNT_SUB`,`su`.`TRAN_ACCNT_MSTMAX` AS `TRAN_ACCNT_MSTMAX`,`su`.`TRAN_ACCNT_SUBMAX` AS `TRAN_ACCNT_SUBMAX`,`su`.`TRAN_ACCNT_MSTUSED` AS `TRAN_ACCNT_MSTUSED`,`su`.`TRAN_ACCNT_SUBUSED` AS `TRAN_ACCNT_SUBUSED`,`su`.`TRAN_ACCNT_MASTER_NAME` AS `TRAN_ACCNT_MASTER_NAME`,`su`.`TRAN_ACCNT_SUB_NAME` AS `TRAN_ACCNT_SUB_NAME`,`su`.`checker_id` AS `checker_id`,`su`.`DISTR_ID` AS `DISTR_ID`,`su`.`AGENT_ID` AS `AGENT_ID`,`su`.`MERCHANT` AS `MERCHANT`,`su`.`GROUP_CODE` AS `GROUP_CODE`,`ascd`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`ur`.`ROLENAME` AS `ROLENAME`,`ur`.`ADMIN_PERM` AS `ADMIN_PERM`,`ur`.`MAKER_PERM` AS `MAKER_PERM`,`ur`.`CHECKER_PERM` AS `CHECKER_PERM`,`ur`.`GLOBAL_ADMIN_PERM` AS `GLOBAL_ADMIN_PERM`,`ur`.`REPORT_PERM` AS `REPORT_PERM`,`ur`.`AUDIT_PERM` AS `AUDIT_PERM` from ((((`system_user` `su` left join `institution` `inst` on((`su`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `user_role` `ur`) where ((`su`.`RSTATUS` = `sc`.`STATUS_ID`) and (`su`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`su`.`USER_ROLE_ID` = `ur`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sms_mesg_in_view`
--

/*!50001 DROP VIEW IF EXISTS `sms_mesg_in_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sms_mesg_in_view` AS select `sm`.`Id` AS `Id`,`sm`.`CPR` AS `CPR`,`sm`.`MFROMADDR` AS `MFROMADDR`,`sm`.`MTOADDR` AS `MTOADDR`,`sm`.`MMESSAGE` AS `MMESSAGE`,`sm`.`MMESSAGESTATUS` AS `MMESSAGESTATUS`,`sm`.`MRETRYCNT` AS `MRETRYCNT`,`sm`.`MESGQIN` AS `MESGQIN`,`sm`.`MESGQOUT` AS `MESGQOUT`,`sm`.`MESGQERR` AS `MESGQERR`,`sm`.`RSTATUS` AS `RSTATUS`,`sm`.`CREATED_BY` AS `CREATED_BY`,`sm`.`CREATED_AT` AS `CREATED_AT`,`sm`.`MODIFIED_AT` AS `MODIFIED_AT`,`sm`.`MODIFIED_BY` AS `MODIFIED_BY`,`sm`.`NEXT_ATTEMPT` AS `NEXT_ATTEMPT`,`sm`.`LAST_ATTEMPT` AS `LAST_ATTEMPT`,`sm`.`REQ_SOURCE` AS `REQ_SOURCE`,`sm`.`LANG_CODE` AS `LANG_CODE`,`sm`.`DESTCID` AS `DESTCID`,`sm`.`EXTN1` AS `EXTN1`,`sm`.`EXTN2` AS `EXTN2`,`sm`.`EXTN3` AS `EXTN3`,`sm`.`EXEC_AG_CODE` AS `EXEC_AG_CODE`,`cm`.`CCODE` AS `CCODE` from (`sms_mesg_in` `sm` join `content_map` `cm`) where ((`cm`.`CTYPE` = 'MESG_COMMN_CODE') and (`sm`.`RSTATUS` = `cm`.`CVALUE`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticket_master_view`
--

/*!50001 DROP VIEW IF EXISTS `ticket_master_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticket_master_view` AS (select `blr`.`Id` AS `Id`,`blr`.`TITLE` AS `TITLE`,`blr`.`TDESC` AS `TDESC`,`blr`.`TTYPE` AS `TTYPE`,`blr`.`TPRIORITY` AS `TPRIORITY`,`blr`.`TPRIORITY_SEQ` AS `TPRIORITY_SEQ`,`blr`.`TCATEGORY` AS `TCATEGORY`,`blr`.`TPROJECT` AS `TPROJECT`,`blr`.`TRECESTIMATE` AS `TRECESTIMATE`,`blr`.`TRESESTIMATE` AS `TRESESTIMATE`,`blr`.`TASGNTO` AS `TASGNTO`,`blr`.`TCURRSTAT` AS `TCURRSTAT`,`blr`.`TRAISED` AS `TRAISED`,`blr`.`TREPEAT_ISSUE` AS `TREPEAT_ISSUE`,`blr`.`TACKAT` AS `TACKAT`,`blr`.`TRECAT` AS `TRECAT`,`blr`.`TRESAT` AS `TRESAT`,`blr`.`TCLSDAT` AS `TCLSDAT`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`GROUP_CODE` AS `GROUP_CODE`,`blr`.`contact_mobile` AS `contact_mobile`,`blr`.`contact_email` AS `contact_email`,`blr`.`CONTACT_NAME` AS `CONTACT_NAME`,`blr`.`EST_TO_COMPL` AS `EST_TO_COMPL`,`blr`.`ROOT_CAUSE` AS `ROOT_CAUSE`,`blr`.`SOURCE_IP` AS `SOURCE_IP`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`REQ_REC_ID` AS `REQ_REC_ID`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ticket_master` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `forex_rate_view`
--

/*!50001 DROP VIEW IF EXISTS `forex_rate_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `forex_rate_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FROM_CURR` AS `FROM_CURR`,`blr`.`TO_CURR` AS `TO_CURR`,`blr`.`BUY_RATE` AS `BUY_RATE`,`blr`.`SELL_RATE` AS `SELL_RATE`,`blr`.`CATEGORY` AS `CATEGORY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`forex_rate` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_reqeust_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_reqeust_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_reqeust_view` AS select `crview`.`Id` AS `Id`,`crview`.`CIF` AS `CIF`,`crview`.`CNAME` AS `CNAME`,`crview`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`crview`.`COMMENTS` AS `COMMENTS`,`crview`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`crview`.`MADE_BY` AS `MADE_BY`,`crview`.`MADE_AT` AS `MADE_AT`,`crview`.`CHECKED_BY` AS `CHECKED_BY`,`crview`.`CHECKED_AT` AS `CHECKED_AT`,`crview`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`crview`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`crview`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`crview`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`crview`.`RSTATUS` AS `RSTATUS`,`crview`.`CREATED_BY` AS `CREATED_BY`,`crview`.`CREATED_AT` AS `CREATED_AT`,`crview`.`MODIFIED_AT` AS `MODIFIED_AT`,`crview`.`MODIFIED_BY` AS `MODIFIED_BY`,`crview`.`REQUEST_DESC` AS `REQUEST_DESC`,`crview`.`REQUEST_STATUS` AS `REQUEST_STATUS`,`crview`.`REQUEST_CHG_DESC` AS `REQUEST_CHG_DESC`,`crview`.`cmobile` AS `cmobile`,`crview`.`extn1` AS `extn1`,`crview`.`extn2` AS `extn2`,`crview`.`extn3` AS `extn3`,`crview`.`STATUS_NAME` AS `STATUS_NAME`,`crview`.`CURR_APP_STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`crview`.`IName` AS `IName`,`su`.`GROUP_CODE` AS `grp_code` from (`customer_reqeust1_view` `crview` left join `system_user` `su` on((`crview`.`MADE_BY` = `su`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customers_email_alert`
--

/*!50001 DROP VIEW IF EXISTS `report_customers_email_alert`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customers_email_alert` AS select `customer`.`cname` AS `cname`,`customer`.`VAL_ACC` AS `val_acc`,substr(`customer`.`VAL_ACC`,2,3) AS `branch`,`customer`.`NATIONAL_ID` AS `national_id`,`customer`.`MOBILE` AS `mobile`,`customer`.`EMAIL` AS `email`,date_format(`customer`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `customer` where (`customer`.`REPORT_FREQ` <> 'None') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `airtel_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `airtel_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `airtel_tran_view` AS select `airtel_tran`.`Id` AS `Id`,`airtel_tran`.`ATID` AS `ATID`,`airtel_tran`.`ORIG` AS `ORIG`,`airtel_tran`.`DEST` AS `DEST`,`airtel_tran`.`TSTAMP` AS `TSTAMP`,`airtel_tran`.`ATTEXT` AS `ATTEXT`,`airtel_tran`.`ATUSER` AS `ATUSER`,`airtel_tran`.`ATPASS` AS `ATPASS`,`airtel_tran`.`ATCODE` AS `ATCODE`,`airtel_tran`.`ATCUSTID` AS `ATCUSTID`,`airtel_tran`.`ATRTMETHODID` AS `ATRTMETHODID`,`airtel_tran`.`ATRTMETHODNAME` AS `ATRTMETHODNAME`,`airtel_tran`.`ATACC` AS `ATACC`,`airtel_tran`.`ATISDN` AS `ATISDN`,`airtel_tran`.`ATTDATE` AS `ATTDATE`,`airtel_tran`.`ATTTIME` AS `ATTTIME`,`airtel_tran`.`ATTAMT` AS `ATTAMT`,`airtel_tran`.`ATSENDER` AS `ATSENDER`,`airtel_tran`.`ATRESP` AS `ATRESP`,`airtel_tran`.`ATERRMSG` AS `ATERRMSG`,`airtel_tran`.`BANKCHARGES` AS `BANKCHARGES`,`airtel_tran`.`SAFARICOMCHARGES` AS `SAFARICOMCHARGES`,`airtel_tran`.`RCVBTRNSRESULT_CODE` AS `RCVBTRNSRESULT_CODE`,`airtel_tran`.`RCVBTRNSRESULT` AS `RCVBTRNSRESULT`,`airtel_tran`.`RCVBTRNSTS` AS `RCVBTRNSTS`,`airtel_tran`.`RCVBTRNSAMT` AS `RCVBTRNSAMT`,`airtel_tran`.`CUSTTRNSRESULT_CODE` AS `CUSTTRNSRESULT_CODE`,`airtel_tran`.`CUSTTRNSRESULT` AS `CUSTTRNSRESULT`,`airtel_tran`.`CUSTTRNSTS` AS `CUSTTRNSTS`,`airtel_tran`.`CUSTTRNSAMT` AS `CUSTTRNSAMT`,`airtel_tran`.`BANKCHRGRESULT_CODE` AS `BANKCHRGRESULT_CODE`,`airtel_tran`.`BANKCHRGRESULT` AS `BANKCHRGRESULT`,`airtel_tran`.`BANKCHRGTS` AS `BANKCHRGTS`,`airtel_tran`.`BANKCHRGAMT` AS `BANKCHRGAMT`,`airtel_tran`.`AIRTELCHRGRESULT_CODE` AS `AIRTELCHRGRESULT_CODE`,`airtel_tran`.`AIRTELCHRGRESULT` AS `AIRTELCHRGRESULT`,`airtel_tran`.`AIRTELCHRGTS` AS `AIRTELCHRGTS`,`airtel_tran`.`AIRTELCHRGAMT` AS `AIRTELCHRGAMT`,`airtel_tran`.`SUSPENSERESULT_CODE` AS `SUSPENSERESULT_CODE`,`airtel_tran`.`SUSPENSERESULT` AS `SUSPENSERESULT`,`airtel_tran`.`SUSPENSECHRGTS` AS `SUSPENSECHRGTS`,`airtel_tran`.`SUSPENSECHRGAMT` AS `SUSPENSECHRGAMT`,`airtel_tran`.`MADE_BY` AS `MADE_BY`,`airtel_tran`.`MADE_AT` AS `MADE_AT`,`airtel_tran`.`CHECKED_BY` AS `CHECKED_BY`,`airtel_tran`.`CHECKED_AT` AS `CHECKED_AT`,`airtel_tran`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`airtel_tran`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`airtel_tran`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`airtel_tran`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`airtel_tran`.`RSTATUS` AS `RSTATUS`,`airtel_tran`.`STATUS_DESC` AS `STATUS_DESC`,`airtel_tran`.`CREATED_BY` AS `CREATED_BY`,`airtel_tran`.`CREATED_AT` AS `CREATED_AT`,`airtel_tran`.`MODIFIED_AT` AS `MODIFIED_AT`,`airtel_tran`.`MODIFIED_BY` AS `MODIFIED_BY`,`airtel_tran`.`REQUEST_SOURCE_IP` AS `REQUEST_SOURCE_IP`,`airtel_tran`.`TAXRESULT_CODE` AS `TAXRESULT_CODE`,`airtel_tran`.`TAXRESULT` AS `TAXRESULT`,`airtel_tran`.`TAXTS` AS `TAXTS`,`airtel_tran`.`TAXAMT` AS `TAXAMT`,date_format(`airtel_tran`.`CREATED_AT`,'%Y%m%d%H%i%S') AS `DATEVAL` from `airtel_tran` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `merchant_payment_refund_view`
--

/*!50001 DROP VIEW IF EXISTS `merchant_payment_refund_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `merchant_payment_refund_view` AS select `mpr`.`Id` AS `Id`,`mpr`.`PAYMENT_ID` AS `PAYMENT_ID`,`mpr`.`RREASON` AS `RREASON`,`mpr`.`RAMOUNT` AS `RAMOUNT`,`mpr`.`RCHARGES` AS `RCHARGES`,`mpr`.`RFINALAMT` AS `RFINALAMT`,`mpr`.`RRESULT` AS `RRESULT`,`mpr`.`RREQTIME` AS `RREQTIME`,`mpr`.`RPAYTIME` AS `RPAYTIME`,`mpr`.`REFUNDSTATUS` AS `REFUNDSTATUS`,`mpr`.`ERRMSG` AS `ERRMSG`,`mpr`.`RSTATUS` AS `RSTATUS`,`mpr`.`CREATED_BY` AS `CREATED_BY`,`mpr`.`CREATED_AT` AS `CREATED_AT`,`mpr`.`MODIFIED_AT` AS `MODIFIED_AT`,`mpr`.`MODIFIED_BY` AS `MODIFIED_BY`,`mpr`.`EXTN1` AS `EXTN1`,`mpr`.`EXTN2` AS `EXTN2`,`mpr`.`EXTN3` AS `EXTN3`,`mpr`.`EXTN4` AS `EXTN4`,`mp`.`PFROM` AS `PFROM`,`mp`.`PFROMCIF` AS `PFROMCIF`,`mp`.`PFROMNAME` AS `PFROMNAME`,`mp`.`PTO` AS `PTO`,`mp`.`PTOCIF` AS `PTOCIF`,`mp`.`PTONAME` AS `PTONAME`,`mp`.`ITEM` AS `ITEM` from (`merchant_payment` `mp` join `merchant_payment_refund` `mpr`) where (`mpr`.`PAYMENT_ID` = `mp`.`Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `corp_self_reg_request_view`
--

/*!50001 DROP VIEW IF EXISTS `corp_self_reg_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `corp_self_reg_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`PREFNAME` AS `PREFNAME`,`blr`.`EMPLOYER` AS `EMPLOYER`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`EMAIL` AS `EMAIL`,`blr`.`NATIONALID` AS `NATIONALID`,`blr`.`NATIONALITY` AS `NATIONALITY`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`NEEDOLBACCESS` AS `NEEDOLBACCESS`,`blr`.`NEEDMBACCESS` AS `NEEDMBACCESS`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`ROLE` AS `ROLE`,`blr`.`DEFAPPCIF` AS `DEFAPPCIF`,`blr`.`DEFAPPCIFNAME` AS `DEFAPPCIFNAME`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`JNTACCAPPCIF1NAME` AS `JNTACCAPPCIF1NAME`,`blr`.`JNTACCAPPCIF2NAME` AS `JNTACCAPPCIF2NAME`,`blr`.`JNTACCAPPCIF3NAME` AS `JNTACCAPPCIF3NAME`,`blr`.`JNTACCAPPCIF4NAME` AS `JNTACCAPPCIF4NAME`,`blr`.`JNTACCAPPCIF5NAME` AS `JNTACCAPPCIF5NAME`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`BULKAPPCIF1NAME` AS `BULKAPPCIF1NAME`,`blr`.`BULKAPPCIF2NAME` AS `BULKAPPCIF2NAME`,`blr`.`BULKAPPCIF3NAME` AS `BULKAPPCIF3NAME`,`blr`.`JNTACCAPPCIF1MA` AS `JNTACCAPPCIF1MA`,`blr`.`JNTACCAPPCIF2MA` AS `JNTACCAPPCIF2MA`,`blr`.`JNTACCAPPCIF3MA` AS `JNTACCAPPCIF3MA`,`blr`.`JNTACCAPPCIF4MA` AS `JNTACCAPPCIF4MA`,`blr`.`JNTACCAPPCIF5MA` AS `JNTACCAPPCIF5MA`,`blr`.`BULKAPPCIF1MA` AS `BULKAPPCIF1MA`,`blr`.`BULKAPPCIF2MA` AS `BULKAPPCIF2MA`,`blr`.`BULKAPPCIF3MA` AS `BULKAPPCIF3MA`,`blr`.`JNTACCAPPCIF1MNDAPP` AS `JNTACCAPPCIF1MNDAPP`,`blr`.`JNTACCAPPCIF2MNDAPP` AS `JNTACCAPPCIF2MNDAPP`,`blr`.`JNTACCAPPCIF3MNDAPP` AS `JNTACCAPPCIF3MNDAPP`,`blr`.`JNTACCAPPCIF4MNDAPP` AS `JNTACCAPPCIF4MNDAPP`,`blr`.`JNTACCAPPCIF5MNDAPP` AS `JNTACCAPPCIF5MNDAPP`,`blr`.`BULKAPPCIF1MNDAPP` AS `BULKAPPCIF1MNDAPP`,`blr`.`BULKAPPCIF2MNDAPP` AS `BULKAPPCIF2MNDAPP`,`blr`.`BULKAPPCIF3MNDAPP` AS `BULKAPPCIF3MNDAPP`,`blr`.`SECQ1` AS `SECQ1`,`blr`.`SECQ2` AS `SECQ2`,`blr`.`SECQ3` AS `SECQ3`,`blr`.`SECA1` AS `SECA1`,`blr`.`SECA2` AS `SECA2`,`blr`.`SECA3` AS `SECA3`,`blr`.`PREFMDOFCOMM` AS `PREFMDOFCOMM`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`JNTACCAPPCIF1SEQ` AS `JNTACCAPPCIF1SEQ`,`blr`.`JNTACCAPPCIF2SEQ` AS `JNTACCAPPCIF2SEQ`,`blr`.`JNTACCAPPCIF3SEQ` AS `JNTACCAPPCIF3SEQ`,`blr`.`JNTACCAPPCIF4SEQ` AS `JNTACCAPPCIF4SEQ`,`blr`.`JNTACCAPPCIF5SEQ` AS `JNTACCAPPCIF5SEQ`,`blr`.`BULKAPPCIF1SEQ` AS `BULKAPPCIF1SEQ`,`blr`.`BULKAPPCIF2SEQ` AS `BULKAPPCIF2SEQ`,`blr`.`BULKAPPCIF3SEQ` AS `BULKAPPCIF3SEQ`,`blr`.`JNTACCAPPCIF1ROLE` AS `JNTACCAPPCIF1ROLE`,`blr`.`JNTACCAPPCIF2ROLE` AS `JNTACCAPPCIF2ROLE`,`blr`.`JNTACCAPPCIF3ROLE` AS `JNTACCAPPCIF3ROLE`,`blr`.`JNTACCAPPCIF4ROLE` AS `JNTACCAPPCIF4ROLE`,`blr`.`JNTACCAPPCIF5ROLE` AS `JNTACCAPPCIF5ROLE`,`blr`.`JNTACCAPPCIF6ROLE` AS `JNTACCAPPCIF6ROLE`,`blr`.`BULKAPPCIF4` AS `BULKAPPCIF4`,`blr`.`BULKAPPCIF5` AS `BULKAPPCIF5`,`blr`.`BULKAPPCIF6` AS `BULKAPPCIF6`,`blr`.`BULKAPPCIF4NAME` AS `BULKAPPCIF4NAME`,`blr`.`BULKAPPCIF5NAME` AS `BULKAPPCIF5NAME`,`blr`.`BULKAPPCIF6NAME` AS `BULKAPPCIF6NAME`,`blr`.`BULKAPPCIF4MA` AS `BULKAPPCIF4MA`,`blr`.`BULKAPPCIF5MA` AS `BULKAPPCIF5MA`,`blr`.`BULKAPPCIF6MA` AS `BULKAPPCIF6MA`,`blr`.`BULKAPPCIF4MNDAPP` AS `BULKAPPCIF4MNDAPP`,`blr`.`BULKAPPCIF5MNDAPP` AS `BULKAPPCIF5MNDAPP`,`blr`.`BULKAPPCIF6MNDAPP` AS `BULKAPPCIF6MNDAPP`,`blr`.`BULKAPPCIF4SEQ` AS `BULKAPPCIF4SEQ`,`blr`.`BULKAPPCIF5SEQ` AS `BULKAPPCIF5SEQ`,`blr`.`BULKAPPCIF6SEQ` AS `BULKAPPCIF6SEQ`,`blr`.`BULKAPPROLE1CODE` AS `BULKAPPROLE1CODE`,`blr`.`BULKAPPROLE2CODE` AS `BULKAPPROLE2CODE`,`blr`.`BULKAPPROLE3CODE` AS `BULKAPPROLE3CODE`,`blr`.`BULKAPPROLE4CODE` AS `BULKAPPROLE4CODE`,`blr`.`BULKAPPROLE5CODE` AS `BULKAPPROLE5CODE`,`blr`.`BULKAPPROLE6CODE` AS `BULKAPPROLE6CODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`corp_self_reg_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `join_account_approver_view`
--

/*!50001 DROP VIEW IF EXISTS `join_account_approver_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `join_account_approver_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CUST_NAME` AS `CUST_NAME`,`blr`.`MANDATORY` AS `MANDATORY`,`blr`.`ROLE_CODE` AS `ROLE_CODE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`REG_CUST_ID` AS `REG_CUST_ID`,`blr`.`REG_CUST_NAME` AS `REG_CUST_NAME`,`blr`.`OTP_GEN` AS `OTP_GEN`,`blr`.`OTP_EXP` AS `OTP_EXP`,`blr`.`max_approval_amount` AS `max_approval_amount`,`blr`.`MOB_NUM` AS `MOB_NUM`,`blr`.`ORIG_CIF` AS `ORIG_CIF`,`blr`.`BEN_MOB_NUM` AS `BEN_MOB_NUM`,`blr`.`CHARGS` AS `CHARGS`,`blr`.`PAYDESC` AS `PAYDESC`,`blr`.`BENBANKCODE` AS `BENBANKCODE`,`blr`.`BENBRNCHCODE` AS `BENBRNCHCODE`,`blr`.`BENBRNCHCURR` AS `BENBRNCHCURR`,`blr`.`BENNAME` AS `BENNAME`,`blr`.`BENTYPE` AS `BENTYPE`,`blr`.`SERV_NAME` AS `SERV_NAME`,`blr`.`FULL_MAP` AS `FULL_MAP`,`blr`.`SEQ_CODE` AS `SEQ_CODE`,`blr`.`CATEG_CODE` AS `CATEG_CODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`join_account_approver` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pcustomer_view`
--

/*!50001 DROP VIEW IF EXISTS `pcustomer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pcustomer_view` AS select `cu`.`Id` AS `Id`,`cu`.`CIF` AS `CIF`,`cu`.`cname` AS `CNAME`,`cu`.`VAL_ACC` AS `VAL_ACC`,`cu`.`NATIONAL_ID` AS `NATIONAL_ID`,`cu`.`PASSPORT` AS `PASSPORT`,`cu`.`NATIONALITY` AS `NATIONALITY`,`cu`.`MOBILE` AS `MOBILE`,`cu`.`EMAIL` AS `EMAIL`,`cu`.`ID_SUBMITTED` AS `ID_SUBMITTED`,`cu`.`ID_VERIFIED` AS `ID_VERIFIED`,`cu`.`PIN_NO` AS `PIN_NO`,`cu`.`TERMS_SIGNED` AS `TERMS_SIGNED`,`cu`.`UG_ISSUED` AS `UG_ISSUED`,`cu`.`PREF_LANG` AS `PREF_LANG`,`cu`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cu`.`MADE_BY` AS `MADE_BY`,`cu`.`MADE_AT` AS `MADE_AT`,`cu`.`CHECKED_BY` AS `CHECKED_BY`,`cu`.`CHECKED_AT` AS `CHECKED_AT`,`cu`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cu`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cu`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cu`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cu`.`RSTATUS` AS `RSTATUS`,`cu`.`CREATED_BY` AS `CREATED_BY`,`cu`.`CREATED_AT` AS `CREATED_AT`,`cu`.`MODIFIED_AT` AS `MODIFIED_AT`,`cu`.`MODIFIED_BY` AS `MODIFIED_BY`,`cu`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`cu`.`CUST_CAT` AS `CUST_CAT`,`cu`.`ALLOWED_PHONE_TYPE1` AS `ALLOWED_PHONE_TYPE1`,`cu`.`ALLOWED_PHONE_TYPE2` AS `ALLOWED_PHONE_TYPE2`,`cu`.`ALLOWED_PHONE_TYPE3` AS `ALLOWED_PHONE_TYPE3`,`cu`.`ALLOWED_PHONE_ID1` AS `ALLOWED_PHONE_ID1`,`cu`.`ALLOWED_PHONE_ID2` AS `ALLOWED_PHONE_ID2`,`cu`.`ALLOWED_PHONE_ID3` AS `ALLOWED_PHONE_ID3`,`cu`.`ALLOWED_PHONE_IDM1` AS `ALLOWED_PHONE_IDM1`,`cu`.`ALLOWED_PHONE_IDA1` AS `ALLOWED_PHONE_IDA1`,`cu`.`TPIN_NO` AS `TPIN_NO`,`cu`.`AUTH_FAIL_PIN` AS `AUTH_FAIL_PIN`,`cu`.`AUTH_FAIL_TPIN` AS `AUTH_FAIL_TPIN`,`cu`.`REPORT_FREQ` AS `REPORT_FREQ`,`cu`.`CUST_EXTN1` AS `CUST_EXTN1`,`cu`.`CUST_EXTN2` AS `CUST_EXTN2`,`cu`.`CUST_EXTN3` AS `CUST_EXTN3`,`cu`.`CUST_EXTN4` AS `CUST_EXTN4`,`cu`.`INITIAL_MPIN` AS `INITIAL_MPIN`,`cu`.`INITIAL_TPIN` AS `INITIAL_TPIN`,`cu`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`cu`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`cu`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`cu`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`cu`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`cu`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`cu`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`cu`.`CUSEXTN11` AS `CUSEXTN11`,`cu`.`CUSEXTN12` AS `CUSEXTN12`,`cu`.`CUSEXTN13` AS `CUSEXTN13`,`cu`.`CUSEXTN14` AS `CUSEXTN14`,`cu`.`CUSEXTN15` AS `CUSEXTN15`,`cu`.`MPIN_FLDATTMPT` AS `MPIN_FLDATTMPT`,`cu`.`LAST_ATTMPTSRC` AS `LAST_ATTMPTSRC`,`cu`.`LAST_ATTMPTVER` AS `LAST_ATTMPTVER`,`cu`.`UNLOCK_TIME` AS `UNLOCK_TIME`,`cu`.`MOBILE_ACCESS` AS `MOBILE_ACCESS`,`cu`.`VIRTUAL_AGENCY` AS `VIRTUAL_AGENCY`,`cu`.`VIRTUAL_AGENCY_ACC` AS `VIRTUAL_AGENCY_ACC`,`cu`.`AGENCY_ID` AS `AGENCY_ID`,`cu`.`VIRTUAL_CUSTOMER` AS `VIRTUAL_CUSTOMER`,`cu`.`CA_APP_ACCESS` AS `CA_APP_ACCESS`,`cu`.`ACCOUNT_OFFICER_ID` AS `ACCOUNT_OFFICER_ID`,`cu`.`ACCOUNT_OFFICER_NAME` AS `ACCOUNT_OFFICER_NAME`,`cu`.`ACCSUP_NAME` AS `ACCSUP_NAME`,`cu`.`MERCHANT` AS `MERCHANT`,`cu`.`IB_ENABLED` AS `IB_ENABLED`,`cu`.`IB_UID` AS `IB_UID`,`cu`.`IB_PWD` AS `IB_PWD`,`cu`.`IB_DEFPWD` AS `IB_DEFPWD`,`cu`.`IB_LASTSETPWD` AS `IB_LASTSETPWD`,`cu`.`IB_SQ1` AS `IB_SQ1`,`cu`.`IB_SQ2` AS `IB_SQ2`,`cu`.`IB_SQ3` AS `IB_SQ3`,`cu`.`IB_SQ4` AS `IB_SQ4`,`cu`.`IB_SQ5` AS `IB_SQ5`,`cu`.`IB_SA1` AS `IB_SA1`,`cu`.`IB_SA2` AS `IB_SA2`,`cu`.`IB_SA3` AS `IB_SA3`,`cu`.`IB_SA4` AS `IB_SA4`,`cu`.`IB_SA5` AS `IB_SA5`,`cu`.`OTP_GEN` AS `OTP_GEN`,`cu`.`OTP_GEN_AT` AS `OTP_GEN_AT`,`cu`.`INETPWD_FLD_ATMPT` AS `INETPWD_FLD_ATMPT`,`cu`.`INETPWD_PWD_FLD_BLK` AS `INETPWD_PWD_FLD_BLK`,`cu`.`INETPWD_LST_FAILED_LOGINAT` AS `INETPWD_LST_FAILED_LOGINAT`,`cu`.`INETPWD_LST_SUCCESS_LOGINAT` AS `INETPWD_LST_SUCCESS_LOGINAT`,`cu`.`CORPORATE_CUSTOMER` AS `CORPORATE_CUSTOMER`,`cu`.`CORPORATE_CUSTOMER_TYPE` AS `CORPORATE_CUSTOMER_TYPE`,`cu`.`INETB_MAKER` AS `INETB_MAKER`,`cu`.`INETB_CHECKER` AS `INETB_CHECKER`,`cu`.`DEFAPPCIF` AS `DEFAPPCIF`,`cu`.`ORGNAME` AS `ORGNAME`,`cu`.`ROLECODE` AS `ROLECODE`,`cu`.`TERMSNCONDS` AS `TERMSNCONDS`,`cu`.`PREFMDOFCOMM` AS `PREFMDOFCOMM`,`cu`.`IBLOCKED` AS `IBLOCKED`,`cu`.`CPRNO` AS `CPRNO`,`cu`.`RIMNO` AS `RIMNO`,`cu`.`FBID` AS `FBID`,`cu`.`FBCODE` AS `FBCODE`,`cu`.`FBACTIVE` AS `FBACTIVE`,`cu`.`OLDSYSPWD` AS `OLDSYSPWD`,`cu`.`INET_OVRRDPWD` AS `INET_OVRRDPWD`,`cu`.`INET_OVRRDPWDEXP` AS `INET_OVRRDPWDEXP`,`cu`.`INET_OVRRDPWDFROMDT` AS `INET_OVRRDPWDFROMDT`,`cu`.`PIN_INVAL_CNT` AS `PIN_INVAL_CNT`,`cu`.`PWD_INVAL_CNT` AS `PWD_INVAL_CNT`,`cu`.`MB_LAST_LOGIN` AS `MB_LAST_LOGIN`,`cu`.`OB_LAST_LOGIN` AS `OB_LAST_LOGIN`,`cu`.`CUST_PREF_NAME` AS `CUST_PREF_NAME`,`cu`.`PIN_RLS_AT` AS `PIN_RLS_AT`,`cu`.`PWD_RLS_AT` AS `PWD_RLS_AT`,`cu`.`MB_CURR_LOGIN` AS `MB_CURR_LOGIN`,`cu`.`OB_CURR_LOGIN` AS `OB_CURR_LOGIN`,`cu`.`MB_LAST_CHANNEL` AS `MB_LAST_CHANNEL`,`cu`.`MB_CURR_CHANNEL` AS `MB_CURR_CHANNEL`,`cu`.`MPINSETDATE` AS `MPINSETDATE`,`cu`.`TPINSETDATE` AS `TPINSETDATE`,`cu`.`prof_mobile1` AS `prof_mobile1`,`cu`.`prof_mobile2` AS `prof_mobile2`,`cu`.`group_code` AS `group_code`,`cu`.`DOB` AS `DOB`,`cu`.`ALTPHONE` AS `ALTPHONE`,`cu`.`DESIG` AS `DESIG`,`cu`.`REGBRANCH` AS `REGBRANCH`,`cu`.`REFBY` AS `REFBY`,`cu`.`OTPDELV` AS `OTPDELV`,`cu`.`FNAME` AS `FNAME`,`cu`.`LNAME` AS `LNAME`,`cu`.`CEXTN1` AS `CEXTN1`,`cu`.`CEXTN2` AS `CEXTN2`,`cu`.`CEXTN3` AS `CEXTN3`,`cu`.`CDSCNUM` AS `CDSCNUM`,`cu`.`BROKER_ID` AS `BROKER_ID`,`cu`.`GENDER` AS `GENDER`,`cu`.`BROKER_NAME` AS `BROKER_NAME`,`cu`.`AKIBA_REG` AS `AKIBA_REG`,`cu`.`AKIBA_REGAT` AS `AKIBA_REGAT`,`cu`.`AKIBA_REGREF` AS `AKIBA_REGREF`,`cu`.`SUB_AGENT` AS `SUB_AGENT`,`cu`.`AGENT_NAME` AS `AGENT_NAME`,`cu`.`AGENT_CODE` AS `AGENT_CODE`,`cu`.`mv_pin_no` AS `mv_pin_no`,`cu`.`cust_type` AS `cust_type`,`cu`.`mva_failed_atmpts` AS `mva_failed_atmpts`,`cu`.`mva_initial_pin` AS `mva_initial_pin`,`cu`.`mva_pin_no` AS `mva_pin_no`,`cu`.`mva_pinsetdate` AS `mva_pinsetdate`,`cu`.`mv_super_cif` AS `mv_super_cif`,`cu`.`mv_initial_pin` AS `mv_initial_pin`,`cu`.`mv_failed_atmpts` AS `mv_failed_atmpts`,`cu`.`mv_pinsetdate` AS `mv_pinsetdate`,`cu`.`DEBMIN` AS `DEBMIN`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`cc`.`CATEGORY` AS `CATEGORY` from ((((`customer` `cu` join `institution` `inst`) join `status_code` `sc`) join `status_code` `ascd`) join `customer_category` `cc`) where ((`cu`.`INSTITUTION_ID` = `inst`.`Id`) and (`cu`.`RSTATUS` = `sc`.`STATUS_ID`) and (`cu`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`cu`.`CUST_CAT` = `cc`.`Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `custreqtrack_view`
--

/*!50001 DROP VIEW IF EXISTS `custreqtrack_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `custreqtrack_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`REQUEST_DATA` AS `REQUEST_DATA`,`blr`.`REQUEST_DATA1` AS `REQUEST_DATA1`,`blr`.`REQUEST_DATA2` AS `REQUEST_DATA2`,`blr`.`REQUEST_DATA3` AS `REQUEST_DATA3`,`blr`.`REQUEST_DATA4` AS `REQUEST_DATA4`,`blr`.`REQUEST_DATA5` AS `REQUEST_DATA5`,`blr`.`REQUEST_STATUS` AS `REQUEST_STATUS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`custreqtrack` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `atp_provider_view`
--

/*!50001 DROP VIEW IF EXISTS `atp_provider_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `atp_provider_view` AS (select `atp`.`Id` AS `Id`,`atp`.`ATP_NAME` AS `ATP_NAME`,`atp`.`ATP_ACNO` AS `ATP_ACNO`,`atp`.`ATP_TYPE` AS `ATP_TYPE`,`atp`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atp`.`MADE_BY` AS `MADE_BY`,`atp`.`MADE_AT` AS `MADE_AT`,`atp`.`CHECKED_BY` AS `CHECKED_BY`,`atp`.`CHECKED_AT` AS `CHECKED_AT`,`atp`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atp`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atp`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atp`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atp`.`RSTATUS` AS `RSTATUS`,`atp`.`CREATED_BY` AS `CREATED_BY`,`atp`.`CREATED_AT` AS `CREATED_AT`,`atp`.`MODIFIED_AT` AS `MODIFIED_AT`,`atp`.`MODIFIED_BY` AS `MODIFIED_BY`,`atp`.`BRANCH_CODE` AS `BRANCH_CODE`,`atp`.`CURR_CODE` AS `CURR_CODE`,`atp`.`PAY_TYPE` AS `PAY_TYPE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`atp_provider` `atp` left join `institution` `inst` on((`atp`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atp`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atp`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cust_auto_reg_view`
--

/*!50001 DROP VIEW IF EXISTS `cust_auto_reg_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cust_auto_reg_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CUST_CODE1` AS `CUST_CODE1`,`blr`.`CUST_CODE2` AS `CUST_CODE2`,`blr`.`CUST_CODE3` AS `CUST_CODE3`,`blr`.`CUST_CODE4` AS `CUST_CODE4`,`blr`.`CUST_CODE5` AS `CUST_CODE5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cust_auto_reg` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `spcl_blr_chrg_type_range`
--

/*!50001 DROP VIEW IF EXISTS `spcl_blr_chrg_type_range`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `spcl_blr_chrg_type_range` AS select `s`.`Id` AS `Id`,`s`.`BILLER_ID` AS `BILLER_ID`,`s`.`RANGE_FROM` AS `RANGE_FROM`,`s`.`RANGE_TO` AS `RANGE_TO`,`s`.`CHARGE_TYPE_CODE` AS `CHARGE_TYPE_CODE`,`s`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`s`.`CHARGE_VALUE2` AS `CHARGE_VALUE2`,`s`.`CHARGE_VALUE3` AS `CHARGE_VALUE3`,`s`.`CHARGE_VALUE4` AS `CHARGE_VALUE4`,`s`.`MADE_BY` AS `MADE_BY`,`s`.`MADE_AT` AS `MADE_AT`,`s`.`CHECKED_BY` AS `CHECKED_BY`,`s`.`CHECKED_AT` AS `CHECKED_AT`,`s`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`s`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`s`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`s`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`s`.`RSTATUS` AS `RSTATUS`,`s`.`CREATED_BY` AS `CREATED_BY`,`s`.`CREATED_AT` AS `CREATED_AT`,`s`.`MODIFIED_AT` AS `MODIFIED_AT`,`s`.`MODIFIED_BY` AS `MODIFIED_BY`,`s`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`b`.`BILLER_NAME` AS `BILLER_NAME`,`b`.`BILLER_TYPE` AS `BILLER_TYPE`,`b`.`BILLER_ACNO` AS `BILLER_ACNO`,`sc`.`STATUS_NAME` AS `STATUS_NAME` from ((`special_biller_charge_type_range` `s` join `biller` `b`) join `status_code` `sc`) where ((`s`.`BILLER_ID` = `b`.`Id`) and (`s`.`CURR_APP_STATUS` = `sc`.`STATUS_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `payee_view`
--

/*!50001 DROP VIEW IF EXISTS `payee_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `payee_view` AS (select `blr`.`Id` AS `Id`,`blr`.`PAYEE_NAME` AS `PAYEE_NAME`,`blr`.`PAYEE_ACNO` AS `PAYEE_ACNO`,`blr`.`PAYER_TYPE` AS `PAYER_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`payee` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sysusr_info_chg_view`
--

/*!50001 DROP VIEW IF EXISTS `sysusr_info_chg_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sysusr_info_chg_view` AS (select `su`.`Id` AS `Id`,`su`.`ORIG_USER_ID` AS `ORIG_USER_ID`,`su`.`USER_ID` AS `USER_ID`,`su`.`PREFIX` AS `PREFIX`,`su`.`FIRST_NAME` AS `FIRST_NAME`,`su`.`MIDDLE_NAME` AS `MIDDLE_NAME`,`su`.`LAST_NAME` AS `LAST_NAME`,`su`.`EMAIL` AS `EMAIL`,`su`.`MOBILE` AS `MOBILE`,`su`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`su`.`COUNTRY` AS `COUNTRY`,`su`.`PREF_LANG` AS `PREF_LANG`,`su`.`PREF_COMM` AS `PREF_COMM`,`su`.`USER_ROLE_ID` AS `USER_ROLE_ID`,`su`.`GROUP_CODE` AS `GROUP_CODE`,`su`.`MADE_BY` AS `MADE_BY`,`su`.`MADE_AT` AS `MADE_AT`,`su`.`CHECKED_BY` AS `CHECKED_BY`,`su`.`CHECKED_AT` AS `CHECKED_AT`,`su`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`su`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`su`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`su`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`su`.`RSTATUS` AS `RSTATUS`,`su`.`CREATED_BY` AS `CREATED_BY`,`su`.`CREATED_AT` AS `CREATED_AT`,`su`.`MODIFIED_AT` AS `MODIFIED_AT`,`su`.`MODIFIED_BY` AS `MODIFIED_BY`,`ascd`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`ur`.`ROLENAME` AS `ROLENAME`,`ur`.`ADMIN_PERM` AS `ADMIN_PERM`,`ur`.`MAKER_PERM` AS `MAKER_PERM`,`ur`.`CHECKER_PERM` AS `CHECKER_PERM`,`ur`.`GLOBAL_ADMIN_PERM` AS `GLOBAL_ADMIN_PERM`,`ur`.`REPORT_PERM` AS `REPORT_PERM`,`ur`.`AUDIT_PERM` AS `AUDIT_PERM` from ((((`sysusr_info_chg` `su` left join `institution` `inst` on((`su`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `user_role` `ur`) where ((`su`.`RSTATUS` = `sc`.`STATUS_ID`) and (`su`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`su`.`USER_ROLE_ID` = `ur`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ft_fail_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ft_fail_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ft_fail_tran_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FROM_ACC` AS `FROM_ACC`,`blr`.`FROM_CIF` AS `FROM_CIF`,`blr`.`TO_CIF` AS `TO_CIF`,`blr`.`FROM_NAME` AS `FROM_NAME`,`blr`.`TO_NAME` AS `TO_NAME`,`blr`.`TO_ACC` AS `TO_ACC`,`blr`.`FT_AMT` AS `FT_AMT`,`blr`.`FT_REM` AS `FT_REM`,`blr`.`FT_RESULT` AS `FT_RESULT`,`blr`.`FT_RESULT_DESC` AS `FT_RESULT_DESC`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ft_fail_tran` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_account_statistics_view`
--

/*!50001 DROP VIEW IF EXISTS `report_account_statistics_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_account_statistics_view` AS select `account_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`account_view`.`IName` AS `INSTITUTION`,`account_view`.`CURR_APP_STATUS_NAME` AS `STATUS`,count(0) AS `COUNT` from `account_view` group by `account_view`.`INSTITUTION_ID`,`account_view`.`IName`,`account_view`.`CURR_APP_STATUS_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_dth_rc_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_dth_rc_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_dth_rc_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`DTHOPERATOR` AS `DTHOPERATOR`,`er`.`RCAMOUNT` AS `RCAMOUNT`,`er`.`DTHSUBSCNO` AS `DTHSUBSCNO`,`er`.`DTHTYPE` AS `DTHTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_dth_rc_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `web_email_failed_login_view`
--

/*!50001 DROP VIEW IF EXISTS `web_email_failed_login_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `web_email_failed_login_view` AS select `fl`.`ID` AS `ID`,`fl`.`username` AS `username`,`fl`.`email` AS `email`,`fl`.`source` AS `source`,`fl`.`created_at` AS `created_at`,`fl`.`created_by` AS `created_by`,`fl`.`modified_at` AS `modified_at`,`fl`.`modified_by` AS `modified_by`,concat(`suv`.`FIRST_NAME`,' ',`suv`.`LAST_NAME`) AS `UName`,`suv`.`INSTITUTION_ID` AS `Institution_id`,`suv`.`IName` AS `IName` from (`failed_login` `fl` join `system_user_view` `suv`) where ((`fl`.`source` like 'Web%') and (`fl`.`email` = `suv`.`EMAIL`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `atmbranch_view`
--

/*!50001 DROP VIEW IF EXISTS `atmbranch_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `atmbranch_view` AS (select `atb`.`Id` AS `Id`,`atb`.`AB_NAME` AS `AB_NAME`,`atb`.`AB_ADDRESS` AS `AB_ADDRESS`,`atb`.`AB_TYPE` AS `AB_TYPE`,`atb`.`AB_PHONE` AS `AB_PHONE`,`atb`.`AB_FAX` AS `AB_FAX`,`atb`.`AB_HOURS` AS `AB_HOURS`,`atb`.`AB_LONG` AS `AB_LONG`,`atb`.`AB_LATT` AS `AB_LATT`,`atb`.`AB_MGR` AS `AB_MGR`,`atb`.`AB_CITY` AS `AB_CITY`,`atb`.`AB_REGION` AS `AB_REGION`,`atb`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atb`.`MADE_BY` AS `MADE_BY`,`atb`.`MADE_AT` AS `MADE_AT`,`atb`.`CHECKED_BY` AS `CHECKED_BY`,`atb`.`CHECKED_AT` AS `CHECKED_AT`,`atb`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atb`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atb`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atb`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atb`.`RSTATUS` AS `RSTATUS`,`atb`.`CREATED_BY` AS `CREATED_BY`,`atb`.`CREATED_AT` AS `CREATED_AT`,`atb`.`MODIFIED_AT` AS `MODIFIED_AT`,`atb`.`MODIFIED_BY` AS `MODIFIED_BY`,`atb`.`DIST` AS `DIST`,`atb`.`LANG_CODE` AS `LANG_CODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`atmbranch` `atb` left join `institution` `inst` on((`atb`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atb`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atb`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `joint_account_request_view`
--

/*!50001 DROP VIEW IF EXISTS `joint_account_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `joint_account_request_view` AS (select `er`.`Id` AS `Id`,`er`.`ACC_NO` AS `ACC_NO`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`MANDATE_COUNT` AS `MANDATE_COUNT`,`er`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`er`.`COMMENTS` AS `COMMENTS`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`joint_account_request` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agent_otp_view`
--

/*!50001 DROP VIEW IF EXISTS `agent_otp_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agent_otp_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`OTP` AS `OTP`,`blr`.`OTP_TS` AS `OTP_TS`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`ACCOUNT` AS `ACCOUNT`,`blr`.`AMOUNT` AS `AMOUNT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`REFID` AS `REFID`,`blr`.`CNAME` AS `CNAME`,`blr`.`AGID` AS `AGID`,`blr`.`AGNAME` AS `AGNAME`,`blr`.`AGUAT` AS `AGUAT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`otp_source` AS `otp_source`,`blr`.`EXTN1_FLD` AS `EXTN1_FLD`,`blr`.`EXTN2_FLD` AS `EXTN2_FLD`,`blr`.`EXTN3_FLD` AS `EXTN3_FLD`,`blr`.`EXTN4_FLD` AS `EXTN4_FLD`,`blr`.`EXTN5_FLD` AS `EXTN5_FLD`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agent_otp` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `corp_sr_add_accnt_req_view`
--

/*!50001 DROP VIEW IF EXISTS `corp_sr_add_accnt_req_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `corp_sr_add_accnt_req_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`corp_self_reg_add_accnt_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_data_update_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_data_update_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_data_update_view` AS select `crview`.`Id` AS `Id`,`crview`.`CUST_RECORD_ID` AS `CUST_RECORD_ID`,`crview`.`ALLOWED_PHONE_ID1` AS `ALLOWED_PHONE_ID1`,`crview`.`ALLOWED_PHONE_ID2` AS `ALLOWED_PHONE_ID2`,`crview`.`CIF` AS `CIF`,`crview`.`CNAME` AS `CNAME`,`crview`.`NATIONAL_ID` AS `NATIONAL_ID`,`crview`.`PASSPORT` AS `PASSPORT`,`crview`.`NATIONALITY` AS `NATIONALITY`,`crview`.`MOBILE` AS `MOBILE`,`crview`.`EMAIL` AS `EMAIL`,`crview`.`PREF_LANG` AS `PREF_LANG`,`crview`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`crview`.`MADE_BY` AS `MADE_BY`,`crview`.`MADE_AT` AS `MADE_AT`,`crview`.`CHECKED_BY` AS `CHECKED_BY`,`crview`.`CHECKED_AT` AS `CHECKED_AT`,`crview`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`crview`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`crview`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`crview`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`crview`.`RSTATUS` AS `RSTATUS`,`crview`.`CREATED_BY` AS `CREATED_BY`,`crview`.`CREATED_AT` AS `CREATED_AT`,`crview`.`MODIFIED_AT` AS `MODIFIED_AT`,`crview`.`MODIFIED_BY` AS `MODIFIED_BY`,`crview`.`CUST_CAT` AS `CUST_CAT`,`crview`.`IB_SQ1` AS `IB_SQ1`,`crview`.`IB_SQ2` AS `IB_SQ2`,`crview`.`IB_SQ3` AS `IB_SQ3`,`crview`.`IB_SQ4` AS `IB_SQ4`,`crview`.`IB_SQ5` AS `IB_SQ5`,`crview`.`IB_SA1` AS `IB_SA1`,`crview`.`IB_SA2` AS `IB_SA2`,`crview`.`IB_SA3` AS `IB_SA3`,`crview`.`IB_SA4` AS `IB_SA4`,`crview`.`IB_SA5` AS `IB_SA5`,`crview`.`ORIG_MOBILE` AS `ORIG_MOBILE`,`crview`.`EXTN1` AS `EXTN1`,`crview`.`EXTN2` AS `EXTN2`,`crview`.`EXTN3` AS `EXTN3`,`crview`.`STATUS_NAME` AS `STATUS_NAME`,`crview`.`CURR_APP_STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`crview`.`IName` AS `IName`,`su`.`GROUP_CODE` AS `grp_code` from (`customer_data_update1_view` `crview` left join `system_user` `su` on((`crview`.`MADE_BY` = `su`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `online_access_request_view`
--

/*!50001 DROP VIEW IF EXISTS `online_access_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `online_access_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`ROLE` AS `ROLE`,`blr`.`PREFMDOFCOMM` AS `PREFMDOFCOMM`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`online_access_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_airtime`
--

/*!50001 DROP VIEW IF EXISTS `report_airtime`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_airtime` AS select `report_funds_transfer_transaction_audit`.`FROM_ACCOUNT` AS `FROM_ACCOUNT`,`report_funds_transfer_transaction_audit`.`TO_ACCOUNT` AS `TO_ACCOUNT`,`report_funds_transfer_transaction_audit`.`REF_NO` AS `REF_NO`,`report_funds_transfer_transaction_audit`.`CUSTOMER_ID` AS `CUSTOMER_ID`,`report_funds_transfer_transaction_audit`.`CUST_MOBILE` AS `CUST_MOBILE`,`report_funds_transfer_transaction_audit`.`FT_TYPE` AS `FT_TYPE`,date_format(`report_funds_transfer_transaction_audit`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL`,`report_funds_transfer_transaction_audit`.`EXTN2` AS `VENDOR_RESPONSE`,`report_funds_transfer_transaction_audit`.`RSTATUS` AS `RSTATUS`,`report_funds_transfer_transaction_audit`.`AMOUNT` AS `AMOUNT`,`report_funds_transfer_transaction_audit`.`CUST_REF2` AS `CUST_REF2` from `report_funds_transfer_transaction_audit` where ((1 = 1) and (substr(`report_funds_transfer_transaction_audit`.`FT_TYPE`,1,12) like 'AirtimeTopUp%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agency_info_stg_view`
--

/*!50001 DROP VIEW IF EXISTS `agency_info_stg_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agency_info_stg_view` AS (select `blr`.`Id` AS `Id`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`NATIONALID` AS `NATIONALID`,`blr`.`BRANCHCODE` AS `BRANCHCODE`,`blr`.`BR_AGENT_CODE` AS `BR_AGENT_CODE`,`blr`.`AGENTID` AS `AGENTID`,`blr`.`TARIFFID` AS `TARIFFID`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`EXPIRY_AT` AS `EXPIRY_AT`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agency_info_stg` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `beneficiary_view`
--

/*!50001 DROP VIEW IF EXISTS `beneficiary_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `beneficiary_view` AS (select `bf`.`Id` AS `Id`,`bf`.`BENEFICIARY_NAME` AS `BENEFICIARY_NAME`,`bf`.`BENEFICIARY_ACNO` AS `BENEFICIARY_ACNO`,`bf`.`BENEFICIARY_TYPE` AS `BENEFICIARY_TYPE`,`bf`.`CUSTOMER_ID` AS `CUSTOMER_ID`,`bf`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`bf`.`MADE_BY` AS `MADE_BY`,`bf`.`MADE_AT` AS `MADE_AT`,`bf`.`CHECKED_BY` AS `CHECKED_BY`,`bf`.`CHECKED_AT` AS `CHECKED_AT`,`bf`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`bf`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`bf`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`bf`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`bf`.`RSTATUS` AS `RSTATUS`,`bf`.`CREATED_BY` AS `CREATED_BY`,`bf`.`CREATED_AT` AS `CREATED_AT`,`bf`.`MODIFIED_AT` AS `MODIFIED_AT`,`bf`.`MODIFIED_BY` AS `MODIFIED_BY`,`bf`.`BANK_CODE` AS `BANK_CODE`,`bf`.`BRANCH` AS `BRANCH`,`bf`.`BENEMOBILE` AS `BENEMOBILE`,`bf`.`BENECURR` AS `BENECURR`,`bf`.`CMT` AS `CMT`,`bf`.`EXTN1` AS `EXTN1`,`bf`.`benemail` AS `benemail`,`bf`.`benalias` AS `benalias`,`bf`.`bencomnt` AS `bencomnt`,`bf`.`IBAN` AS `IBAN`,`bf`.`BENCOUNTRY` AS `BENCOUNTRY`,`bf`.`BENSWIFTCODE` AS `BENSWIFTCODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`beneficiary` `bf` left join `institution` `inst` on((`bf`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`bf`.`RSTATUS` = `sc`.`STATUS_ID`) and (`bf`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_mob_ftr_usage_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `rep_mob_ftr_usage_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_mob_ftr_usage_stat_view` AS select `mobile_access_log_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`mobile_access_log_view`.`INAME` AS `INSTITUTION`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') AS `DATEVAL`,`mobile_access_log_view`.`ACTION_MESG` AS `ACTION_MESG`,count(0) AS `COUNT` from `mobile_access_log_view` group by `mobile_access_log_view`.`INSTITUTION_ID`,`mobile_access_log_view`.`INAME`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d'),`mobile_access_log_view`.`ACTION_MESG` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_non_login_functionality`
--

/*!50001 DROP VIEW IF EXISTS `report_non_login_functionality`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_non_login_functionality` AS select `mail_mesg`.`MTOADDR` AS `MTOADDR`,`mail_mesg`.`MSUBJECT` AS `MSUBJECT`,`mail_mesg`.`MMESSAGE` AS `MMESSAGE`,`mail_mesg`.`MESGQIN` AS `MESGQIN`,`mail_mesg`.`MESGQOUT` AS `MESGQOUT` from `mail_mesg` where ((`mail_mesg`.`MSUBJECT` <> 'Mobile Banking - Your M-Pin') and (`mail_mesg`.`MSUBJECT` <> 'Mobile Banking - Your Password')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `nfc_tag_view`
--

/*!50001 DROP VIEW IF EXISTS `nfc_tag_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `nfc_tag_view` AS (select `blr`.`Id` AS `Id`,`blr`.`TAGCODE` AS `TAGCODE`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`TAG_CATEGORY` AS `TAG_CATEGORY`,`blr`.`FROM_DATE` AS `FROM_DATE`,`blr`.`TO_DATE` AS `TO_DATE`,`blr`.`TAG_STATUS` AS `TAG_STATUS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`nfc_tag` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `retail_self_reg_add_accnt_request_view`
--

/*!50001 DROP VIEW IF EXISTS `retail_self_reg_add_accnt_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `retail_self_reg_add_accnt_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`retail_self_reg_add_accnt_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sysuser_reqeust_view`
--

/*!50001 DROP VIEW IF EXISTS `sysuser_reqeust_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sysuser_reqeust_view` AS (select `blr`.`Id` AS `Id`,`blr`.`USER_REC_ID` AS `USER_REC_ID`,`blr`.`USER_ID` AS `USER_ID`,`blr`.`UNAME` AS `UNAME`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`COMMENTS` AS `COMMENTS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`REQUEST_DESC` AS `REQUEST_DESC`,`blr`.`REQUEST_STATUS` AS `REQUEST_STATUS`,`blr`.`REQUEST_CHG_DESC` AS `REQUEST_CHG_DESC`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`sysuser_reqeust` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `content_map_view`
--

/*!50001 DROP VIEW IF EXISTS `content_map_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `content_map_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CCATG` AS `CCATG`,`blr`.`CTYPE` AS `CTYPE`,`blr`.`CCODE` AS `CCODE`,`blr`.`CVALUE` AS `CVALUE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`CSEQ` AS `CSEQ`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`USSD` AS `USSD`,`blr`.`WAP` AS `WAP`,`blr`.`MOBILE_ACCESS_CODE` AS `MOBILE_ACCESS_CODE`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`WEB_UI_CODE` AS `WEB_UI_CODE`,`blr`.`CA_APP_ACCESS` AS `CA_APP_ACCESS`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`content_map` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bulk_payment_approver_view`
--

/*!50001 DROP VIEW IF EXISTS `bulk_payment_approver_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bulk_payment_approver_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`REG_CUST_ID` AS `REG_CUST_ID`,`blr`.`REG_CUST_NAME` AS `REG_CUST_NAME`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CUST_NAME` AS `CUST_NAME`,`blr`.`MANDATORY` AS `MANDATORY`,`blr`.`ROLE_CODE` AS `ROLE_CODE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`OTP_GEN` AS `OTP_GEN`,`blr`.`OTP_EXP` AS `OTP_EXP`,`blr`.`max_approval_amount` AS `max_approval_amount`,`blr`.`SEQ_CODE` AS `SEQ_CODE`,`blr`.`CATEG_CODE` AS `CATEG_CODE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`bulk_payment_approver` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ret_sr_add_accnt_req_view`
--

/*!50001 DROP VIEW IF EXISTS `ret_sr_add_accnt_req_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ret_sr_add_accnt_req_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`retail_self_reg_add_accnt_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cust_act_audit_view`
--

/*!50001 DROP VIEW IF EXISTS `cust_act_audit_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cust_act_audit_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CHANNEL` AS `CHANNEL`,`blr`.`SCREEN` AS `SCREEN`,`blr`.`ACTION_AT` AS `ACTION_AT`,`blr`.`REQ_SOURCE` AS `REQ_SOURCE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cust_act_audit` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cif_mobile_view`
--

/*!50001 DROP VIEW IF EXISTS `cif_mobile_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cif_mobile_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`EMAIL` AS `EMAIL`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`CNAME` AS `CNAME`,`blr`.`CURR_PIN` AS `CURR_PIN`,`blr`.`PRIMARY_ACC` AS `PRIMARY_ACC`,`blr`.`NEW_PIN` AS `NEW_PIN`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cif_mobile` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `charge_type_range_archive_view`
--

/*!50001 DROP VIEW IF EXISTS `charge_type_range_archive_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `charge_type_range_archive_view` AS (select `ctr`.`Id` AS `Id`,`ctr`.`CHARGE_TYPE_ID` AS `CHARGE_TYPE_ID`,`ctr`.`SERVICE_ID` AS `SERVICE_ID`,`ctr`.`RANGE_FROM` AS `RANGE_FROM`,`ctr`.`RANGE_TO` AS `RANGE_TO`,`ctr`.`CHARGE_TYPE_CODE` AS `CHARGE_TYPE_CODE`,`ctr`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`ctr`.`CHARGE_VALUE2` AS `CHARGE_VALUE2`,`ctr`.`MADE_BY` AS `MADE_BY`,`ctr`.`MADE_AT` AS `MADE_AT`,`ctr`.`CHECKED_BY` AS `CHECKED_BY`,`ctr`.`CHECKED_AT` AS `CHECKED_AT`,`ctr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ctr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ctr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ctr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ctr`.`RSTATUS` AS `RSTATUS`,`ctr`.`CREATED_BY` AS `CREATED_BY`,`ctr`.`CREATED_AT` AS `CREATED_AT`,`ctr`.`MODIFIED_AT` AS `MODIFIED_AT`,`ctr`.`MODIFIED_BY` AS `MODIFIED_BY`,`ctr`.`ARCHIVED_BY` AS `ARCHIVED_BY`,`ctr`.`ARCHIVED_AT` AS `ARCHIVED_AT`,`ctr`.`ARCHIVE_CMT` AS `ARCHIVE_CMT`,`ccv`.`CATEGORY` AS `CHARGE_TYPE`,`ccv`.`IName` AS `INAME`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`ms`.`SERVICE_CODE` AS `SERVICE_CODE`,`ms`.`SERVICE_NAME` AS `SERVICE_NAME` from ((((`charge_type_range_archive` `ctr` join `customer_category_view` `ccv`) join `status_code` `sc`) join `status_code` `ascd`) join `master_service` `ms`) where ((`ctr`.`CHARGE_TYPE_ID` = `ccv`.`Id`) and (`ctr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ctr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ctr`.`SERVICE_ID` = `ms`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customer_list`
--

/*!50001 DROP VIEW IF EXISTS `report_customer_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customer_list` AS select `c`.`CREATED_AT` AS `CREATED_AT`,(select distinct `s`.`data_text` from `static_data` `s` where ((`c`.`RSTATUS` = `s`.`data_value`) and (`s`.`data_type` = 'ENTITY_STATUS'))) AS `RSTATUS`,`c`.`MODIFIED_AT` AS `MODIFIED_AT`,(select distinct `s`.`USER_ID` from `system_user` `s` where (`c`.`MADE_BY` = `s`.`Id`)) AS `MADE_BY`,(select distinct `s`.`USER_ID` from `system_user` `s` where (`c`.`CHECKED_BY` = `s`.`Id`)) AS `CHECKED_BY`,`c`.`EMAIL` AS `EMAIL`,`c`.`CIF` AS `CIF`,`c`.`CNAME` AS `CNAME`,`c`.`NATIONAL_ID` AS `NATIONAL_ID`,`c`.`MOBILE` AS `MOBILE`,(select distinct `s`.`data_text` from `static_data` `s` where ((`c`.`RSTATUS` = `s`.`data_value`) and (`s`.`data_type` = 'NATIONALITY'))) AS `NATIONALITY`,(select distinct `s`.`CATEGORY` from `customer_category` `s` where (`c`.`CUST_CAT` = `s`.`Id`)) AS `CUST_CAT`,(select distinct `i`.`INAME` from `institution` `i` where (`c`.`INSTITUTION_ID` = `i`.`Id`)) AS `INSTITUTION`,`a`.`ACC_NUM` AS `ACC_NUM`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from (`customer_view` `c` join `account` `a`) where (`c`.`CIF` = `a`.`CUST_ID`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `biller_view`
--

/*!50001 DROP VIEW IF EXISTS `biller_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `biller_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BILLER_NAME` AS `BILLER_NAME`,`blr`.`BILLER_ACNO` AS `BILLER_ACNO`,`blr`.`BILLER_TYPE` AS `BILLER_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`FLD1NAME` AS `FLD1NAME`,`blr`.`FLD2NAME` AS `FLD2NAME`,`blr`.`FLD3NAME` AS `FLD3NAME`,`blr`.`FLD4NAME` AS `FLD4NAME`,`blr`.`FLD5NAME` AS `FLD5NAME`,`blr`.`FLD1CODE` AS `FLD1CODE`,`blr`.`FLD2CODE` AS `FLD2CODE`,`blr`.`FLD3CODE` AS `FLD3CODE`,`blr`.`FLD4CODE` AS `FLD4CODE`,`blr`.`FLD5CODE` AS `FLD5CODE`,`blr`.`FLD1TYPE` AS `FLD1TYPE`,`blr`.`FLD2TYPE` AS `FLD2TYPE`,`blr`.`FLD3TYPE` AS `FLD3TYPE`,`blr`.`FLD4TYPE` AS `FLD4TYPE`,`blr`.`FLD5TYPE` AS `FLD5TYPE`,`blr`.`MIN_TRAN_AMT` AS `MIN_TRAN_AMT`,`blr`.`MAX_TRAN_AMT` AS `MAX_TRAN_AMT`,`blr`.`DLY_TRAN_AMT` AS `DLY_TRAN_AMT`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`CURR_CODE` AS `CURR_CODE`,`blr`.`PAY_TYPE` AS `PAY_TYPE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`biller` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bulk_payment_master_view`
--

/*!50001 DROP VIEW IF EXISTS `bulk_payment_master_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bulk_payment_master_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FILE_NAME` AS `FILE_NAME`,`blr`.`NO_OF_REC` AS `NO_OF_REC`,`blr`.`TOTAL_AMOUNT` AS `TOTAL_AMOUNT`,`blr`.`status` AS `STATUS`,`blr`.`batch_code` AS `BATCH_CODE`,`blr`.`SERVICE_TITLE` AS `SERVICE_TITLE`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`bulk_payment_master` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `retail_self_reg_request_view`
--

/*!50001 DROP VIEW IF EXISTS `retail_self_reg_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `retail_self_reg_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`PREFNAME` AS `PREFNAME`,`blr`.`EMPLOYER` AS `EMPLOYER`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`EMAIL` AS `EMAIL`,`blr`.`NATIONALID` AS `NATIONALID`,`blr`.`NATIONALITY` AS `NATIONALITY`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`NEEDOLBACCESS` AS `NEEDOLBACCESS`,`blr`.`NEEDMBACCESS` AS `NEEDMBACCESS`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`ROLE` AS `ROLE`,`blr`.`DEFAPPCIF` AS `DEFAPPCIF`,`blr`.`DEFAPPCIFNAME` AS `DEFAPPCIFNAME`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`JNTACCAPPCIF1NAME` AS `JNTACCAPPCIF1NAME`,`blr`.`JNTACCAPPCIF2NAME` AS `JNTACCAPPCIF2NAME`,`blr`.`JNTACCAPPCIF3NAME` AS `JNTACCAPPCIF3NAME`,`blr`.`JNTACCAPPCIF4NAME` AS `JNTACCAPPCIF4NAME`,`blr`.`JNTACCAPPCIF5NAME` AS `JNTACCAPPCIF5NAME`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`BULKAPPCIF1NAME` AS `BULKAPPCIF1NAME`,`blr`.`BULKAPPCIF2NAME` AS `BULKAPPCIF2NAME`,`blr`.`BULKAPPCIF3NAME` AS `BULKAPPCIF3NAME`,`blr`.`JNTACCAPPCIF1MA` AS `JNTACCAPPCIF1MA`,`blr`.`JNTACCAPPCIF2MA` AS `JNTACCAPPCIF2MA`,`blr`.`JNTACCAPPCIF3MA` AS `JNTACCAPPCIF3MA`,`blr`.`JNTACCAPPCIF4MA` AS `JNTACCAPPCIF4MA`,`blr`.`JNTACCAPPCIF5MA` AS `JNTACCAPPCIF5MA`,`blr`.`BULKAPPCIF1MA` AS `BULKAPPCIF1MA`,`blr`.`BULKAPPCIF2MA` AS `BULKAPPCIF2MA`,`blr`.`BULKAPPCIF3MA` AS `BULKAPPCIF3MA`,`blr`.`JNTACCAPPCIF1MNDAPP` AS `JNTACCAPPCIF1MNDAPP`,`blr`.`JNTACCAPPCIF2MNDAPP` AS `JNTACCAPPCIF2MNDAPP`,`blr`.`JNTACCAPPCIF3MNDAPP` AS `JNTACCAPPCIF3MNDAPP`,`blr`.`JNTACCAPPCIF4MNDAPP` AS `JNTACCAPPCIF4MNDAPP`,`blr`.`JNTACCAPPCIF5MNDAPP` AS `JNTACCAPPCIF5MNDAPP`,`blr`.`BULKAPPCIF1MNDAPP` AS `BULKAPPCIF1MNDAPP`,`blr`.`BULKAPPCIF2MNDAPP` AS `BULKAPPCIF2MNDAPP`,`blr`.`BULKAPPCIF3MNDAPP` AS `BULKAPPCIF3MNDAPP`,`blr`.`SECQ1` AS `SECQ1`,`blr`.`SECQ2` AS `SECQ2`,`blr`.`SECQ3` AS `SECQ3`,`blr`.`SECA1` AS `SECA1`,`blr`.`SECA2` AS `SECA2`,`blr`.`SECA3` AS `SECA3`,`blr`.`PREFMDOFCOMM` AS `PREFMDOFCOMM`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`retail_self_reg_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dnd_time_view`
--

/*!50001 DROP VIEW IF EXISTS `dnd_time_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dnd_time_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`MOBILE_NUMBER` AS `MOBILE_NUMBER`,`blr`.`APPLY_FOR_ALL` AS `APPLY_FOR_ALL`,`blr`.`FROM_DATE` AS `FROM_DATE`,`blr`.`TO_DATE` AS `TO_DATE`,`blr`.`FROM_TIME` AS `FROM_TIME`,`blr`.`TO_TIME` AS `TO_TIME`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`dnd_time` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_customer_acquisition`
--

/*!50001 DROP VIEW IF EXISTS `view_customer_acquisition`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_customer_acquisition` AS select `cust_acq`.`FIRST_NAME` AS `FIRST_NAME`,`cust_acq`.`LAST_NAME` AS `LAST_NAME`,`cust_acq`.`EMAIL` AS `EMAIL`,`cust_acq`.`CUST_TYPE` AS `ACCOUNT_TYPE`,`cust_acq`.`MOBILE` AS `CUST_MOBILE`,`cust_acq`.`SUBMIT_AG_NAME` AS `AGENT_NAME`,`cust_acq`.`AG_MOBILE` AS `AG_MOBILE`,`cust_acq`.`CA_STATUS` AS `STATUS`,`cust_acq`.`REG_STATUS` AS `REG_STATUS`,`cust_acq`.`CREATED_AT` AS `CREATED_AT` from `cust_acq` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_systemuser_list`
--

/*!50001 DROP VIEW IF EXISTS `report_systemuser_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_systemuser_list` AS select `c`.`CREATED_AT` AS `CREATED_AT`,`c`.`MODIFIED_AT` AS `MODIFIED_AT`,`c`.`FIRST_NAME` AS `FIRST_NAME`,`c`.`LAST_NAME` AS `LAST_NAME`,`c`.`EMAIL` AS `EMAIL`,`c`.`MOBILE` AS `MOBILE`,(select distinct `r`.`ROLENAME` from `user_role` `r` where (`c`.`USER_ROLE_ID` = `r`.`Id`)) AS `USER_ROLE_ID`,(select distinct `s`.`USER_ID` from `system_user` `s` where (`c`.`MADE_BY` = `s`.`Id`)) AS `MADE_BY`,(select distinct `s`.`USER_ID` from `system_user` `s` where (`c`.`CHECKED_BY` = `s`.`Id`)) AS `CHECKED_BY`,(select distinct `s`.`data_text` from `static_data` `s` where ((`c`.`RSTATUS` = `s`.`data_value`) and (`s`.`data_type` = 'ENTITY_STATUS'))) AS `RSTATUS`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `system_user` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_role_view`
--

/*!50001 DROP VIEW IF EXISTS `user_role_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user_role_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ROLENAME` AS `ROLENAME`,`blr`.`ADMIN_PERM` AS `ADMIN_PERM`,`blr`.`MAKER_PERM` AS `MAKER_PERM`,`blr`.`CHECKER_PERM` AS `CHECKER_PERM`,`blr`.`GLOBAL_ADMIN_PERM` AS `GLOBAL_ADMIN_PERM`,`blr`.`REPORT_PERM` AS `REPORT_PERM`,`blr`.`AUDIT_PERM` AS `AUDIT_PERM`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`user_role` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticket_comment_view`
--

/*!50001 DROP VIEW IF EXISTS `ticket_comment_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticket_comment_view` AS (select `blr`.`Id` AS `Id`,`blr`.`TICKET_ID` AS `TICKET_ID`,`blr`.`TDESC` AS `TDESC`,`blr`.`NEW_STATUS` AS `NEW_STATUS`,`blr`.`NEW_ASSIGNEE` AS `NEW_ASSIGNEE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`GROUP_CODE` AS `GROUP_CODE`,`blr`.`COMMENTOR_ID` AS `COMMENTOR_ID`,`blr`.`COMMENTOR_NAME` AS `COMMENTOR_NAME`,`blr`.`COMMENTOR_AT` AS `COMMENTOR_AT`,`blr`.`SOURCE_IP` AS `SOURCE_IP`,`blr`.`NEW_PRSEQ` AS `NEW_PRSEQ`,`blr`.`NEW_RECEST` AS `NEW_RECEST`,`blr`.`NEW_RESEST` AS `NEW_RESEST`,`blr`.`NEW_ESTIMATE` AS `NEW_ESTIMATE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ticket_comment` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `other_bank_branch_view`
--

/*!50001 DROP VIEW IF EXISTS `other_bank_branch_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `other_bank_branch_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BANK_ID` AS `BANK_ID`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`BRANCH_NAME` AS `BRANCH_NAME`,`blr`.`SWIFT_CODE` AS `SWIFT_CODE`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`other_bank_branch` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `corporate_view`
--

/*!50001 DROP VIEW IF EXISTS `corporate_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `corporate_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CORPORATE_ID` AS `CORPORATE_ID`,`blr`.`CORPORATE_NAME` AS `CORPORATE_NAME`,`blr`.`CONTACT_PERSON_NAME` AS `CONTACT_PERSON_NAME`,`blr`.`CONTACT_PERSON_MOBILE` AS `CONTACT_PERSON_MOBILE`,`blr`.`CONTACT_PERSON_EMAIL` AS `CONTACT_PERSON_EMAIL`,`blr`.`REQUEST_IP` AS `REQUEST_IP`,`blr`.`REMARKS` AS `REMARKS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`corporate` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `paccount_view`
--

/*!50001 DROP VIEW IF EXISTS `paccount_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `paccount_view` AS (select `ac`.`Id` AS `Id`,`ac`.`ACC_NUM` AS `ACC_NUM`,`ac`.`ALIAS` AS `ALIAS`,`ac`.`CUST_ID` AS `CUST_ID`,`ac`.`CURRENCY` AS `CURRENCY`,`ac`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ac`.`MADE_BY` AS `MADE_BY`,`ac`.`MADE_AT` AS `MADE_AT`,`ac`.`CHECKED_BY` AS `CHECKED_BY`,`ac`.`CHECKED_AT` AS `CHECKED_AT`,`ac`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ac`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ac`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ac`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ac`.`RSTATUS` AS `RSTATUS`,`ac`.`CREATED_BY` AS `CREATED_BY`,`ac`.`CREATED_AT` AS `CREATED_AT`,`ac`.`MODIFIED_AT` AS `MODIFIED_AT`,`ac`.`MODIFIED_BY` AS `MODIFIED_BY`,`ac`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`ac`.`REPORT_FREQ` AS `REPORT_FREQ`,`ac`.`ALLOW_SMS` AS `ALLOW_SMS`,`ac`.`ALLOW_EMAIL` AS `ALLOW_EMAIL`,`ac`.`SMS_THRES` AS `SMS_THRES`,`ac`.`EMAIL_THRES` AS `EMAIL_THRES`,`ac`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`ac`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`ac`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`ac`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`ac`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`ac`.`ADDTNL_SMS1` AS `ADDTNL_SMS1`,`ac`.`ADDTNL_SMS2` AS `ADDTNL_SMS2`,`ac`.`ADDTNL_SMS3` AS `ADDTNL_SMS3`,`ac`.`ADDTNL_SMS4` AS `ADDTNL_SMS4`,`ac`.`ADDTNL_SMS5` AS `ADDTNL_SMS5`,`ac`.`ACCEXTN1` AS `ACCEXTN1`,`ac`.`ACCEXTN2` AS `ACCEXTN2`,`ac`.`ACCEXTN3` AS `ACCEXTN3`,`ac`.`ACCEXTN4` AS `ACCEXTN4`,`ac`.`ACCEXTN5` AS `ACCEXTN5`,`ac`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`ac`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`ac`.`CURR_BALANCE` AS `CURR_BALANCE`,`ac`.`CURR_BALANCE_TYPE` AS `CURR_BALANCE_TYPE`,`ac`.`CURR_BAL_LASTUPD` AS `CURR_BAL_LASTUPD`,`ac`.`BRANCH_CODE` AS `BRANCH_CODE`,`ac`.`ALLOW_MOBILE` AS `ALLOW_MOBILE`,`ac`.`VIRTUAL_ACCOUNT` AS `VIRTUAL_ACCOUNT`,`ac`.`ALT_ACC_ID` AS `ALT_ACC_ID`,`ac`.`AH_CB_NAME` AS `AH_CB_NAME`,`ac`.`AH_CIF_NAME` AS `AH_CIF_NAME`,`ac`.`JOINT_ACCOUNT` AS `JOINT_ACCOUNT`,`ac`.`JOINT_ACCOUNT_MANDATES` AS `JOINT_ACCOUNT_MANDATES`,`ac`.`PRIMARY_ACCOUNT` AS `PRIMARY_ACCOUNT`,`ac`.`group_code` AS `group_code`,`ac`.`CRDMIN` AS `CRDMIN`,`ac`.`DEBMIN` AS `DEBMIN`,`ac`.`ALSALCR` AS `ALSALCR`,`ac`.`ALCHQDEP` AS `ALCHQDEP`,`ac`.`ALODAM` AS `ALODAM`,`ac`.`ALATM` AS `ALATM`,`ac`.`ACCCTYPE` AS `ACCCTYPE`,`ac`.`STMT_PRTY` AS `STMT_PRTY`,`cu`.`cname` AS `CNAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME` from ((((`account` `ac` join `customer` `cu`) join `institution` `inst`) join `status_code` `sc`) join `status_code` `ascd`) where ((`ac`.`INSTITUTION_ID` = `inst`.`Id`) and (`ac`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ac`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ac`.`CUST_ID` = `cu`.`CIF`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customer_statistics_view`
--

/*!50001 DROP VIEW IF EXISTS `report_customer_statistics_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customer_statistics_view` AS select `customer_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`customer_view`.`IName` AS `INSTITUTION`,`customer_view`.`CATEGORY` AS `CATEGORY`,`customer_view`.`CURR_APP_STATUS_NAME` AS `STATUS`,count(0) AS `COUNT` from `customer_view` group by `customer_view`.`INSTITUTION_ID`,`customer_view`.`IName`,`customer_view`.`CATEGORY`,`customer_view`.`CURR_APP_STATUS_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cust_acq_view`
--

/*!50001 DROP VIEW IF EXISTS `cust_acq_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cust_acq_view` AS (select `cav`.`Id` AS `Id`,`cav`.`SALUTN` AS `SALUTN`,`cav`.`FIRST_NAME` AS `FIRST_NAME`,`cav`.`MIDDLE_NAME` AS `MIDDLE_NAME`,`cav`.`LAST_NAME` AS `LAST_NAME`,`cav`.`EMAIL` AS `EMAIL`,`cav`.`IMG1` AS `IMG1`,`cav`.`IMG2` AS `IMG2`,`cav`.`IMG3` AS `IMG3`,`cav`.`IMG4` AS `IMG4`,`cav`.`IMG5` AS `IMG5`,`cav`.`SHORT_NAME` AS `SHORT_NAME`,`cav`.`CUST_TYPE` AS `CUST_TYPE`,`cav`.`ADDR_TYPE` AS `ADDR_TYPE`,`cav`.`COMM_TYPE` AS `COMM_TYPE`,`cav`.`DEV_NO` AS `DEV_NO`,`cav`.`DOC_ID` AS `DOC_ID`,`cav`.`REF_NO` AS `REF_NO`,`cav`.`SEC_ANA_TYPE` AS `SEC_ANA_TYPE`,`cav`.`ORG_CLASSF` AS `ORG_CLASSF`,`cav`.`ES_CLASSF` AS `ES_CLASSF`,`cav`.`AN_TYPE` AS `AN_TYPE`,`cav`.`AN_CODE` AS `AN_CODE`,`cav`.`NATIONAL_ID` AS `NATIONAL_ID`,`cav`.`MOBILE` AS `MOBILE`,`cav`.`DOB` AS `DOB`,`cav`.`ADDRESS` AS `ADDRESS`,`cav`.`SUBMIT_AG_NAME` AS `SUBMIT_AG_NAME`,`cav`.`AG_MOBILE` AS `AG_MOBILE`,`cav`.`CA_STATUS` AS `CA_STATUS`,`cav`.`REG_STATUS` AS `REG_STATUS`,`cav`.`REQ_CATEG` AS `REQ_CATEG`,`cav`.`CURR_CODE` AS `CURR_CODE`,`cav`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cav`.`MADE_BY` AS `MADE_BY`,`cav`.`MADE_AT` AS `MADE_AT`,`cav`.`CHECKED_BY` AS `CHECKED_BY`,`cav`.`CHECKED_AT` AS `CHECKED_AT`,`cav`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cav`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cav`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cav`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cav`.`RSTATUS` AS `RSTATUS`,`cav`.`CREATED_BY` AS `CREATED_BY`,`cav`.`CREATED_AT` AS `CREATED_AT`,`cav`.`MODIFIED_AT` AS `MODIFIED_AT`,`cav`.`MODIFIED_BY` AS `MODIFIED_BY`,`cav`.`ID1Checked` AS `ID1Checked`,`cav`.`ID2Checked` AS `ID2Checked`,`cav`.`PhotoChecked` AS `PhotoChecked`,`cav`.`SignatureChecked` AS `SignatureChecked`,`cav`.`IPRSChecked` AS `IPRSChecked`,`cav`.`CBCUST_ID` AS `CBCUST_ID`,`cav`.`CBACCNUM1` AS `CBACCNUM1`,`cav`.`CBACCNUM2` AS `CBACCNUM2`,`cav`.`CBACCNUM3` AS `CBACCNUM3`,`cav`.`CBACCNUM4` AS `CBACCNUM4`,`cav`.`RESULTCODE` AS `RESULTCODE`,`cav`.`RESULTDESC` AS `RESULTDESC`,`cav`.`BRANCH_ID` AS `BRANCH_ID`,`cav`.`ADDR` AS `ADDR`,`cav`.`NATURE_OF_BUS` AS `NATURE_OF_BUS`,`cav`.`AGENT_CODE` AS `AGENT_CODE`,`cav`.`AGENT_CAT` AS `AGENT_CAT`,`cav`.`DATE_CODE` AS `DATE_CODE`,`cav`.`ACCOUNT_OFFICER_ID` AS `ACCOUNT_OFFICER_ID`,`cav`.`ACCOUNT_OFFICER_NAME` AS `ACCOUNT_OFFICER_NAME`,`cav`.`NATIONAL_ID_CHECKED` AS `NATIONAL_ID_CHECKED`,`cav`.`TIN` AS `TIN`,`cav`.`RES_TYPE` AS `RES_TYPE`,`cav`.`MAR_STATUS` AS `MAR_STATUS`,`cav`.`EMPLOYER` AS `EMPLOYER`,`cav`.`ZIPCODE` AS `ZIPCODE`,`cav`.`CURRENCY` AS `CURRENCY`,`cav`.`NATIONALITY` AS `NATIONALITY`,`cav`.`ADDR1` AS `ADDR1`,`cav`.`ADDR2` AS `ADDR2`,`cav`.`ADDR3` AS `ADDR3`,`cav`.`ADDR4` AS `ADDR4`,`cav`.`GENDER` AS `GENDER`,`cav`.`CHILDCNT` AS `CHILDCNT`,`cav`.`OTPGEN` AS `OTPGEN`,`cav`.`OTPEXP` AS `OTPEXP`,`cav`.`OTPCONFIRMED` AS `OTPCONFIRMED`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cust_acq` `cav` left join `institution` `inst` on((`cav`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`cav`.`RSTATUS` = `sc`.`STATUS_ID`) and (`cav`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_request_view`
--

/*!50001 DROP VIEW IF EXISTS `user_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user_request_view` AS (select `er`.`Id` AS `Id`,`er`.`USERRECID` AS `USERRECID`,`er`.`USERID` AS `USERID`,`er`.`UNAME` AS `UNAME`,`er`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`er`.`COMMENTS` AS `COMMENTS`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`user_request` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `funds_tran_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `funds_tran_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `funds_tran_tran_view` AS select `ftt`.`Id` AS `Id`,`ftt`.`FTFROM` AS `FTFROM`,`ftt`.`FTTO` AS `FTTO`,`ftt`.`FTAMOUNT` AS `FTAMOUNT`,`ftt`.`FTRESULT` AS `FTRESULT`,`ftt`.`FTCURRCODE` AS `FTCURRCODE`,`ftt`.`FTCHARGE` AS `FTCHARGE`,`ftt`.`FTTRANTIME` AS `FTTRANTIME`,`ftt`.`FTCIF` AS `FTCIF`,`ftt`.`FTSOURCE` AS `FTSOURCE`,`ftt`.`FTPHONEID` AS `FTPHONEID`,`ftt`.`FTSESSIONID` AS `FTSESSIONID`,`ftt`.`FTREFNO` AS `FTREFNO`,`ftt`.`FTRESULTCODE` AS `FTRESULTCODE`,`ftt`.`ERRMSG` AS `ERRMSG`,`ftt`.`RSTATUS` AS `RSTATUS`,`ftt`.`CREATED_BY` AS `CREATED_BY`,`ftt`.`CREATED_AT` AS `CREATED_AT`,`ftt`.`MODIFIED_AT` AS `MODIFIED_AT`,`ftt`.`MODIFIED_BY` AS `MODIFIED_BY`,`ftt`.`FTTYPE` AS `FTTYPE`,`ftt`.`FTSUBCHARGE` AS `FTSUBCHARGE`,`ftt`.`FTSTEPFAILED` AS `FTSTEPFAILED`,`ftt`.`RESP1` AS `RESP1`,`ftt`.`RESP2` AS `RESP2`,`ftt`.`RESP3` AS `RESP3`,`ftt`.`RESP4` AS `RESP4`,`ftt`.`FTCOMMENT` AS `FTCOMMENT`,(case `ftt`.`FTRESULTCODE` when 1 then 'Yes' when 0 then 'No' end) AS `RESULTCODE` from `funds_transfer_transaction` `ftt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `service_access_view`
--

/*!50001 DROP VIEW IF EXISTS `service_access_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `service_access_view` AS (select `sa`.`Id` AS `Id`,`sa`.`CHARGE_TYPE_ID` AS `CHARGE_TYPE_ID`,`sa`.`SERVICE_ID` AS `SERVICE_ID`,`sa`.`ACTIVE_FLAG` AS `ACTIVE_FLAG`,`sa`.`MADE_BY` AS `MADE_BY`,`sa`.`MADE_AT` AS `MADE_AT`,`sa`.`CHECKED_BY` AS `CHECKED_BY`,`sa`.`CHECKED_AT` AS `CHECKED_AT`,`sa`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`sa`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`sa`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`sa`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`sa`.`RSTATUS` AS `RSTATUS`,`sa`.`CREATED_BY` AS `CREATED_BY`,`sa`.`CREATED_AT` AS `CREATED_AT`,`sa`.`MODIFIED_AT` AS `MODIFIED_AT`,`sa`.`MODIFIED_BY` AS `MODIFIED_BY`,`ccv`.`CATEGORY` AS `CHARGE_TYPE`,`ccv`.`IName` AS `INAME`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`ms`.`SERVICE_CODE` AS `SERVICE_CODE`,`ms`.`SERVICE_NAME` AS `SERVICE_NAME` from ((((`service_access` `sa` join `customer_category_view` `ccv`) join `status_code` `sc`) join `status_code` `ascd`) join `master_service` `ms`) where ((`sa`.`CHARGE_TYPE_ID` = `ccv`.`Id`) and (`sa`.`RSTATUS` = `sc`.`STATUS_ID`) and (`sa`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`sa`.`SERVICE_ID` = `ms`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mpesa_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `mpesa_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mpesa_tran_view` AS select `mpesa_tran`.`Id` AS `Id`,`mpesa_tran`.`MPID` AS `MPID`,`mpesa_tran`.`ORIG` AS `ORIG`,`mpesa_tran`.`DEST` AS `DEST`,`mpesa_tran`.`TSTAMP` AS `TSTAMP`,`mpesa_tran`.`MPTEXT` AS `MPTEXT`,`mpesa_tran`.`MPUSER` AS `MPUSER`,`mpesa_tran`.`MPPASS` AS `MPPASS`,`mpesa_tran`.`MPCODE` AS `MPCODE`,`mpesa_tran`.`MPCUSTID` AS `MPCUSTID`,`mpesa_tran`.`MPRTMETHODID` AS `MPRTMETHODID`,`mpesa_tran`.`MPRTMETHODNAME` AS `MPRTMETHODNAME`,`mpesa_tran`.`MPACC` AS `MPACC`,`mpesa_tran`.`MPISDN` AS `MPISDN`,`mpesa_tran`.`MPTDATE` AS `MPTDATE`,`mpesa_tran`.`MPTTIME` AS `MPTTIME`,`mpesa_tran`.`MPTAMT` AS `MPTAMT`,`mpesa_tran`.`MPSENDER` AS `MPSENDER`,`mpesa_tran`.`MPRESP` AS `MPRESP`,`mpesa_tran`.`MPERRMSG` AS `MPERRMSG`,`mpesa_tran`.`BANKCHARGES` AS `BANKCHARGES`,`mpesa_tran`.`SAFARICOMCHARGES` AS `SAFARICOMCHARGES`,`mpesa_tran`.`RCVBTRNSRESULT_CODE` AS `RCVBTRNSRESULT_CODE`,`mpesa_tran`.`RCVBTRNSRESULT` AS `RCVBTRNSRESULT`,`mpesa_tran`.`RCVBTRNSTS` AS `RCVBTRNSTS`,`mpesa_tran`.`RCVBTRNSAMT` AS `RCVBTRNSAMT`,`mpesa_tran`.`CUSTTRNSRESULT_CODE` AS `CUSTTRNSRESULT_CODE`,`mpesa_tran`.`CUSTTRNSRESULT` AS `CUSTTRNSRESULT`,`mpesa_tran`.`CUSTTRNSTS` AS `CUSTTRNSTS`,`mpesa_tran`.`CUSTTRNSAMT` AS `CUSTTRNSAMT`,`mpesa_tran`.`BANKCHRGRESULT_CODE` AS `BANKCHRGRESULT_CODE`,`mpesa_tran`.`BANKCHRGRESULT` AS `BANKCHRGRESULT`,`mpesa_tran`.`BANKCHRGTS` AS `BANKCHRGTS`,`mpesa_tran`.`BANKCHRGAMT` AS `BANKCHRGAMT`,`mpesa_tran`.`MPESACHRGRESULT_CODE` AS `MPESACHRGRESULT_CODE`,`mpesa_tran`.`MPESACHRGRESULT` AS `MPESACHRGRESULT`,`mpesa_tran`.`MPESACHRGTS` AS `MPESACHRGTS`,`mpesa_tran`.`MPESACHRGAMT` AS `MPESACHRGAMT`,`mpesa_tran`.`SUSPENSERESULT_CODE` AS `SUSPENSERESULT_CODE`,`mpesa_tran`.`SUSPENSERESULT` AS `SUSPENSERESULT`,`mpesa_tran`.`SUSPENSECHRGTS` AS `SUSPENSECHRGTS`,`mpesa_tran`.`SUSPENSECHRGAMT` AS `SUSPENSECHRGAMT`,`mpesa_tran`.`MADE_BY` AS `MADE_BY`,`mpesa_tran`.`MADE_AT` AS `MADE_AT`,`mpesa_tran`.`CHECKED_BY` AS `CHECKED_BY`,`mpesa_tran`.`CHECKED_AT` AS `CHECKED_AT`,`mpesa_tran`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`mpesa_tran`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`mpesa_tran`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`mpesa_tran`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`mpesa_tran`.`RSTATUS` AS `RSTATUS`,`mpesa_tran`.`STATUS_DESC` AS `STATUS_DESC`,`mpesa_tran`.`CREATED_BY` AS `CREATED_BY`,`mpesa_tran`.`CREATED_AT` AS `CREATED_AT`,`mpesa_tran`.`MODIFIED_AT` AS `MODIFIED_AT`,`mpesa_tran`.`MODIFIED_BY` AS `MODIFIED_BY`,`mpesa_tran`.`REQUEST_SOURCE_IP` AS `REQUEST_SOURCE_IP`,date_format(`mpesa_tran`.`CREATED_AT`,'%Y%m%d%H%i%S') AS `DATEVAL` from `mpesa_tran` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `employer_view`
--

/*!50001 DROP VIEW IF EXISTS `employer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `employer_view` AS (select `er`.`Id` AS `Id`,`er`.`EMPLOYER_ID` AS `EMPLOYER_ID`,`er`.`EMPLOYER_NAME` AS `EMPLOYER_NAME`,`er`.`OTHER_INFO` AS `OTHER_INFO`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`employer` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `health_check_view`
--

/*!50001 DROP VIEW IF EXISTS `health_check_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `health_check_view` AS select `hcs`.`Id` AS `Id`,`hcs`.`CHECK_TITLE` AS `CHECK_TITLE`,`hcs`.`CHECK_CODE` AS `CHECK_CODE`,`hcs`.`CHECK_CLASS` AS `CHECK_CLASS`,`hcs`.`CHECK_METHOD` AS `CHECK_METHOD`,`hcs`.`RSTATUS` AS `RSTATUS`,`hcs`.`CREATED_BY` AS `CREATED_BY`,`hcs`.`CREATED_AT` AS `CREATED_AT`,`hcs`.`MODIFIED_AT` AS `MODIFIED_AT`,`hcs`.`MODIFIED_BY` AS `MODIFIED_BY`,`hcstat`.`CHECK_ID` AS `CHECK_ID`,`hcstat`.`CHECK_TS` AS `CHECK_TS`,`hcstat`.`CHECK_STATUS` AS `CHECK_STATUS`,`hcstat`.`CHECK_STATUS_MESSAGE` AS `CHECK_STATUS_MESSAGE` from (`health_check_service` `hcs` join `health_check_stat` `hcstat`) where ((`hcs`.`RSTATUS` = '1') and (`hcs`.`Id` = `hcstat`.`CHECK_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `charge_type_range_view`
--

/*!50001 DROP VIEW IF EXISTS `charge_type_range_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `charge_type_range_view` AS (select `ctr`.`Id` AS `Id`,`ctr`.`CHARGE_TYPE_ID` AS `CHARGE_TYPE_ID`,`ctr`.`SERVICE_ID` AS `SERVICE_ID`,`ctr`.`RANGE_FROM` AS `RANGE_FROM`,`ctr`.`RANGE_TO` AS `RANGE_TO`,`ctr`.`CHARGE_TYPE_CODE` AS `CHARGE_TYPE_CODE`,`ctr`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`ctr`.`CHARGE_VALUE2` AS `CHARGE_VALUE2`,`ctr`.`MADE_BY` AS `MADE_BY`,`ctr`.`MADE_AT` AS `MADE_AT`,`ctr`.`CHECKED_BY` AS `CHECKED_BY`,`ctr`.`CHECKED_AT` AS `CHECKED_AT`,`ctr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ctr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ctr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ctr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ctr`.`RSTATUS` AS `RSTATUS`,`ctr`.`CREATED_BY` AS `CREATED_BY`,`ctr`.`CREATED_AT` AS `CREATED_AT`,`ctr`.`MODIFIED_AT` AS `MODIFIED_AT`,`ctr`.`MODIFIED_BY` AS `MODIFIED_BY`,`ctr`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`ctr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ccv`.`CATEGORY` AS `CHARGE_TYPE`,`ccv`.`IName` AS `INAME`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`ms`.`SERVICE_CODE` AS `SERVICE_CODE`,`ms`.`SERVICE_NAME` AS `SERVICE_NAME` from ((((`charge_type_range` `ctr` join `customer_category_view` `ccv`) join `status_code` `sc`) join `status_code` `ascd`) join `master_service` `ms`) where ((`ctr`.`CHARGE_TYPE_ID` = `ccv`.`Id`) and (`ctr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ctr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ctr`.`SERVICE_ID` = `ms`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `misc_request_view`
--

/*!50001 DROP VIEW IF EXISTS `misc_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `misc_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`REQUEST_CODE` AS `REQUEST_CODE`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`EXTN11` AS `EXTN11`,`blr`.`EXTN12` AS `EXTN12`,`blr`.`EXTN13` AS `EXTN13`,`blr`.`EXTN14` AS `EXTN14`,`blr`.`EXTN15` AS `EXTN15`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`made_by` AS `made_by`,`blr`.`made_at` AS `made_at`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`misc_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_tran_limits_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_tran_limits_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_tran_limits_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`MIN_TRAN_AMOUNT` AS `MIN_TRAN_AMOUNT`,`blr`.`MAX_TRAN_AMOUNT` AS `MAX_TRAN_AMOUNT`,`blr`.`MAX_FREQUENCY` AS `MAX_FREQUENCY`,`blr`.`DAILY_AMT_LIMIT` AS `DAILY_AMT_LIMIT`,`blr`.`LIMIT_TYPE` AS `LIMIT_TYPE`,`blr`.`TRAN_TYPE_CODE` AS `TRAN_TYPE_CODE`,`blr`.`TRAN_TYPE_DESC` AS `TRAN_TYPE_DESC`,`blr`.`TEMP_START_DATE` AS `TEMP_START_DATE`,`blr`.`TEMP_END_DATE` AS `TEMP_END_DATE`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`customer_transaction_limits` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticket_status_view`
--

/*!50001 DROP VIEW IF EXISTS `ticket_status_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticket_status_view` AS (select `blr`.`Id` AS `Id`,`blr`.`TICKET_ID` AS `TICKET_ID`,`blr`.`TNEWSTATUSCMNT` AS `TNEWSTATUSCMNT`,`blr`.`TNEWSTATUS` AS `TNEWSTATUS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`GROUP_CODE` AS `GROUP_CODE`,`blr`.`COMMENTOR_ID` AS `COMMENTOR_ID`,`blr`.`COMMENTOR_NAME` AS `COMMENTOR_NAME`,`blr`.`COMMENTOR_AT` AS `COMMENTOR_AT`,`blr`.`SOURCE_IP` AS `SOURCE_IP`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ticket_status` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_mobile_bp_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_mobile_bp_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_mobile_bp_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`RCOPERATOR` AS `RCOPERATOR`,`er`.`RCAMOUNT` AS `RCAMOUNT`,`er`.`RCMOBILE` AS `RCMOBILE`,`er`.`RCTYPE` AS `RCTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_mobile_recharge_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `alert_rule_view`
--

/*!50001 DROP VIEW IF EXISTS `alert_rule_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `alert_rule_view` AS (select `blr`.`Id` AS `Id`,`blr`.`TRANSACTION` AS `TRANSACTION`,`blr`.`RULE_FLD1` AS `RULE_FLD1`,`blr`.`RULE_FLD2` AS `RULE_FLD2`,`blr`.`RULE_FLD3` AS `RULE_FLD3`,`blr`.`RULE_FLD4` AS `RULE_FLD4`,`blr`.`RULE_FLD5` AS `RULE_FLD5`,`blr`.`RULE_FLD6` AS `RULE_FLD6`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`alert_rule` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_mob_user_usage_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `rep_mob_user_usage_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_mob_user_usage_stat_view` AS select `mobile_access_log_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`mobile_access_log_view`.`INAME` AS `INSTITUTION`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') AS `DATEVAL`,count(distinct `mobile_access_log_view`.`CIFNO`) AS `COUNT` from `mobile_access_log_view` group by `mobile_access_log_view`.`INSTITUTION_ID`,`mobile_access_log_view`.`INAME`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `airtime_voucher_view`
--

/*!50001 DROP VIEW IF EXISTS `airtime_voucher_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `airtime_voucher_view` AS (select `blr`.`Id` AS `Id`,`blr`.`PROVIDER` AS `PROVIDER`,`blr`.`AIRTIME_CODE` AS `AIRTIME_CODE`,`blr`.`AIRTIME_VALUE` AS `AIRTIME_VALUE`,`blr`.`CURRENCY` AS `CURRENCY`,`blr`.`EXPIRY_AT` AS `EXPIRY_AT`,`blr`.`INT_DATA_VALUE` AS `INT_DATA_VALUE`,`blr`.`ALLOTED_MOBILE` AS `ALLOTED_MOBILE`,`blr`.`ALLOTED_AT` AS `ALLOTED_AT`,`blr`.`ALLOTED_CHANNEL` AS `ALLOTED_CHANNEL`,`blr`.`AIRTIME_STATUS` AS `AIRTIME_STATUS`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`SERIAL_NO` AS `SERIAL_NO`,`blr`.`BATCH_NO` AS `BATCH_NO`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`airtime_voucher` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_gs_bp_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_gs_bp_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_gs_bp_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`PAYMENT_REF` AS `PAYMENT_REF`,`er`.`BPOPERATOR` AS `BPOPERATOR`,`er`.`BPAMOUNT` AS `BPAMOUNT`,`er`.`BPNUM` AS `BPNUM`,`er`.`BPTYPE` AS `BPTYPE`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`RCTRAN_RESULT_CODE` AS `RCTRAN_RESULT_CODE`,`er`.`RCTRAN_RESULT_DESC` AS `RCTRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_gs_bp_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sb_event_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `sb_event_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sb_event_stat_view` AS select `ses`.`Id` AS `Id`,`ses`.`EVENT_ID` AS `EVENT_ID`,`ses`.`TBP_FBID` AS `TBP_FBID`,`ses`.`TBP_FBNAME` AS `TBP_FBNAME`,`ses`.`TBP_MAIL` AS `TBP_MAIL`,`ses`.`TBP_MOBILE` AS `TBP_MOBILE`,`ses`.`TBP_STATUS` AS `TBP_STATUS`,`ses`.`REMINDERS_SENT` AS `REMINDERS_SENT`,`ses`.`LAST_REM_AT` AS `LAST_REM_AT`,`ses`.`TBP_COMMENTS` AS `TBP_COMMENTS`,`ses`.`TBP_VOUCHER` AS `TBP_VOUCHER`,`ses`.`RSTATUS` AS `RSTATUS`,`ses`.`CREATED_BY` AS `CREATED_BY`,`ses`.`CREATED_AT` AS `CREATED_AT`,`ses`.`MODIFIED_AT` AS `MODIFIED_AT`,`ses`.`MODIFIED_BY` AS `MODIFIED_BY`,`ses`.`TBP_AMT` AS `TBP_AMT`,`se`.`EVENT_NAME` AS `event_name`,`se`.`EVENT_STATUS` AS `event_status`,`se`.`EVENT_CATEGORY` AS `event_category`,`se`.`EVENT_SPLIT_TYPE` AS `event_split_type`,`se`.`EVENT_PAIDCNT` AS `event_paidcnt`,`se`.`EVENT_PENDINGCNT` AS `event_pendingcnt`,`se`.`EVENT_FRNDCNT` AS `event_frndcnt`,`se`.`EVENT_AMT` AS `event_amt`,`se`.`EVENT_CREATETS` AS `event_createts`,`se`.`EVENT_DESC` AS `event_desc` from (`sb_event_stat` `ses` join `sb_event` `se`) where (`ses`.`EVENT_ID` = `se`.`Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bond_reg_dtl_view`
--

/*!50001 DROP VIEW IF EXISTS `bond_reg_dtl_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bond_reg_dtl_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FNAME` AS `FNAME`,`blr`.`LNAME` AS `LNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`VIR_ACC_NUM` AS `VIR_ACC_NUM`,`blr`.`INV_ACC_NUM` AS `INV_ACC_NUM`,`blr`.`DOB` AS `DOB`,`blr`.`CIF` AS `CIF`,`blr`.`PIN` AS `PIN`,`blr`.`MESSAGE` AS `MESSAGE`,`blr`.`LOAN_TERM` AS `LOAN_TERM`,`blr`.`REG_STATUS` AS `REG_STATUS`,`blr`.`NATIONAL_ID` AS `NATIONAL_ID`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`bond_reg_dtl` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `remember_me_view`
--

/*!50001 DROP VIEW IF EXISTS `remember_me_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `remember_me_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`FEATURE_CODE` AS `FEATURE_CODE`,`blr`.`PARAMS` AS `PARAMS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`remember_me` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `intf_call_log_view`
--

/*!50001 DROP VIEW IF EXISTS `intf_call_log_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `intf_call_log_view` AS select `icl`.`Id` AS `Id`,`icl`.`SERVICE_CODE` AS `SERVICE_CODE`,`icl`.`SERVICE_MAP_ID` AS `SERVICE_MAP_ID`,`icl`.`REQUEST_MAP` AS `REQUEST_MAP`,`icl`.`MESSAGE` AS `MESSAGE`,`icl`.`RESULT` AS `RESULT`,`icl`.`REQUEST_TS` AS `REQUEST_TS`,`icl`.`RESPONSE_TS` AS `RESPONSE_TS`,`icl`.`ERROR_MESG` AS `ERROR_MESG`,`icl`.`CHARGES` AS `CHARGES`,`icl`.`REQUESTOR_ID` AS `REQUESTOR_ID`,`icl`.`SESSION_ID` AS `SESSION_ID`,`icl`.`REQUEST_SOURCE` AS `REQUEST_SOURCE`,`icl`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`icl`.`MADE_BY` AS `MADE_BY`,`icl`.`MADE_AT` AS `MADE_AT`,`icl`.`CHECKED_BY` AS `CHECKED_BY`,`icl`.`CHECKED_AT` AS `CHECKED_AT`,`icl`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`icl`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`icl`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`icl`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`icl`.`RSTATUS` AS `RSTATUS`,`icl`.`CREATED_BY` AS `CREATED_BY`,`icl`.`CREATED_AT` AS `CREATED_AT`,`icl`.`MODIFIED_AT` AS `MODIFIED_AT`,`icl`.`MODIFIED_BY` AS `MODIFIED_BY`,`icl`.`RESPONSE_MAP` AS `RESPONSE_MAP`,`icl`.`CUST_NAME` AS `CUST_NAME`,`icl`.`CID` AS `CID`,substr(`icl`.`REQUEST_TS`,1,8) AS `dateval` from `intf_call_log` `icl` where (trim(length(`icl`.`SERVICE_CODE`)) > 4) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ft_request_view`
--

/*!50001 DROP VIEW IF EXISTS `ft_request_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ft_request_view` AS (select `blr`.`Id` AS `Id`,`blr`.`FROM_ACC` AS `FROM_ACC`,`blr`.`FROM_CIF` AS `FROM_CIF`,`blr`.`TO_CIF` AS `TO_CIF`,`blr`.`FROM_NAME` AS `FROM_NAME`,`blr`.`TO_NAME` AS `TO_NAME`,`blr`.`TO_ACC` AS `TO_ACC`,`blr`.`FT_AMT` AS `FT_AMT`,`blr`.`FT_REM` AS `FT_REM`,`blr`.`FT_RESULT` AS `FT_RESULT`,`blr`.`FT_RESULT_DESC` AS `FT_RESULT_DESC`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ft_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mvisa_merchant_view`
--

/*!50001 DROP VIEW IF EXISTS `mvisa_merchant_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mvisa_merchant_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`IDNUM` AS `IDNUM`,`blr`.`PINNUM` AS `PINNUM`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`IDPRESENT` AS `IDPRESENT`,`blr`.`SIGNOK` AS `SIGNOK`,`blr`.`POST_ADDR` AS `POST_ADDR`,`blr`.`BUS_NAME` AS `BUS_NAME`,`blr`.`BUS_PIN` AS `BUS_PIN`,`blr`.`BUS_TYPE` AS `BUS_TYPE`,`blr`.`BUS_CODE` AS `BUS_CODE`,`blr`.`BUS_LOC` AS `BUS_LOC`,`blr`.`BUS_PSTADDR` AS `BUS_PSTADDR`,`blr`.`BUS_PSTCODE` AS `BUS_PSTCODE`,`blr`.`ISBUS_PIN_PRE` AS `ISBUS_PIN_PRE`,`blr`.`BUS_CERT` AS `BUS_CERT`,`blr`.`BANK_CODE` AS `BANK_CODE`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`BANK_ACC_NUM` AS `BANK_ACC_NUM`,`blr`.`MERC_DISC_RATE` AS `MERC_DISC_RATE`,`blr`.`MERC_FULL_ID` AS `MERC_FULL_ID`,`blr`.`MERC_ID` AS `MERC_ID`,`blr`.`NOTF_METHOD` AS `NOTF_METHOD`,`blr`.`NOTF_DEVID` AS `NOTF_DEVID`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`PUSH_URL` AS `PUSH_URL`,`blr`.`ALIAS_NAME` AS `ALIAS_NAME`,`blr`.`PRIMARY_CARD` AS `PRIMARY_CARD`,`blr`.`MERC_PWD` AS `MERC_PWD`,`blr`.`NOTIF_MAIL` AS `NOTIF_MAIL`,`blr`.`MERC_INIT_PWD` AS `MERC_INIT_PWD`,`blr`.`addtn_mob1` AS `addtn_mob1`,`blr`.`addtn_mob2` AS `addtn_mob2`,`blr`.`addtn_mob3` AS `addtn_mob3`,`blr`.`addtn_mob4` AS `addtn_mob4`,`blr`.`addtn_mob5` AS `addtn_mob5`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`mvisa_merchant` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `service_list_view`
--

/*!50001 DROP VIEW IF EXISTS `service_list_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `service_list_view` AS select `sl`.`Id` AS `Id`,`sl`.`SCODE` AS `SCODE`,`sl`.`SNAME` AS `SNAME`,`sl`.`SCATG` AS `SCATG`,`sl`.`SCATG1` AS `SCATG1`,`sl`.`SCATG2` AS `SCATG2`,`sl`.`SPARENT` AS `SPARENT`,`sl`.`RSTATUS` AS `RSTATUS`,`sl`.`CREATED_BY` AS `CREATED_BY`,`sl`.`CREATED_AT` AS `CREATED_AT`,`sl`.`MODIFIED_AT` AS `MODIFIED_AT`,`sl`.`MODIFIED_BY` AS `MODIFIED_BY`,(case `sl`.`RSTATUS` when 1 then 'Yes' when 0 then 'No' end) AS `ACTIVE` from `service_list` `sl` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `web_login_failed_login_view`
--

/*!50001 DROP VIEW IF EXISTS `web_login_failed_login_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `web_login_failed_login_view` AS select `fl`.`ID` AS `ID`,`fl`.`username` AS `username`,`fl`.`email` AS `email`,`fl`.`source` AS `source`,`fl`.`created_at` AS `created_at`,`fl`.`created_by` AS `created_by`,`fl`.`modified_at` AS `modified_at`,`fl`.`modified_by` AS `modified_by`,concat(`suv`.`FIRST_NAME`,' ',`suv`.`LAST_NAME`) AS `UName`,`suv`.`INSTITUTION_ID` AS `Institution_id`,`suv`.`IName` AS `IName` from (`failed_login` `fl` left join `system_user_view` `suv` on((`fl`.`username` = `suv`.`USER_ID`))) where (`fl`.`source` like 'Web%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customers_estatements`
--

/*!50001 DROP VIEW IF EXISTS `report_customers_estatements`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customers_estatements` AS select `customer`.`cname` AS `cname`,`customer`.`VAL_ACC` AS `val_acc`,substr(`customer`.`VAL_ACC`,2,3) AS `branch`,`customer`.`NATIONAL_ID` AS `national_id`,`customer`.`MOBILE` AS `mobile`,`customer`.`EMAIL` AS `email`,date_format(`customer`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `customer` where (`customer`.`REPORT_FREQ` <> 'None') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_systemuser_creation_history`
--

/*!50001 DROP VIEW IF EXISTS `report_systemuser_creation_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_systemuser_creation_history` AS select `c`.`USER_ID` AS `USERNAME`,(select `user_role`.`ROLENAME` from `user_role` where (`user_role`.`Id` = `c`.`USER_ROLE_ID`)) AS `ROLE`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CREATED_BY`)) AS `CREATED_BY`,`c`.`CREATED_AT` AS `CREATED_AT`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CHECKED_BY`)) AS `CHECKED_BY`,`c`.`CHECKED_AT` AS `CHECKED_AT`,(select `institution`.`INAME` from `institution` where (`institution`.`Id` = `c`.`INSTITUTION_ID`)) AS `INSTITUTION`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `system_user` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rtl_sr_add_accnt_request`
--

/*!50001 DROP VIEW IF EXISTS `rtl_sr_add_accnt_request`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rtl_sr_add_accnt_request` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`CNAME` AS `CNAME`,`blr`.`MOBILE` AS `MOBILE`,`blr`.`REGACCOUNTNO` AS `REGACCOUNTNO`,`blr`.`JNTACCOUNT` AS `JNTACCOUNT`,`blr`.`MANDCNT` AS `MANDCNT`,`blr`.`JNTACCAPPCIF1` AS `JNTACCAPPCIF1`,`blr`.`JNTACCAPPCIF2` AS `JNTACCAPPCIF2`,`blr`.`JNTACCAPPCIF3` AS `JNTACCAPPCIF3`,`blr`.`JNTACCAPPCIF4` AS `JNTACCAPPCIF4`,`blr`.`JNTACCAPPCIF5` AS `JNTACCAPPCIF5`,`blr`.`BULKAPPCIF1` AS `BULKAPPCIF1`,`blr`.`BULKAPPCIF2` AS `BULKAPPCIF2`,`blr`.`BULKAPPCIF3` AS `BULKAPPCIF3`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`retail_self_reg_add_accnt_request` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `charge_type_view`
--

/*!50001 DROP VIEW IF EXISTS `charge_type_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `charge_type_view` AS (select `ct`.`Id` AS `Id`,`ct`.`CHARGE_TYPE` AS `CHARGE_TYPE`,`ct`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`ct`.`MADE_BY` AS `MADE_BY`,`ct`.`MADE_AT` AS `MADE_AT`,`ct`.`CHECKED_BY` AS `CHECKED_BY`,`ct`.`CHECKED_AT` AS `CHECKED_AT`,`ct`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ct`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ct`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ct`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ct`.`RSTATUS` AS `RSTATUS`,`ct`.`CREATED_BY` AS `CREATED_BY`,`ct`.`CREATED_AT` AS `CREATED_AT`,`ct`.`MODIFIED_AT` AS `MODIFIED_AT`,`ct`.`MODIFIED_BY` AS `MODIFIED_BY`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME` from (((`charge_type` `ct` left join `institution` `inst` on((`ct`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`ct`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ct`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `eod_requests_view`
--

/*!50001 DROP VIEW IF EXISTS `eod_requests_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `eod_requests_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`AMOUNT` AS `AMOUNT`,`blr`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`blr`.`PERCENTAGE` AS `PERCENTAGE`,`blr`.`MATURITY_DATE` AS `MATURITY_DATE`,`blr`.`FREQUENCY` AS `FREQUENCY`,`blr`.`AUTO_DEBIT` AS `AUTO_DEBIT`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`eod_requests` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_reqeust_viewwgc`
--

/*!50001 DROP VIEW IF EXISTS `customer_reqeust_viewwgc`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_reqeust_viewwgc` AS select `crview`.`Id` AS `Id`,`crview`.`CIF` AS `CIF`,`crview`.`CNAME` AS `CNAME`,`crview`.`REQUEST_TYPE` AS `REQUEST_TYPE`,`crview`.`COMMENTS` AS `COMMENTS`,`crview`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`crview`.`MADE_BY` AS `MADE_BY`,`crview`.`MADE_AT` AS `MADE_AT`,`crview`.`CHECKED_BY` AS `CHECKED_BY`,`crview`.`CHECKED_AT` AS `CHECKED_AT`,`crview`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`crview`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`crview`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`crview`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`crview`.`RSTATUS` AS `RSTATUS`,`crview`.`CREATED_BY` AS `CREATED_BY`,`crview`.`CREATED_AT` AS `CREATED_AT`,`crview`.`MODIFIED_AT` AS `MODIFIED_AT`,`crview`.`MODIFIED_BY` AS `MODIFIED_BY`,`crview`.`REQUEST_DESC` AS `REQUEST_DESC`,`crview`.`REQUEST_STATUS` AS `REQUEST_STATUS`,`crview`.`REQUEST_CHG_DESC` AS `REQUEST_CHG_DESC`,`crview`.`STATUS_NAME` AS `STATUS_NAME`,`crview`.`CURR_APP_STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`crview`.`IName` AS `IName`,`su`.`GROUP_CODE` AS `group_code` from (`customer_reqeust_view` `crview` left join `system_user` `su` on((`crview`.`MADE_BY` = `su`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pin_migration_view`
--

/*!50001 DROP VIEW IF EXISTS `pin_migration_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pin_migration_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`OLD_PWD` AS `OLD_PWD`,`blr`.`NEW_PWD` AS `NEW_PWD`,`blr`.`PREF_TYPE` AS `PREF_TYPE`,`blr`.`COMMENTS` AS `COMMENTS`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`pin_migration` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_channel_usage`
--

/*!50001 DROP VIEW IF EXISTS `report_channel_usage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_channel_usage` AS select `ms`.`CIFNO` AS `CIF`,`c`.`cname` AS `CUST_NAME`,`c`.`MOBILE` AS `CUST_MOBILE`,`ms`.`SESSIONID` AS `SESSIONID`,date_format(`ms`.`CREATED_AT`,'%Y%m%d%H%i%S') AS `CREATED_AT`,date_format(`ms`.`LASTACC`,'%Y%m%d%H%i%S') AS `LASTACC`,`ms`.`CLOSED_AT` AS `CLOSED_AT`,`ms`.`CLOSE_TYPE` AS `CLOSE_TYPE`,`ms`.`LAST_PHONE_TYPE` AS `REQSOURCE`,date_format(`ms`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL`,timestampdiff(SECOND,`ms`.`CREATED_AT`,`ms`.`LASTACC`) AS `DIFFTIMESECONDS` from (`mobile_session2` `ms` join `customer` `c`) where (convert(`ms`.`CIFNO` using utf8) = `c`.`CIF`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_category_view_cbz`
--

/*!50001 DROP VIEW IF EXISTS `customer_category_view_cbz`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_category_view_cbz` AS select `cc`.`Id` AS `Id`,`cc`.`CATEGORY` AS `CATEGORY`,`cc`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cc`.`CHARGE_TYPE` AS `CHARGE_TYPE`,`cc`.`CHARGE_VALUE` AS `CHARGE_VALUE`,`cc`.`PER_DAY_LIMIT` AS `PER_DAY_LIMIT`,`cc`.`PER_TRAN_LIMIT` AS `PER_TRAN_LIMIT`,`cc`.`MIN_TRAN_LIMIT` AS `MIN_TRAN_LIMIT`,`cc`.`MADE_BY` AS `MADE_BY`,`cc`.`MADE_AT` AS `MADE_AT`,`cc`.`CHECKED_BY` AS `CHECKED_BY`,`cc`.`CHECKED_AT` AS `CHECKED_AT`,`cc`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cc`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cc`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cc`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cc`.`RSTATUS` AS `RSTATUS`,`cc`.`CREATED_BY` AS `CREATED_BY`,`cc`.`CREATED_AT` AS `CREATED_AT`,`mstrsrv`.`SERVICE_NAME` AS `SERVICE_ID`,`cc`.`MODIFIED_AT` AS `MODIFIED_AT`,`cc`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from ((((`customer_category` `cc` left join `institution` `inst` on((`cc`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `master_service` `mstrsrv`) where ((`cc`.`RSTATUS` = `sc`.`STATUS_ID`) and (`cc`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`cc`.`SERVICE_ID` = `mstrsrv`.`Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agency_details_view`
--

/*!50001 DROP VIEW IF EXISTS `agency_details_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agency_details_view` AS (select `blr`.`Id` AS `Id`,`blr`.`DOMIBRNCH` AS `DOMIBRNCH`,`blr`.`NATIONALTY` AS `NATIONALTY`,`blr`.`PROFCONT1` AS `PROFCONT1`,`blr`.`PROFCONT2` AS `PROFCONT2`,`blr`.`SERVPK` AS `SERVPK`,`blr`.`BRNCHCODE` AS `BRNCHCODE`,`blr`.`PROFPROV` AS `PROFPROV`,`blr`.`PROFAGCODE` AS `PROFAGCODE`,`blr`.`TRDNAME` AS `TRDNAME`,`blr`.`PSTADDR` AS `PSTADDR`,`blr`.`LRNUM` AS `LRNUM`,`blr`.`PSTCITY` AS `PSTCITY`,`blr`.`PSTZIP` AS `PSTZIP`,`blr`.`BUSLOC` AS `BUSLOC`,`blr`.`PHYADDR` AS `PHYADDR`,`blr`.`BUSSTAT` AS `BUSSTAT`,`blr`.`BUSNAME` AS `BUSNAME`,`blr`.`BUSDESIG` AS `BUSDESIG`,`blr`.`BUSNATIONALITY` AS `BUSNATIONALITY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`MAST_AGCODE` AS `MAST_AGCODE`,`blr`.`accnum1` AS `accnum1`,`blr`.`accnum2` AS `accnum2`,`blr`.`accnum3` AS `accnum3`,`blr`.`ag_type` AS `ag_type`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agency_details` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_funds_transfer_trans_view`
--

/*!50001 DROP VIEW IF EXISTS `report_funds_transfer_trans_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_funds_transfer_trans_view` AS select `av`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`av`.`IName` AS `INSTITUTION`,date_format(`ft`.`FTTRANTIME`,'%Y%m%d') AS `DATEVAL`,sum(`ft`.`FTAMOUNT`) AS `AMOUNT`,sum(`ft`.`FTCHARGE`) AS `CHARGES` from (`funds_transfer_transaction_view` `ft` join `account_view` `av`) where ((`ft`.`FTRESULTCODE` = '1') and (`ft`.`FTFROM` = `av`.`ACC_NUM`)) group by `av`.`INSTITUTION_ID`,`av`.`IName`,date_format(`ft`.`FTTRANTIME`,'%Y%m%d') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mail_mesg_view`
--

/*!50001 DROP VIEW IF EXISTS `mail_mesg_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mail_mesg_view` AS select `mm`.`Id` AS `Id`,`mm`.`MFROMADDR` AS `MFROMADDR`,`mm`.`MTOADDR` AS `MTOADDR`,`mm`.`MCCADDR` AS `MCCADDR`,`mm`.`MSUBJECT` AS `MSUBJECT`,`mm`.`MMESSAGE` AS `MMESSAGE`,`mm`.`MRETRYCNT` AS `MRETRYCNT`,`mm`.`MESGQIN` AS `MESGQIN`,`mm`.`MESGQOUT` AS `MESGQOUT`,`mm`.`MESGQERR` AS `MESGQERR`,`mm`.`RSTATUS` AS `RSTATUS`,`mm`.`CREATED_BY` AS `CREATED_BY`,`mm`.`CREATED_AT` AS `CREATED_AT`,`mm`.`MODIFIED_AT` AS `MODIFIED_AT`,`mm`.`MODIFIED_BY` AS `MODIFIED_BY`,`mm`.`NEXT_ATTEMPT` AS `NEXT_ATTEMPT`,`mm`.`LAST_ATTEMPT` AS `LAST_ATTEMPT`,`mm`.`SCHEDULE_TS` AS `SCHEDULE_TS`,`mm`.`EXEC_AG_CODE` AS `EXEC_AG_CODE`,`cm`.`CCODE` AS `CCODE` from (`mail_mesg` `mm` join `content_map` `cm`) where ((`cm`.`CTYPE` = 'MESG_COMMN_CODE') and (`mm`.`RSTATUS` = `cm`.`CVALUE`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `paybill_view`
--

/*!50001 DROP VIEW IF EXISTS `paybill_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `paybill_view` AS (select `blr`.`Id` AS `Id`,`blr`.`PB_TYPE` AS `PB_TYPE`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`ACC_NAME` AS `ACC_NAME`,`blr`.`CIF` AS `CIF`,`blr`.`PB_DESC` AS `PB_DESC`,`blr`.`PB_CODE` AS `PB_CODE`,`blr`.`PB_VAL` AS `PB_VAL`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`EXTN6` AS `EXTN6`,`blr`.`EXTN7` AS `EXTN7`,`blr`.`EXTN8` AS `EXTN8`,`blr`.`EXTN9` AS `EXTN9`,`blr`.`EXTN10` AS `EXTN10`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`paybill` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_audit_log`
--

/*!50001 DROP VIEW IF EXISTS `report_audit_log`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_audit_log` AS select `c`.`Id` AS `Id`,`c`.`ENTITY_NAME` AS `ENTITY_NAME`,`c`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`c`.`MESSAGE` AS `MESSAGE`,`c`.`ACTION_TYPE` AS `ACTION_TYPE`,`c`.`USER_ID` AS `USER_ID`,`c`.`CREATED_BY` AS `CREATED_BY`,`c`.`CREATED_AT` AS `CREATED_AT`,`c`.`MODIFIED_AT` AS `MODIFIED_AT`,`c`.`MODIFIED_BY` AS `MODIFIED_BY`,date_format(`c`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `audit_log` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_mpesa_to_account`
--

/*!50001 DROP VIEW IF EXISTS `report_mpesa_to_account`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_mpesa_to_account` AS select `mpesa_tran`.`TSTAMP` AS `CREATED_AT`,`mpesa_tran`.`MPSENDER` AS `CUSTOMER_ID`,`mpesa_tran`.`DEST` AS `CUST_MOBILE`,`mpesa_tran`.`MPACC` AS `FROM_ACCOUNT`,`mpesa_tran`.`ORIG` AS `FT_TYPE`,`mpesa_tran`.`MPCODE` AS `REF_NO`,`mpesa_tran`.`MPTAMT` AS `AMOUNT`,`mpesa_tran`.`RSTATUS` AS `RSTATUS`,`mpesa_tran`.`BANKCHRGRESULT` AS `CUST_REF2`,`mpesa_tran`.`BANKCHRGTS` AS `ISO_REF_NO`,`mpesa_tran`.`BANKCHRGRESULT_CODE` AS `ISO_RSTATUS`,date_format(`mpesa_tran`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `mpesa_tran` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `nfc_category_view`
--

/*!50001 DROP VIEW IF EXISTS `nfc_category_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `nfc_category_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CATEGORY_CODE` AS `CATEGORY_CODE`,`blr`.`CATEGORY_NAME` AS `CATEGORY_NAME`,`blr`.`CURR_PRICE` AS `CURR_PRICE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`nfc_category` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_mobile_feature_usage_statistics_view`
--

/*!50001 DROP VIEW IF EXISTS `report_mobile_feature_usage_statistics_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_mobile_feature_usage_statistics_view` AS select `mobile_access_log_view`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`mobile_access_log_view`.`INAME` AS `INSTITUTION`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d') AS `DATEVAL`,`mobile_access_log_view`.`ACTION_MESG` AS `ACTION_MESG`,count(0) AS `COUNT` from `mobile_access_log_view` group by `mobile_access_log_view`.`INSTITUTION_ID`,`mobile_access_log_view`.`INAME`,date_format(`mobile_access_log_view`.`LASTACC`,'%Y%m%d'),`mobile_access_log_view`.`ACTION_MESG` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customers_sms_alert`
--

/*!50001 DROP VIEW IF EXISTS `report_customers_sms_alert`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customers_sms_alert` AS select `customer`.`cname` AS `cname`,`customer`.`VAL_ACC` AS `val_acc`,substr(`customer`.`VAL_ACC`,2,3) AS `branch`,`customer`.`NATIONAL_ID` AS `national_id`,`customer`.`MOBILE` AS `mobile`,`customer`.`EMAIL` AS `email`,`customer`.`CUST_EXTN3` AS `cust_extn3`,`customer`.`CUST_EXTN2` AS `cust_extn2`,date_format(`customer`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `customer` where (`customer`.`CUST_EXTN1` = 'Y') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bulk_payment_approvercr_view`
--

/*!50001 DROP VIEW IF EXISTS `bulk_payment_approvercr_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bulk_payment_approvercr_view` AS (select `blr`.`Id` AS `Id`,`blr`.`ORIG_REC_ID` AS `ORIG_REC_ID`,`blr`.`ACC_NUM` AS `ACC_NUM`,`blr`.`REG_CUST_ID` AS `REG_CUST_ID`,`blr`.`REG_CUST_NAME` AS `REG_CUST_NAME`,`blr`.`ALIAS` AS `ALIAS`,`blr`.`CUST_ID` AS `CUST_ID`,`blr`.`CUST_NAME` AS `CUST_NAME`,`blr`.`MANDATORY` AS `MANDATORY`,`blr`.`ROLE_CODE` AS `ROLE_CODE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`OTP_GEN` AS `OTP_GEN`,`blr`.`OTP_EXP` AS `OTP_EXP`,`blr`.`max_approval_amount` AS `max_approval_amount`,`blr`.`SEQ_CODE` AS `SEQ_CODE`,`blr`.`CATEG_CODE` AS `CATEG_CODE`,`blr`.`UPDATE_STAT` AS `UPDATE_STAT`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`bulk_payment_approvercr` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sweep_order_view`
--

/*!50001 DROP VIEW IF EXISTS `sweep_order_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sweep_order_view` AS (select `blr`.`Id` AS `Id`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`REQ_CNAME` AS `REQ_CNAME`,`blr`.`REQ_SOURCE` AS `REQ_SOURCE`,`blr`.`SWEEP_NAME` AS `SWEEP_NAME`,`blr`.`SWEEP_TYPE` AS `SWEEP_TYPE`,`blr`.`FROMACC` AS `FROMACC`,`blr`.`TOACC` AS `TOACC`,`blr`.`AMOUNT` AS `AMOUNT`,`blr`.`FT_REMARKS` AS `FT_REMARKS`,`blr`.`SWEEP_STATUS` AS `SWEEP_STATUS`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`BankBranchCode` AS `BankBranchCode`,`blr`.`BEN_NAME` AS `BEN_NAME`,`blr`.`PAY_DESC` AS `PAY_DESC`,`blr`.`BANK_SWIFT_CODE` AS `BANK_SWIFT_CODE`,`blr`.`BEN_DTL1` AS `BEN_DTL1`,`blr`.`BEN_DTL2` AS `BEN_DTL2`,`blr`.`BEN_DTL3` AS `BEN_DTL3`,`blr`.`BANK_CODE` AS `BANK_CODE`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`BEN_TYPE` AS `BEN_TYPE`,`blr`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`blr`.`SWEEP_FREQ` AS `SWEEP_FREQ`,`blr`.`SWEEP_STARTTS` AS `SWEEP_STARTTS`,`blr`.`SWEEP_FINISHTS` AS `SWEEP_FINISHTS`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`sweep_order` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agency_info_view`
--

/*!50001 DROP VIEW IF EXISTS `agency_info_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agency_info_view` AS (select `blr`.`Id` AS `Id`,`blr`.`REF_CUST_REC_ID` AS `REF_CUST_REC_ID`,`blr`.`REF_CUST_CIF` AS `REF_CUST_CIF`,`blr`.`REF_CUST_MOBILE` AS `REF_CUST_MOBILE`,`blr`.`REF_CUST_NAME` AS `REF_CUST_NAME`,`blr`.`DOMIBRNCH` AS `DOMIBRNCH`,`blr`.`NATIONALTY` AS `NATIONALTY`,`blr`.`PROFCONT1` AS `PROFCONT1`,`blr`.`PROFCONT2` AS `PROFCONT2`,`blr`.`SERVPK` AS `SERVPK`,`blr`.`BRNCHCODE` AS `BRNCHCODE`,`blr`.`PROFPROV` AS `PROFPROV`,`blr`.`PROFAGCODE` AS `PROFAGCODE`,`blr`.`TRDNAME` AS `TRDNAME`,`blr`.`PSTADDR` AS `PSTADDR`,`blr`.`LRNUM` AS `LRNUM`,`blr`.`PSTCITY` AS `PSTCITY`,`blr`.`PSTZIP` AS `PSTZIP`,`blr`.`BUSLOC` AS `BUSLOC`,`blr`.`PHYADDR` AS `PHYADDR`,`blr`.`BUSSTAT` AS `BUSSTAT`,`blr`.`BUSNAME` AS `BUSNAME`,`blr`.`BUSDESIG` AS `BUSDESIG`,`blr`.`BUSNATIONALITY` AS `BUSNATIONALITY`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`SUB_AGENCY` AS `SUB_AGENCY`,`blr`.`MAST_AGCODE` AS `MAST_AGCODE`,`blr`.`MERORAG` AS `MERORAG`,`blr`.`served_by` AS `served_by`,`blr`.`safoutcode` AS `safoutcode`,`blr`.`airoutcode` AS `airoutcode`,`blr`.`agextn1` AS `agextn1`,`blr`.`agextn2` AS `agextn2`,`blr`.`agextn3` AS `agextn3`,`blr`.`agextn4` AS `agextn4`,`blr`.`agextn5` AS `agextn5`,`blr`.`cb_min_amt` AS `cb_min_amt`,`blr`.`cb_max_amt` AS `cb_max_amt`,`blr`.`serv_comm` AS `serv_comm`,`blr`.`merpayurl` AS `merpayurl`,`blr`.`agextn6` AS `agextn6`,`blr`.`agextn7` AS `agextn7`,`blr`.`agextn8` AS `agextn8`,`blr`.`agextn9` AS `agextn9`,`blr`.`agextn10` AS `agextn10`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agency_info` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agent_details_view`
--

/*!50001 DROP VIEW IF EXISTS `agent_details_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agent_details_view` AS select `account`.`ACC_NUM` AS `ACC_NUM`,`account`.`CUST_ID` AS `CUST_ID`,`account`.`ALIAS` AS `ALIAS`,date_format(`account`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `account` where (`account`.`ALIAS` like 'Agent%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `agent_requests_view`
--

/*!50001 DROP VIEW IF EXISTS `agent_requests_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `agent_requests_view` AS (select `blr`.`Id` AS `Id`,`blr`.`REQ_CIF` AS `REQ_CIF`,`blr`.`REQ_MOB` AS `REQ_MOB`,`blr`.`REQ_NAME` AS `REQ_NAME`,`blr`.`req_type` AS `REQ_TYPE`,`blr`.`COMMENTS` AS `COMMENTS`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`EXTN3` AS `EXTN3`,`blr`.`EXTN4` AS `EXTN4`,`blr`.`EXTN5` AS `EXTN5`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`agent_requests` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sms_stat_view`
--

/*!50001 DROP VIEW IF EXISTS `sms_stat_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sms_stat_view` AS select date_format(`mm`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL`,`mm`.`RSTATUS` AS `status`,count(0) AS `cnt` from `sms_mesg` `mm` group by date_format(`mm`.`CREATED_AT`,'%Y%m%d'),`mm`.`RSTATUS` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `chama_master_view`
--

/*!50001 DROP VIEW IF EXISTS `chama_master_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `chama_master_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CHAMA_ACC_NUM` AS `CHAMA_ACC_NUM`,`blr`.`CHAMA_TITLE` AS `CHAMA_TITLE`,`blr`.`CHAMA_ALIAS` AS `CHAMA_ALIAS`,`blr`.`CHAMA_OTHER_INFO` AS `CHAMA_OTHER_INFO`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`blr`.`EXTN1` AS `EXTN1`,`blr`.`EXTN2` AS `EXTN2`,`blr`.`primar_cif` AS `primar_cif`,`blr`.`primar_mob` AS `primar_mob`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`chama_master` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cust_req_audit_view`
--

/*!50001 DROP VIEW IF EXISTS `cust_req_audit_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cust_req_audit_view` AS (select `blr`.`Id` AS `Id`,`blr`.`CIF` AS `CIF`,`blr`.`REQ_TYPE` AS `REQ_TYPE`,`blr`.`REQ_CONTENT` AS `REQ_CONTENT`,`blr`.`REQ_STATUS` AS `REQ_STATUS`,`blr`.`REQ_AT` AS `REQ_AT`,`blr`.`REQ_SOURCE` AS `REQ_SOURCE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`cust_req_audit` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `standing_order_view`
--

/*!50001 DROP VIEW IF EXISTS `standing_order_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `standing_order_view` AS (select `atp`.`Id` AS `Id`,`atp`.`PAYER_CODE` AS `PAYER_CODE`,`atp`.`FROMACC` AS `FROMACC`,`atp`.`TOACC` AS `TOACC`,`atp`.`AMOUNT` AS `AMOUNT`,`atp`.`FREQUENCY` AS `FREQUENCY`,`atp`.`FT_REMARKS` AS `FT_REMARKS`,`atp`.`FT_TRIGGERTS` AS `FT_TRIGGERTS`,`atp`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atp`.`MADE_BY` AS `MADE_BY`,`atp`.`MADE_AT` AS `MADE_AT`,`atp`.`CHECKED_BY` AS `CHECKED_BY`,`atp`.`CHECKED_AT` AS `CHECKED_AT`,`atp`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atp`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atp`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atp`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atp`.`RSTATUS` AS `RSTATUS`,`atp`.`CREATED_BY` AS `CREATED_BY`,`atp`.`CREATED_AT` AS `CREATED_AT`,`atp`.`MODIFIED_AT` AS `MODIFIED_AT`,`atp`.`MODIFIED_BY` AS `MODIFIED_BY`,`atp`.`BENE_RECORD_ID` AS `BENE_RECORD_ID`,`atp`.`BPCATEGORY1` AS `BPCATEGORY1`,`atp`.`BPCATEGORY2` AS `BPCATEGORY2`,`atp`.`EXPIRE_AFTER` AS `EXPIRE_AFTER`,`atp`.`ORDER_NAME` AS `ORDER_NAME`,`atp`.`ORIG_CUST_ID` AS `ORIG_CUST_ID`,`atp`.`ORIG_CUST_NAME` AS `ORIG_CUST_NAME`,`atp`.`ORIG_CUST_MOBILE` AS `ORIG_CUST_MOBILE`,`atp`.`ORIG_CUST_GROUP` AS `ORIG_CUST_GROUP`,`atp`.`BankBranchCode` AS `BankBranchCode`,`atp`.`BEN_NAME` AS `BEN_NAME`,`atp`.`PAY_DESC` AS `PAY_DESC`,`atp`.`BANK_SWIFT_CODE` AS `BANK_SWIFT_CODE`,`atp`.`BEN_DTL1` AS `BEN_DTL1`,`atp`.`BEN_DTL2` AS `BEN_DTL2`,`atp`.`BEN_DTL3` AS `BEN_DTL3`,`atp`.`BANK_CODE` AS `BANK_CODE`,`atp`.`BRANCH_CODE` AS `BRANCH_CODE`,`atp`.`BENE_TYPE` AS `BENE_TYPE`,`atp`.`REQ_CIF` AS `REQ_CIF`,`atp`.`REQ_CNAME` AS `REQ_CNAME`,`atp`.`BATCH_CODE` AS `BATCH_CODE`,`atp`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`atp`.`PSTATUS` AS `PSTATUS`,`atp`.`SERVICE_TITLE` AS `SERVICE_TITLE`,`atp`.`SERVICE_CODE` AS `SERVICE_CODE`,`atp`.`SERVICE_RESULT` AS `SERVICE_RESULT`,`atp`.`DISP_STAT` AS `DISP_STAT`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`standing_order` `atp` left join `institution` `inst` on((`atp`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atp`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atp`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `goods_list_view`
--

/*!50001 DROP VIEW IF EXISTS `goods_list_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `goods_list_view` AS (select `blr`.`Id` AS `Id`,`blr`.`GOODS_CAT` AS `GOODS_CAT`,`blr`.`GOODS_NAME` AS `GOODS_NAME`,`blr`.`GOODS_COST` AS `GOODS_COST`,`blr`.`GOODS_TYPE` AS `GOODS_TYPE`,`blr`.`GOODS_DESC` AS `GOODS_DESC`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`goods_list` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ef_charge_tran_view`
--

/*!50001 DROP VIEW IF EXISTS `ef_charge_tran_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ef_charge_tran_view` AS (select `er`.`Id` AS `Id`,`er`.`CARD_NO` AS `CARD_NO`,`er`.`CARD_NAME` AS `CARD_NAME`,`er`.`CARD_EXPMON` AS `CARD_EXPMON`,`er`.`CARD_EXPYR` AS `CARD_EXPYR`,`er`.`CARD_CVV` AS `CARD_CVV`,`er`.`CARD_TYPE` AS `CARD_TYPE`,`er`.`WALLET_ACC` AS `WALLET_ACC`,`er`.`AMOUNT` AS `AMOUNT`,`er`.`CIF` AS `CIF`,`er`.`CNAME` AS `CNAME`,`er`.`CURRENCY` AS `CURRENCY`,`er`.`TRAN_DESC` AS `TRAN_DESC`,`er`.`TRAN_RESULT_CODE` AS `TRAN_RESULT_CODE`,`er`.`TRAN_RESULT_DESC` AS `TRAN_RESULT_DESC`,`er`.`MADE_BY` AS `MADE_BY`,`er`.`MADE_AT` AS `MADE_AT`,`er`.`CHECKED_BY` AS `CHECKED_BY`,`er`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`er`.`CHECKED_AT` AS `CHECKED_AT`,`er`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`er`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`er`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`er`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`er`.`RSTATUS` AS `RSTATUS`,`er`.`CREATED_BY` AS `CREATED_BY`,`er`.`CREATED_AT` AS `CREATED_AT`,`er`.`MODIFIED_AT` AS `MODIFIED_AT`,`er`.`MODIFIED_BY` AS `MODIFIED_BY`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`ef_charge_tran` `er` left join `institution` `inst` on((`er`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`er`.`RSTATUS` = `sc`.`STATUS_ID`) and (`er`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `interest_type_range_view`
--

/*!50001 DROP VIEW IF EXISTS `interest_type_range_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `interest_type_range_view` AS (select `ctr`.`Id` AS `Id`,`ctr`.`INTEREST_TYPE_ID` AS `INTEREST_TYPE_ID`,`ctr`.`SERVICE_ID` AS `SERVICE_ID`,`ctr`.`RANGE_FROM` AS `RANGE_FROM`,`ctr`.`RANGE_TO` AS `RANGE_TO`,`ctr`.`INTEREST_TYPE_CODE` AS `INTEREST_TYPE_CODE`,`ctr`.`INTEREST_VALUE` AS `INTEREST_VALUE`,`ctr`.`INTEREST_VALUE2` AS `INTEREST_VALUE2`,`ctr`.`INTEREST_VALUE3` AS `INTEREST_VALUE3`,`ctr`.`MADE_BY` AS `MADE_BY`,`ctr`.`MADE_AT` AS `MADE_AT`,`ctr`.`CHECKED_BY` AS `CHECKED_BY`,`ctr`.`CHECKED_AT` AS `CHECKED_AT`,`ctr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`ctr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`ctr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`ctr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`ctr`.`RSTATUS` AS `RSTATUS`,`ctr`.`CREATED_BY` AS `CREATED_BY`,`ctr`.`CREATED_AT` AS `CREATED_AT`,`ctr`.`MODIFIED_AT` AS `MODIFIED_AT`,`ctr`.`MODIFIED_BY` AS `MODIFIED_BY`,`ctr`.`ARCHIVED_AT` AS `ARCHIVED_AT`,`ctr`.`ARCHIVED_BY` AS `ARCHIVED_BY`,`ctr`.`CURRENCY_CODE` AS `CURRENCY_CODE`,`ccv`.`CATEGORY` AS `CHARGE_TYPE`,`ccv`.`IName` AS `INAME`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`ms`.`SERVICE_CODE` AS `SERVICE_CODE`,`ms`.`SERVICE_NAME` AS `SERVICE_NAME` from ((((`interest_type_range` `ctr` join `customer_category_view` `ccv`) join `status_code` `sc`) join `status_code` `ascd`) join `master_service` `ms`) where ((`ctr`.`INTEREST_TYPE_ID` = `ccv`.`Id`) and (`ctr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`ctr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`ctr`.`SERVICE_ID` = `ms`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `report_customers_mobile_banking`
--

/*!50001 DROP VIEW IF EXISTS `report_customers_mobile_banking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `report_customers_mobile_banking` AS select `customer`.`cname` AS `cname`,`customer`.`VAL_ACC` AS `val_acc`,substr(`customer`.`VAL_ACC`,2,3) AS `branch`,`customer`.`NATIONAL_ID` AS `national_id`,`customer`.`MOBILE` AS `mobile`,`customer`.`EMAIL` AS `email`,date_format(`customer`.`CREATED_AT`,'%Y%m%d') AS `DATEVAL` from `customer` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cbcustomer_view`
--

/*!50001 DROP VIEW IF EXISTS `cbcustomer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cbcustomer_view` AS (select `cu`.`Id` AS `Id`,`cu`.`CIF` AS `CIF`,`cu`.`cname` AS `CNAME`,`cu`.`VAL_ACC` AS `VAL_ACC`,`cu`.`NATIONAL_ID` AS `NATIONAL_ID`,`cu`.`PASSPORT` AS `PASSPORT`,`cu`.`NATIONALITY` AS `NATIONALITY`,`cu`.`MOBILE` AS `MOBILE`,`cu`.`EMAIL` AS `EMAIL`,`cu`.`ID_SUBMITTED` AS `ID_SUBMITTED`,`cu`.`ID_VERIFIED` AS `ID_VERIFIED`,`cu`.`PIN_NO` AS `PIN_NO`,`cu`.`TERMS_SIGNED` AS `TERMS_SIGNED`,`cu`.`UG_ISSUED` AS `UG_ISSUED`,`cu`.`PREF_LANG` AS `PREF_LANG`,`cu`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`cu`.`MADE_BY` AS `MADE_BY`,`cu`.`MADE_AT` AS `MADE_AT`,`cu`.`CHECKED_BY` AS `CHECKED_BY`,`cu`.`CHECKED_AT` AS `CHECKED_AT`,`cu`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`cu`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`cu`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`cu`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`cu`.`RSTATUS` AS `RSTATUS`,`cu`.`CREATED_BY` AS `CREATED_BY`,`cu`.`CREATED_AT` AS `CREATED_AT`,`cu`.`MODIFIED_AT` AS `MODIFIED_AT`,`cu`.`MODIFIED_BY` AS `MODIFIED_BY`,`cu`.`BLOCKED_FLAG` AS `BLOCKED_FLAG`,`cu`.`CUST_CAT` AS `CUST_CAT`,`cu`.`ALLOWED_PHONE_TYPE1` AS `ALLOWED_PHONE_TYPE1`,`cu`.`ALLOWED_PHONE_TYPE2` AS `ALLOWED_PHONE_TYPE2`,`cu`.`ALLOWED_PHONE_TYPE3` AS `ALLOWED_PHONE_TYPE3`,`cu`.`ALLOWED_PHONE_ID1` AS `ALLOWED_PHONE_ID1`,`cu`.`ALLOWED_PHONE_ID2` AS `ALLOWED_PHONE_ID2`,`cu`.`ALLOWED_PHONE_ID3` AS `ALLOWED_PHONE_ID3`,`cu`.`TPIN_NO` AS `TPIN_NO`,`cu`.`AUTH_FAIL_PIN` AS `AUTH_FAIL_PIN`,`cu`.`AUTH_FAIL_TPIN` AS `AUTH_FAIL_TPIN`,`cu`.`REPORT_FREQ` AS `REPORT_FREQ`,`cu`.`CUST_EXTN1` AS `CUST_EXTN1`,`cu`.`CUST_EXTN2` AS `CUST_EXTN2`,`cu`.`CUST_EXTN3` AS `CUST_EXTN3`,`cu`.`CUST_EXTN4` AS `CUST_EXTN4`,`cu`.`INITIAL_MPIN` AS `INITIAL_MPIN`,`cu`.`INITIAL_TPIN` AS `INITIAL_TPIN`,`cu`.`EMAIL_ALERT_TYPE` AS `EMAIL_ALERT_TYPE`,`cu`.`SMS_ALERT_TYPE` AS `SMS_ALERT_TYPE`,`cu`.`ADDTNL_MAIL1` AS `ADDTNL_MAIL1`,`cu`.`ADDTNL_MAIL2` AS `ADDTNL_MAIL2`,`cu`.`ADDTNL_MAIL3` AS `ADDTNL_MAIL3`,`cu`.`ADDTNL_MAIL4` AS `ADDTNL_MAIL4`,`cu`.`ADDTNL_MAIL5` AS `ADDTNL_MAIL5`,`cu`.`CUSEXTN11` AS `CUSEXTN11`,`cu`.`CUSEXTN12` AS `CUSEXTN12`,`cu`.`CUSEXTN13` AS `CUSEXTN13`,`cu`.`CUSEXTN14` AS `CUSEXTN14`,`cu`.`CUSEXTN15` AS `CUSEXTN15`,`cu`.`MPIN_FLDATTMPT` AS `MPIN_FLDATTMPT`,`cu`.`LAST_ATTMPTSRC` AS `LAST_ATTMPTSRC`,`cu`.`LAST_ATTMPTVER` AS `LAST_ATTMPTVER`,`cu`.`UNLOCK_TIME` AS `UNLOCK_TIME`,`cu`.`MOBILE_ACCESS` AS `MOBILE_ACCESS`,`cu`.`VIRTUAL_AGENCY` AS `VIRTUAL_AGENCY`,`cu`.`VIRTUAL_AGENCY_ACC` AS `VIRTUAL_AGENCY_ACC`,`cu`.`AGENCY_ID` AS `AGENCY_ID`,`cu`.`VIRTUAL_CUSTOMER` AS `VIRTUAL_CUSTOMER`,`cu`.`CA_APP_ACCESS` AS `CA_APP_ACCESS`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,`cc`.`CATEGORY` AS `CATEGORY` from ((((`customer` `cu` left join `institution` `inst` on((`cu`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) join `customer_category` `cc`) where ((`cu`.`RSTATUS` = `sc`.`STATUS_ID`) and (`cu`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`) and (`cu`.`CUST_CAT` = `cc`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `joint_acc_pend_app_view`
--

/*!50001 DROP VIEW IF EXISTS `joint_acc_pend_app_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `joint_acc_pend_app_view` AS select distinct `joint_account_approvals`.`FT_TRAN_ID` AS `ft_tran_id`,`joint_account_approvals`.`FT_FROM` AS `ft_from`,count(0) AS `cnt`,max(`joint_account_approvals`.`NEXT_REM_TS`) AS `NEXT_REM_TS` from `joint_account_approvals` where (`joint_account_approvals`.`OVERALL_APPROVAL_STATUS` = 'Pending Other Approvals') group by `joint_account_approvals`.`FT_TRAN_ID`,`joint_account_approvals`.`FT_FROM` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_data_update1_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_data_update1_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_data_update1_view` AS (select `atb`.`Id` AS `Id`,`atb`.`ALLOWED_PHONE_ID1` AS `ALLOWED_PHONE_ID1`,`atb`.`ALLOWED_PHONE_ID2` AS `ALLOWED_PHONE_ID2`,`atb`.`CUST_RECORD_ID` AS `CUST_RECORD_ID`,`atb`.`CIF` AS `CIF`,`atb`.`CNAME` AS `CNAME`,`atb`.`NATIONAL_ID` AS `NATIONAL_ID`,`atb`.`PASSPORT` AS `PASSPORT`,`atb`.`NATIONALITY` AS `NATIONALITY`,`atb`.`MOBILE` AS `MOBILE`,`atb`.`EMAIL` AS `EMAIL`,`atb`.`PREF_LANG` AS `PREF_LANG`,`atb`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`atb`.`MADE_BY` AS `MADE_BY`,`atb`.`MADE_AT` AS `MADE_AT`,`atb`.`CHECKED_BY` AS `CHECKED_BY`,`atb`.`CHECKED_AT` AS `CHECKED_AT`,`atb`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`atb`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`atb`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`atb`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`atb`.`RSTATUS` AS `RSTATUS`,`atb`.`CREATED_BY` AS `CREATED_BY`,`atb`.`CREATED_AT` AS `CREATED_AT`,`atb`.`MODIFIED_AT` AS `MODIFIED_AT`,`atb`.`MODIFIED_BY` AS `MODIFIED_BY`,`atb`.`CUST_CAT` AS `CUST_CAT`,`atb`.`IB_SQ1` AS `IB_SQ1`,`atb`.`IB_SQ2` AS `IB_SQ2`,`atb`.`IB_SQ3` AS `IB_SQ3`,`atb`.`IB_SQ4` AS `IB_SQ4`,`atb`.`IB_SQ5` AS `IB_SQ5`,`atb`.`IB_SA1` AS `IB_SA1`,`atb`.`IB_SA2` AS `IB_SA2`,`atb`.`IB_SA3` AS `IB_SA3`,`atb`.`IB_SA4` AS `IB_SA4`,`atb`.`IB_SA5` AS `IB_SA5`,`atb`.`ORIG_MOBILE` AS `ORIG_MOBILE`,`atb`.`EXTN1` AS `EXTN1`,`atb`.`EXTN2` AS `EXTN2`,`atb`.`EXTN3` AS `EXTN3`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`customer_data_update` `atb` left join `institution` `inst` on((`atb`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`atb`.`RSTATUS` = `sc`.`STATUS_ID`) and (`atb`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `biller_type_view`
--

/*!50001 DROP VIEW IF EXISTS `biller_type_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `biller_type_view` AS (select `blr`.`Id` AS `Id`,`blr`.`BILLER_CODE` AS `BILLER_CODE`,`blr`.`BILLER_ACNO` AS `BILLER_ACNO`,`blr`.`BILLER_TYPE` AS `BILLER_TYPE`,`blr`.`INSTITUTION_ID` AS `INSTITUTION_ID`,`blr`.`MADE_BY` AS `MADE_BY`,`blr`.`MADE_AT` AS `MADE_AT`,`blr`.`CHECKED_BY` AS `CHECKED_BY`,`blr`.`CHECKED_AT` AS `CHECKED_AT`,`blr`.`MAKER_LAST_CMT` AS `MAKER_LAST_CMT`,`blr`.`CHECKER_LAST_CMT` AS `CHECKER_LAST_CMT`,`blr`.`CURR_APP_STATUS` AS `CURR_APP_STATUS`,`blr`.`ADMIN_LAST_CMT` AS `ADMIN_LAST_CMT`,`blr`.`RSTATUS` AS `RSTATUS`,`blr`.`CREATED_BY` AS `CREATED_BY`,`blr`.`CREATED_AT` AS `CREATED_AT`,`blr`.`MODIFIED_AT` AS `MODIFIED_AT`,`blr`.`MODIFIED_BY` AS `MODIFIED_BY`,`blr`.`FLD1NAME` AS `FLD1NAME`,`blr`.`FLD2NAME` AS `FLD2NAME`,`blr`.`FLD3NAME` AS `FLD3NAME`,`blr`.`FLD4NAME` AS `FLD4NAME`,`blr`.`FLD5NAME` AS `FLD5NAME`,`blr`.`FLD1CODE` AS `FLD1CODE`,`blr`.`FLD2CODE` AS `FLD2CODE`,`blr`.`FLD3CODE` AS `FLD3CODE`,`blr`.`FLD4CODE` AS `FLD4CODE`,`blr`.`FLD5CODE` AS `FLD5CODE`,`blr`.`FLD1TYPE` AS `FLD1TYPE`,`blr`.`FLD2TYPE` AS `FLD2TYPE`,`blr`.`FLD3TYPE` AS `FLD3TYPE`,`blr`.`FLD4TYPE` AS `FLD4TYPE`,`blr`.`FLD5TYPE` AS `FLD5TYPE`,`blr`.`MIN_TRAN_AMT` AS `MIN_TRAN_AMT`,`blr`.`MAX_TRAN_AMT` AS `MAX_TRAN_AMT`,`blr`.`DLY_TRAN_AMT` AS `DLY_TRAN_AMT`,`blr`.`BRANCH_CODE` AS `BRANCH_CODE`,`blr`.`CURR_CODE` AS `CURR_CODE`,`blr`.`PAY_TYPE` AS `PAY_TYPE`,`sc`.`STATUS_NAME` AS `STATUS_NAME`,`ascd`.`STATUS_NAME` AS `CURR_APP_STATUS_NAME`,concat(`inst`.`INAME`,'-',`inst`.`ILOCATION`) AS `IName` from (((`biller_type` `blr` left join `institution` `inst` on((`blr`.`INSTITUTION_ID` = `inst`.`Id`))) join `status_code` `sc`) join `status_code` `ascd`) where ((`blr`.`RSTATUS` = `sc`.`STATUS_ID`) and (`blr`.`CURR_APP_STATUS` = `ascd`.`STATUS_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rep_customer_crea_history`
--

/*!50001 DROP VIEW IF EXISTS `rep_customer_crea_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rep_customer_crea_history` AS select `c`.`cname` AS `CUST_NAME`,`c`.`MOBILE` AS `CUST_MOB`,`c`.`VAL_ACC` AS `CUST_AC`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`MADE_BY`)) AS `CREATED_BY`,`c`.`MADE_AT` AS `CREATED_AT`,(select `system_user`.`USER_ID` from `system_user` where (`system_user`.`Id` = `c`.`CHECKED_BY`)) AS `CHECKED_BY`,`c`.`CHECKED_AT` AS `CHECKED_AT`,date_format(`c`.`MADE_AT`,'%Y%m%d') AS `DATEVAL` from `customer` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:35:17
