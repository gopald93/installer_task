drop procedure IF EXISTS sp_create_institute;
DELIMITER $$
CREATE PROCEDURE sp_create_institute (IN in_id int,IN in_iname varchar(200),IN in_location varchar(1000))
BEGIN
    INSERT INTO `institution` (`Id`,`INAME`,`ILOCATION`,`MADE_BY`,`MADE_AT`,`CHECKED_BY`,`CHECKED_AT`,`MAKER_LAST_CMT`,`CHECKER_LAST_CMT`,`CURR_APP_STATUS`,`ADMIN_LAST_CMT`,`RSTATUS`,`CREATED_BY`,`CREATED_AT`,`MODIFIED_AT`,`MODIFIED_BY`,`INSTITUTION_ID`) VALUES 
    (in_id,in_iname,in_location,3,NULL,NULL,NULL,NULL,NULL,-1,NULL,-1,3,now(),now(),1,NULL);
    commit;
END;
$$
DELIMITER ;

