DROP PROCEDURE IF EXISTS sp_add_langauge;
DELIMITER $$
CREATE PROCEDURE sp_add_langauge (IN in_lang varchar(255),IN in_institute varchar(100))
BEGIN
DECLARE _next TEXT DEFAULT NULL;
DECLARE _nextlen TEXT DEFAULT NULL;
-- Input parameter converted to lower case for comparision;
SET in_lang=LOWER(in_lang);

iterator:
LOOP
-- exit the loop if the list seems empty or was null;
-- this is necessary to avoid an endless loop in the proc.
  IF LENGTH(TRIM(in_lang)) = 0 OR in_lang IS NULL THEN
    LEAVE iterator;
  END IF;
  -- capture the next value from the list
  SET _next = SUBSTRING_INDEX(in_lang,',',1);
  -- save the length of the captured value; we will need to remove this
  -- many characters + 1 from the beginning of the string 
  -- before the next iteration
  SET _nextlen = LENGTH(_next);
	IF _next = "english" THEN
		INSERT INTO `language` (`EXTN1`,`EXTN2`,`EXTN3`,`base`,`enabled`,`locale`,`name`,`rtl`,`unicode`,`status`,`CREATED_BY`,`CREATED_AT`,`MODIFIED_AT`,`MODIFIED_BY`,`INSTITUTION_ID`) VALUES (NULL,NULL,NULL,1,1,'en_US','English',1,NULL,1,NULL,NULL,now(),100,in_institute);
		commit;
	ELSEIF _next = "swahili" THEN
		INSERT INTO `language` (`EXTN1`,`EXTN2`,`EXTN3`,`base`,`enabled`,`locale`,`name`,`rtl`,`unicode`,`status`,`CREATED_BY`,`CREATED_AT`,`MODIFIED_AT`,`MODIFIED_BY`,`INSTITUTION_ID`) VALUES (NULL,NULL,NULL,1,1,'sw_KE','Swahili',1,NULL,1,NULL,NULL,now(),100,in_institute);
		commit;
	ELSEIF _next = "arabic" THEN
		INSERT INTO `language` (`EXTN1`,`EXTN2`,`EXTN3`,`base`,`enabled`,`locale`,`name`,`rtl`,`unicode`,`status`,`CREATED_BY`,`CREATED_AT`,`MODIFIED_AT`,`MODIFIED_BY`,`INSTITUTION_ID`) VALUES (NULL,NULL,NULL,1,1,'ar_SA','Arabic',1,NULL,1,NULL,NULL,now(),100,in_institute);
		commit;
	ELSE
		SELECT 'Langauge not supported.';
	END IF;
	-- rewrite the original string using the `INSERT()` string function,
	-- args are original string, start position, how many characters to remove, 
	-- and what to "insert" in their place (in this case, we "insert"
	-- an empty string, which removes _nextlen + 1 characters)
  SET in_lang = INSERT(in_lang,1,_nextlen + 1,'');
END LOOP;
END;
$$
DELIMITER ;
