-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_mpesapendingtransactions`
--

DROP TABLE IF EXISTS `t_mpesapendingtransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mpesapendingtransactions` (
  `ColumnID` int(11) NOT NULL AUTO_INCREMENT,
  `OurbranchID` varchar(15) NOT NULL,
  `AccountID` varchar(15) NOT NULL,
  `PhoneNumber` varchar(30) NOT NULL,
  `Amount` decimal(38,0) NOT NULL,
  `SerialID` varchar(30) NOT NULL,
  `DateAdded` datetime DEFAULT NULL,
  `DatePostedOn` datetime DEFAULT NULL,
  `TransactionPosted` int(11) DEFAULT NULL,
  `MPESAResult` varchar(2000) DEFAULT NULL,
  `FetchedStatus` int(11) DEFAULT NULL,
  `Reversed` int(11) DEFAULT NULL,
  `Reversedon` datetime DEFAULT NULL,
  `Provider` varchar(3) DEFAULT NULL,
  `Uploaded` int(11) DEFAULT NULL,
  `Authorized` int(11) DEFAULT NULL,
  `ReceiptNumber` varchar(20) DEFAULT NULL,
  `authorizedat` datetime DEFAULT NULL,
  PRIMARY KEY (`ColumnID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:32:51
