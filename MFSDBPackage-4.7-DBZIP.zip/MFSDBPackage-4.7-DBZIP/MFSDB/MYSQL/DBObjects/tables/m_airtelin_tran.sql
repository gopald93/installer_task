-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airtelin_tran`
--

DROP TABLE IF EXISTS `airtelin_tran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airtelin_tran` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `REF_NUM` varchar(50) DEFAULT NULL,
  `FROM_ACC` varchar(50) DEFAULT NULL,
  `TO_ACC` varchar(50) DEFAULT NULL,
  `AMT` varchar(25) DEFAULT NULL,
  `MOBILE` varchar(25) DEFAULT NULL,
  `TRANSTATUS` varchar(50) DEFAULT NULL,
  `TRANDATETIME` varchar(50) DEFAULT NULL,
  `RSTATUS` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_AT` datetime DEFAULT NULL,
  `MODIFIED_AT` datetime DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `MFREVACC` varchar(30) DEFAULT NULL,
  `MFREVAMT` varchar(40) DEFAULT NULL,
  `EXCACC` varchar(30) DEFAULT NULL,
  `EXCAMT` varchar(40) DEFAULT NULL,
  `EXTN1` varchar(30) DEFAULT NULL,
  `EXTN2` varchar(30) DEFAULT NULL,
  `EXTN3` varchar(30) DEFAULT NULL,
  `EXTN4` varchar(30) DEFAULT NULL,
  `EXTN5` varchar(100) DEFAULT NULL,
  `EXTN6` varchar(100) DEFAULT NULL,
  `EXTN7` varchar(100) DEFAULT NULL,
  `EXTN8` varchar(100) DEFAULT NULL,
  `EXTN9` varchar(100) DEFAULT NULL,
  `EXTN10` varchar(100) DEFAULT NULL,
  `arextn1` varchar(100) DEFAULT NULL,
  `arextn2` varchar(100) DEFAULT NULL,
  `arextn3` varchar(100) DEFAULT NULL,
  `arextn4` varchar(100) DEFAULT NULL,
  `arextn5` varchar(100) DEFAULT NULL,
  `arextn6` varchar(100) DEFAULT NULL,
  `arextn7` varchar(100) DEFAULT NULL,
  `arextn8` varchar(100) DEFAULT NULL,
  `arextn9` varchar(100) DEFAULT NULL,
  `arextn10` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:35:05
