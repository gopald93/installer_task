-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `joint_account_tran_master`
--

DROP TABLE IF EXISTS `joint_account_tran_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `joint_account_tran_master` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FT_FROM` varchar(100) DEFAULT NULL,
  `FT_TO` varchar(100) DEFAULT NULL,
  `FT_AMT` varchar(100) DEFAULT NULL,
  `FT_REMARKS` varchar(100) DEFAULT NULL,
  `REQ_ID` varchar(100) DEFAULT NULL,
  `REQ_NAME` varchar(100) DEFAULT NULL,
  `REQ_TS` varchar(100) DEFAULT NULL,
  `CURR_APP_LEVEL` varchar(100) DEFAULT NULL,
  `MANDATE_CNT` varchar(100) DEFAULT NULL,
  `CURR_APP_DONE` varchar(100) DEFAULT NULL,
  `OVERALL_APPROVAL_STATUS` varchar(100) DEFAULT NULL,
  `RSTATUS` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_AT` datetime DEFAULT NULL,
  `MODIFIED_AT` datetime DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `MOB_NUM` varchar(100) DEFAULT NULL,
  `ORIG_CIF` varchar(100) DEFAULT NULL,
  `BEN_MOB_NUM` varchar(100) DEFAULT NULL,
  `CHARGS` varchar(100) DEFAULT NULL,
  `PAYDESC` varchar(100) DEFAULT NULL,
  `BENBANKCODE` varchar(100) DEFAULT NULL,
  `BENBRNCHCODE` varchar(100) DEFAULT NULL,
  `BENBRNCHCURR` varchar(100) DEFAULT NULL,
  `BENNAME` varchar(100) DEFAULT NULL,
  `BENTYPE` varchar(100) DEFAULT NULL,
  `SERV_NAME` varchar(100) DEFAULT NULL,
  `FULL_MAP` varchar(3000) DEFAULT NULL,
  `SERVICE_ID` varchar(200) DEFAULT NULL,
  `SERVICE_CODE` varchar(200) DEFAULT NULL,
  `SERVICE_TITLE` varchar(200) DEFAULT NULL,
  `LAST_REM_TS` varchar(20) DEFAULT NULL,
  `NEXT_REM_TS` varchar(20) DEFAULT NULL,
  `MASTER_REQUEST` varchar(10) DEFAULT NULL,
  `INSTITUTION_ID` int(11) DEFAULT NULL,
  `MADE_BY` int(11) DEFAULT NULL,
  `MADE_AT` datetime DEFAULT NULL,
  `CHECKED_BY` int(11) DEFAULT NULL,
  `CHECKED_AT` datetime DEFAULT NULL,
  `MAKER_LAST_CMT` varchar(200) DEFAULT NULL,
  `CHECKER_LAST_CMT` varchar(200) DEFAULT NULL,
  `CURR_APP_STATUS` int(11) DEFAULT NULL,
  `ADMIN_LAST_CMT` varchar(200) DEFAULT NULL,
  `TRAN_RESULT` varchar(2000) DEFAULT NULL,
  `TRAN_RESULT_MESG` varchar(2000) DEFAULT NULL,
  `TRAN_ATTMPT_AT` varchar(20) DEFAULT NULL,
  `BPFLAG` varchar(10) DEFAULT NULL,
  `BPID` varchar(100) DEFAULT NULL,
  `BPGRP` varchar(100) DEFAULT NULL,
  `limitamount` varchar(100) DEFAULT NULL,
  `standing_order` varchar(100) DEFAULT NULL,
  `standing_order_freq` varchar(100) DEFAULT NULL,
  `standing_order_start` varchar(100) DEFAULT NULL,
  `standing_order_exp` varchar(100) DEFAULT NULL,
  `standing_order_type` varchar(100) DEFAULT NULL,
  `ben_curr` varchar(100) DEFAULT NULL,
  `origla` varchar(100) DEFAULT NULL,
  `revla` varchar(100) DEFAULT NULL,
  `updla` varchar(2) DEFAULT NULL,
  `extn1` varchar(100) DEFAULT NULL,
  `extn2` varchar(100) DEFAULT NULL,
  `extn3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ja_acc_num` (`FT_FROM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:31:48
