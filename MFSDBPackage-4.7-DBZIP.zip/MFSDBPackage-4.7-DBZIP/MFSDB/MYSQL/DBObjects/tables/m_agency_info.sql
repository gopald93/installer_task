-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agency_info`
--

DROP TABLE IF EXISTS `agency_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agency_info` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `REF_CUST_REC_ID` varchar(100) DEFAULT NULL,
  `REF_CUST_CIF` varchar(100) DEFAULT NULL,
  `REF_CUST_MOBILE` varchar(100) DEFAULT NULL,
  `REF_CUST_NAME` varchar(100) DEFAULT NULL,
  `DOMIBRNCH` varchar(100) DEFAULT NULL,
  `NATIONALTY` varchar(100) DEFAULT NULL,
  `PROFCONT1` varchar(100) DEFAULT NULL,
  `PROFCONT2` varchar(100) DEFAULT NULL,
  `SERVPK` varchar(100) DEFAULT NULL,
  `BRNCHCODE` varchar(100) DEFAULT NULL,
  `PROFPROV` varchar(100) DEFAULT NULL,
  `PROFAGCODE` varchar(100) DEFAULT NULL,
  `TRDNAME` varchar(100) DEFAULT NULL,
  `PSTADDR` varchar(100) DEFAULT NULL,
  `LRNUM` varchar(100) DEFAULT NULL,
  `PSTCITY` varchar(100) DEFAULT NULL,
  `PSTZIP` varchar(100) DEFAULT NULL,
  `BUSLOC` varchar(100) DEFAULT NULL,
  `PHYADDR` varchar(100) DEFAULT NULL,
  `BUSSTAT` varchar(100) DEFAULT NULL,
  `BUSNAME` varchar(100) DEFAULT NULL,
  `BUSDESIG` varchar(100) DEFAULT NULL,
  `BUSNATIONALITY` varchar(100) DEFAULT NULL,
  `INSTITUTION_ID` int(11) DEFAULT NULL,
  `MADE_BY` int(11) DEFAULT NULL,
  `MADE_AT` datetime DEFAULT NULL,
  `CHECKED_BY` int(11) DEFAULT NULL,
  `CHECKED_AT` datetime DEFAULT NULL,
  `MAKER_LAST_CMT` varchar(200) DEFAULT NULL,
  `CHECKER_LAST_CMT` varchar(200) DEFAULT NULL,
  `CURR_APP_STATUS` int(11) DEFAULT NULL,
  `ADMIN_LAST_CMT` varchar(200) DEFAULT NULL,
  `RSTATUS` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_AT` datetime DEFAULT NULL,
  `MODIFIED_AT` datetime DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `SUB_AGENCY` varchar(10) DEFAULT NULL,
  `MAST_AGCODE` varchar(50) DEFAULT NULL,
  `MERORAG` varchar(2) DEFAULT NULL,
  `served_by` varchar(2) DEFAULT NULL,
  `safoutcode` varchar(10) DEFAULT NULL,
  `airoutcode` varchar(10) DEFAULT NULL,
  `agextn1` varchar(50) DEFAULT NULL,
  `agextn2` varchar(50) DEFAULT NULL,
  `agextn3` varchar(50) DEFAULT NULL,
  `agextn4` varchar(50) DEFAULT NULL,
  `agextn5` varchar(50) DEFAULT NULL,
  `cb_min_amt` varchar(10) DEFAULT NULL,
  `cb_max_amt` varchar(10) DEFAULT NULL,
  `serv_comm` varchar(5) DEFAULT NULL,
  `merpayurl` varchar(200) DEFAULT NULL,
  `agextn6` varchar(50) DEFAULT NULL,
  `agextn7` varchar(50) DEFAULT NULL,
  `agextn8` varchar(50) DEFAULT NULL,
  `agextn9` varchar(50) DEFAULT NULL,
  `agextn10` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `PROFAGCODE_UNIQUE` (`PROFAGCODE`),
  KEY `ref_cust_cif_agif` (`REF_CUST_CIF`),
  KEY `profagcode_agif` (`PROFAGCODE`),
  KEY `ref_cust_rec_id_agif` (`REF_CUST_REC_ID`),
  KEY `mast_agcode_agif` (`MAST_AGCODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:32:04
