-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: masterdb20170123
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funds_transfer_transaction`
--

DROP TABLE IF EXISTS `funds_transfer_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funds_transfer_transaction` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FTFROM` varchar(200) DEFAULT NULL,
  `FTTO` varchar(200) DEFAULT NULL,
  `FTAMOUNT` varchar(20) DEFAULT NULL,
  `FTRESULT` varchar(4000) DEFAULT NULL,
  `FTCURRCODE` varchar(20) DEFAULT NULL,
  `FTCHARGE` varchar(20) DEFAULT NULL,
  `FTTRANTIME` datetime DEFAULT NULL,
  `FTCIF` varchar(20) DEFAULT NULL,
  `FTSOURCE` varchar(100) DEFAULT NULL,
  `FTPHONEID` varchar(100) DEFAULT NULL,
  `FTSESSIONID` varchar(100) DEFAULT NULL,
  `FTREFNO` varchar(100) DEFAULT NULL,
  `FTRESULTCODE` int(11) DEFAULT NULL,
  `ERRMSG` varchar(4000) DEFAULT NULL,
  `RSTATUS` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_AT` datetime DEFAULT NULL,
  `MODIFIED_AT` datetime DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `FTTYPE` varchar(100) DEFAULT NULL,
  `FTSUBCHARGE` varchar(100) DEFAULT NULL,
  `FTSTEPFAILED` varchar(100) DEFAULT NULL,
  `RESP1` varchar(100) DEFAULT NULL,
  `RESP2` varchar(100) DEFAULT NULL,
  `RESP3` varchar(100) DEFAULT NULL,
  `RESP4` varchar(100) DEFAULT NULL,
  `FTCOMMENT` varchar(100) DEFAULT NULL,
  `beneficiary_bank` varchar(500) DEFAULT NULL,
  `beneficiary_branch` varchar(500) DEFAULT NULL,
  `beneficiary_currency` varchar(100) DEFAULT NULL,
  `beneficiary_mobile` varchar(50) DEFAULT NULL,
  `CAT1` varchar(100) DEFAULT NULL,
  `CAT2` varchar(100) DEFAULT NULL,
  `TRAN_DATETS` varchar(100) DEFAULT NULL,
  `CAT3` varchar(100) DEFAULT NULL,
  `curr_code` varchar(100) DEFAULT NULL,
  `tip_amt` varchar(100) DEFAULT NULL,
  `tran_amtf` varchar(100) DEFAULT NULL,
  `ref_tab_id` varchar(100) DEFAULT NULL,
  `tip_and_fee` varchar(100) DEFAULT NULL,
  `conv_fee_amt` varchar(100) DEFAULT NULL,
  `INSTITUTION_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `cat1_ftaudit` (`CAT1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-03 15:32:19
