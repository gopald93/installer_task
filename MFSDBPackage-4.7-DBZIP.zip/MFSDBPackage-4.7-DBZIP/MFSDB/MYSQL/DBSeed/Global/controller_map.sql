/*
-- Query: select * from controller_map
-- Date: 2017-05-15 16:54
*/
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-Systemuserview-','com.modefinserver.mb.controller.extn.MFSystemuserController2','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-Reportmesg-','com.modefinserver.mb.controller.extn.MFReportmesgController2','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-WebSystemuserview-','com.modefinserver.mb.controller.extn.MFSystemuserControllerWeb','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-Agentuserview-','com.modefinserver.mb.controller.extn.MFAgentuserController2','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-Systemlnmuserview-','com.modefinserver.mb.controller.extn.MFLNMuserControllerWeb','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-bokagview-','com.modefinserver.mb.controller.extn.MFSystemuserControllerBok','Y');
INSERT INTO `controller_map` (`CODE`,`CLASSNAME`,`AUTH_FLAG`) VALUES ('-Reportmesgbok-','com.modefinserver.mb.controller.extn.MFReportmesgControllerBok','Y');
